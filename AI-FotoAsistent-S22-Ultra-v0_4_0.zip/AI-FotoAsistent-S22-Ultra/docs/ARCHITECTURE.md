# Architektura

## Tok dat

1. `CameraPreview` připojí Preview, ImageCapture a ImageAnalysis k životnímu cyklu aktivity.
2. `SceneAnalyzer` vzorkuje Y rovinu snímku a spustí lokální ML Kit Image Labeling.
3. `SceneAdvisor` klasifikuje scénu a vytvoří `SceneAdvice`.
4. `CameraViewModel` drží stav, nastavuje zoom/EV, ostří a ukládá snímek přes MediaStore.
5. `CameraScreen` vykresluje doporučení, histogram, vodováhu a ovládací prvky.

## Důležité soubory

- `analysis/SceneAnalyzer.kt` – obrazové metriky a ML Kit.
- `analysis/SceneAdvisor.kt` – fotografická pravidla.
- `CameraViewModel.kt` – CameraX ovládání a ukládání.
- `ui/CameraPreview.kt` – připojení CameraX use cases.
- `ui/CameraScreen.kt` – uživatelské rozhraní.

## Výkon

- `STRATEGY_KEEP_ONLY_LATEST` zabraňuje hromadění snímků.
- Analýza je omezena na interval 650 ms.
- Jasová rovina se vzorkuje po 12 pixelech.
- V jednom okamžiku běží pouze jeden požadavek ML Kit.
