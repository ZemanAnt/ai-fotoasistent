# Changelog

## 0.1.0

- první funkční CameraX fotoaparát;
- lokální AI rozpoznávání scén;
- fotografický poradce pro deset typů scén;
- histogram, vodováha, mřížka a dotykové ostření;
- zoom, korekce expozice, blesk a ukládání do MediaStore;
- české mobilní rozhraní.
