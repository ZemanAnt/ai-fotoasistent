# ML Kit and CameraX ship consumer rules. Add project-specific rules here if needed.
