package cz.hqsnet.aifoto.analysis

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SceneAdvisorTest {

    @Test
    fun darkFrameProducesNightAdvice() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 38f, shadowRatio = 0.42f),
            emptyList()
        )
        assertEquals(SceneKind.NIGHT, result.scene)
        assertEquals(1f, result.zoomRatio)
    }

    @Test
    fun personLabelProducesPortraitAdvice() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 128f),
            listOf("Person" to 0.91f)
        )
        assertEquals(SceneKind.PORTRAIT, result.scene)
        assertTrue(result.zoomRatio >= 3f)
    }

    @Test
    fun mixedHighlightsAndShadowsWarnAboutBacklight() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(
                meanLuma = 120f,
                shadowRatio = 0.24f,
                highlightRatio = 0.09f
            ),
            emptyList()
        )
        assertEquals(SceneKind.BACKLIGHT, result.scene)
        assertTrue(result.exposureCompensation < 0f)
    }
}
