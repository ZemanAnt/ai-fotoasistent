package cz.hqsnet.aifoto.analysis

import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.sqrt

class SceneAnalyzer(
    private val onAdvice: (SceneAdvice) -> Unit
) : ImageAnalysis.Analyzer, AutoCloseable {

    private val labeler = ImageLabeling.getClient(
        ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.45f)
            .build()
    )
    private val processing = AtomicBoolean(false)
    private var lastAnalysisAt = 0L
    private var previousSamples: IntArray? = null

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (processing.get() || now - lastAnalysisAt < ANALYSIS_INTERVAL_MS) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        processing.set(true)
        lastAnalysisAt = now

        try {
            val metrics = calculateMetrics(imageProxy)
            val inputImage = InputImage.fromMediaImage(
                mediaImage,
                imageProxy.imageInfo.rotationDegrees
            )

            labeler.process(inputImage)
                .addOnSuccessListener { labels ->
                    val recognized = labels.map { it.text to it.confidence }
                    onAdvice(SceneAdvisor.recommend(metrics, recognized))
                }
                .addOnFailureListener {
                    onAdvice(SceneAdvisor.recommend(metrics, emptyList()))
                }
                .addOnCompleteListener {
                    processing.set(false)
                    imageProxy.close()
                }
        } catch (_: Throwable) {
            processing.set(false)
            imageProxy.close()
        }
    }

    private fun calculateMetrics(imageProxy: ImageProxy): FrameMetrics {
        val plane = imageProxy.planes.first()
        val buffer = plane.buffer.duplicate()
        val width = imageProxy.width
        val height = imageProxy.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val step = SAMPLE_STEP

        val sampleColumns = ((width - 1) / step) + 1
        val sampleRows = ((height - 1) / step) + 1
        val samples = IntArray(sampleColumns * sampleRows)
        val histogram = IntArray(16)
        val previousRow = IntArray(sampleColumns)

        var index = 0
        var sum = 0.0
        var sumSquares = 0.0
        var shadows = 0
        var highlights = 0
        var edgeTotal = 0.0
        var edgeComparisons = 0

        var sampleY = 0
        var y = 0
        while (y < height) {
            var sampleX = 0
            var left = -1
            var x = 0
            while (x < width) {
                val position = y * rowStride + x * pixelStride
                if (position >= buffer.limit()) break
                val luma = buffer.get(position).toInt() and 0xFF
                samples[index++] = luma
                histogram[(luma / 16).coerceIn(0, 15)]++
                sum += luma
                sumSquares += luma.toDouble() * luma.toDouble()
                if (luma < 28) shadows++
                if (luma > 235) highlights++

                if (left >= 0) {
                    edgeTotal += abs(luma - left)
                    edgeComparisons++
                }
                if (sampleY > 0) {
                    edgeTotal += abs(luma - previousRow[sampleX])
                    edgeComparisons++
                }
                previousRow[sampleX] = luma
                left = luma
                sampleX++
                x += step
            }
            sampleY++
            y += step
        }

        val usedSamples = if (index == samples.size) samples else samples.copyOf(index)
        val count = usedSamples.size.coerceAtLeast(1)
        val mean = (sum / count).toFloat()
        val variance = (sumSquares / count - mean * mean).coerceAtLeast(0.0)
        val contrast = sqrt(variance).toFloat()
        val motion = calculateMotion(usedSamples)
        previousSamples = usedSamples

        val normalizedHistogram = histogram.map { it.toFloat() / count.toFloat() }
        return FrameMetrics(
            meanLuma = mean,
            contrast = contrast,
            shadowRatio = shadows.toFloat() / count,
            highlightRatio = highlights.toFloat() / count,
            motion = motion,
            edgeEnergy = if (edgeComparisons == 0) 0f else (edgeTotal / edgeComparisons).toFloat(),
            histogram = normalizedHistogram
        )
    }

    private fun calculateMotion(current: IntArray): Float {
        val previous = previousSamples ?: return 0f
        if (previous.size != current.size || current.isEmpty()) return 0f

        var difference = 0L
        for (i in current.indices) {
            difference += abs(current[i] - previous[i])
        }
        return (difference.toFloat() / current.size.toFloat() / 255f).coerceIn(0f, 1f)
    }

    override fun close() {
        labeler.close()
    }

    private companion object {
        const val ANALYSIS_INTERVAL_MS = 650L
        const val SAMPLE_STEP = 12
    }
}
