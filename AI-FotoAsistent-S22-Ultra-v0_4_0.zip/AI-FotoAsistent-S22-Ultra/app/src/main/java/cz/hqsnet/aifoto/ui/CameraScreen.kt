package cz.hqsnet.aifoto.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cz.hqsnet.aifoto.CameraEvent
import cz.hqsnet.aifoto.CameraUiState
import cz.hqsnet.aifoto.CameraViewModel
import cz.hqsnet.aifoto.FlashMode
import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2

private val PanelColor = Color(0xCC071014)
private val FineLine = Color.White.copy(alpha = 0.38f)

@Composable
fun CameraScreen(viewModel: CameraViewModel) {
    val advice by viewModel.advice.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            val message = when (event) {
                is CameraEvent.Message -> event.text
                is CameraEvent.PhotoSaved -> event.text
            }
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        containerColor = Color.Black,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .padding(innerPadding)
        ) {
            CameraPreview(
                viewModel = viewModel,
                modifier = Modifier.fillMaxSize()
            ) { previewView ->
                CameraOverlay(
                    previewView = previewView,
                    viewModel = viewModel,
                    advice = advice,
                    uiState = uiState
                )
            }
        }
    }
}

@Composable
private fun CameraOverlay(
    previewView: PreviewView,
    viewModel: CameraViewModel,
    advice: SceneAdvice,
    uiState: CameraUiState
) {
    val level = rememberLevelAngle()

    Box(Modifier.fillMaxSize()) {
        RuleOfThirdsGrid()
        FocusReticle(uiState)
        LevelIndicator(level)

        TopControls(
            advice = advice,
            flashMode = uiState.flashMode,
            onFlash = viewModel::cycleFlash,
            torchOn = uiState.torchOn,
            torchAvailable = uiState.torchAvailable,
            onTorch = viewModel::toggleTorch,
            rawEnabled = uiState.rawEnabled,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        )

        BottomControls(
            advice = advice,
            uiState = uiState,
            onZoom = viewModel::setZoom,
            onApply = viewModel::applyCurrentAdvice,
            onCapture = { viewModel.takePhoto(previewView.context) },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun TopControls(
    advice: SceneAdvice,
    flashMode: FlashMode,
    onFlash: () -> Unit,
    torchOn: Boolean,
    torchAvailable: Boolean,
    onTorch: () -> Unit,
    rawEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = PanelColor,
                shape = RoundedCornerShape(18.dp),
                tonalElevation = 0.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "AI",
                            color = MaterialTheme.colorScheme.onPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "FOTOASISTENT",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            letterSpacing = 0.8.sp
                        )
                        Text(
                            text = if (rawEnabled) "analýza v telefonu · RAW+JPEG" else "analýza v telefonu",
                            color = Color.White.copy(alpha = 0.64f),
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (torchAvailable) {
                    Surface(
                        modifier = Modifier.clickable(onClick = onTorch),
                        color = if (torchOn) MaterialTheme.colorScheme.primary else PanelColor,
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Text(
                            text = "🔦",
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                }
                Surface(
                    modifier = Modifier.clickable(onClick = onFlash),
                    color = PanelColor,
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        text = when (flashMode) {
                            FlashMode.OFF -> "⚡ ×"
                            FlashMode.AUTO -> "⚡ A"
                            FlashMode.ON -> "⚡"
                        },
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Surface(
            color = PanelColor,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = advice.scene.displayName,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "${(advice.confidence * 100).toInt()} %",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = advice.mainTip,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        color = Color.White.copy(alpha = 0.78f),
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
                Spacer(Modifier.width(10.dp))
                MiniHistogram(advice.metrics)
            }
        }
    }
}

@Composable
private fun BottomControls(
    advice: SceneAdvice,
    uiState: CameraUiState,
    onZoom: (Float) -> Unit,
    onApply: () -> Unit,
    onCapture: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LensStrip(
            selectedZoom = uiState.selectedZoom,
            minZoom = uiState.minZoom,
            maxZoom = uiState.maxZoom,
            onZoom = onZoom
        )
        Spacer(Modifier.height(8.dp))

        Surface(
            color = PanelColor,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SettingValue("OBJEKTIV", advice.lensLabel, Modifier.weight(1.2f))
                    SettingValue("ČAS", advice.shutter, Modifier.weight(1f))
                    SettingValue("ISO", advice.iso, Modifier.weight(1f))
                    SettingValue("EV", formatEv(advice.exposureCompensation), Modifier.weight(0.55f))
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onApply,
                        enabled = uiState.cameraReady,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "Použít zoom + EV",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                    }

                    ShutterButton(
                        saving = uiState.isSaving,
                        enabled = uiState.cameraReady,
                        onClick = onCapture
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = advice.secondaryTip,
                    color = Color.White.copy(alpha = 0.62f),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun LensStrip(
    selectedZoom: Float,
    minZoom: Float,
    maxZoom: Float,
    onZoom: (Float) -> Unit
) {
    Surface(
        color = PanelColor,
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier.padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            listOf(0.6f, 1f, 3f, 10f).forEach { zoom ->
                val available = zoom in (minZoom - 0.02f)..(maxZoom + 0.02f)
                val selected = abs(selectedZoom - zoom) < 0.12f
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else Color.Transparent
                        )
                        .alpha(if (available) 1f else 0.35f)
                        .clickable(enabled = available) { onZoom(zoom) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (zoom) {
                            0.6f -> "0,6"
                            1f -> "1×"
                            3f -> "3×"
                            else -> "10×"
                        },
                        color = if (selected) MaterialTheme.colorScheme.onPrimary else Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingValue(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(end = 5.dp)) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 9.sp,
            letterSpacing = 0.6.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 13.sp
        )
    }
}

@Composable
private fun ShutterButton(saving: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(CircleShape)
            .border(3.dp, Color.White.copy(alpha = if (enabled) 0.95f else 0.35f), CircleShape)
            .padding(5.dp)
            .clip(CircleShape)
            .background(if (enabled) Color.White else Color.White.copy(alpha = 0.25f))
            .clickable(enabled = enabled && !saving, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (saving) {
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                strokeWidth = 3.dp,
                color = Color.Black
            )
        }
    }
}

@Composable
private fun RuleOfThirdsGrid() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val x1 = size.width / 3f
        val x2 = size.width * 2f / 3f
        val y1 = size.height / 3f
        val y2 = size.height * 2f / 3f
        drawLine(FineLine, Offset(x1, 0f), Offset(x1, size.height), strokeWidth = 1f)
        drawLine(FineLine, Offset(x2, 0f), Offset(x2, size.height), strokeWidth = 1f)
        drawLine(FineLine, Offset(0f, y1), Offset(size.width, y1), strokeWidth = 1f)
        drawLine(FineLine, Offset(0f, y2), Offset(size.width, y2), strokeWidth = 1f)
    }
}

@Composable
private fun FocusReticle(uiState: CameraUiState) {
    val point = uiState.focusPoint ?: return
    val pulse by animateFloatAsState(
        targetValue = if (uiState.focusPulse % 2 == 0) 1f else 0.82f,
        animationSpec = tween(240),
        label = "focusPulse"
    )
    Canvas(modifier = Modifier.fillMaxSize()) {
        val radius = 34.dp.toPx() * pulse
        drawCircle(
            color = Color.White,
            radius = radius,
            center = Offset(point.x, point.y),
            style = Stroke(width = 2.dp.toPx())
        )
        drawLine(
            Color.White,
            Offset(point.x - radius - 9.dp.toPx(), point.y),
            Offset(point.x - radius + 7.dp.toPx(), point.y),
            strokeWidth = 2.dp.toPx()
        )
        drawLine(
            Color.White,
            Offset(point.x + radius - 7.dp.toPx(), point.y),
            Offset(point.x + radius + 9.dp.toPx(), point.y),
            strokeWidth = 2.dp.toPx()
        )
    }
}

@Composable
private fun LevelIndicator(angle: Float) {
    val animatedAngle by animateFloatAsState(angle, label = "level")
    val leveled = abs(animatedAngle) < 1.5f
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 205.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.graphicsLayer(rotationZ = -animatedAngle.coerceIn(-12f, 12f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .width(54.dp)
                    .height(2.dp)
                    .background(if (leveled) MaterialTheme.colorScheme.primary else Color.White)
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (leveled) MaterialTheme.colorScheme.primary else Color.White)
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .width(54.dp)
                    .height(2.dp)
                    .background(if (leveled) MaterialTheme.colorScheme.primary else Color.White)
            )
        }
        AnimatedVisibility(visible = leveled) {
            Text(
                text = "ROVINA",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun MiniHistogram(metrics: FrameMetrics) {
    val primary = MaterialTheme.colorScheme.primary
    Canvas(
        modifier = Modifier
            .width(74.dp)
            .height(42.dp)
    ) {
        val values = metrics.histogram.ifEmpty { List(16) { 0f } }
        val maxValue = values.maxOrNull()?.coerceAtLeast(0.001f) ?: 0.001f
        val barWidth = size.width / values.size
        values.forEachIndexed { index, value ->
            val barHeight = size.height * (value / maxValue)
            drawLine(
                color = primary.copy(alpha = 0.92f),
                start = Offset(index * barWidth + barWidth / 2f, size.height),
                end = Offset(index * barWidth + barWidth / 2f, size.height - barHeight),
                strokeWidth = (barWidth * 0.64f).coerceAtLeast(1f),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun rememberLevelAngle(): Float {
    val context = LocalContext.current
    var angle by remember { mutableFloatStateOf(0f) }

    DisposableEffect(context) {
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val raw = Math.toDegrees(
                    atan2(event.values[0].toDouble(), event.values[1].toDouble())
                ).toFloat()
                angle = angle * 0.82f + raw * 0.18f
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        if (sensor != null) {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { manager.unregisterListener(listener) }
    }
    return angle
}

private fun formatEv(ev: Float): String = when {
    ev > 0f -> "+%.1f".format(Locale.US, ev)
    ev < 0f -> "%.1f".format(Locale.US, ev)
    else -> "0"
}
