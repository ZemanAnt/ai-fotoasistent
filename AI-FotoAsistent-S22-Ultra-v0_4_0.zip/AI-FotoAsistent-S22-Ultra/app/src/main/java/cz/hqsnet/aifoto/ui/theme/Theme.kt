package cz.hqsnet.aifoto.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AppColors = darkColorScheme(
    primary = Color(0xFF14E6C5),
    onPrimary = Color(0xFF00201A),
    secondary = Color(0xFF8FD6FF),
    tertiary = Color(0xFFFFD166),
    background = Color(0xFF05090B),
    surface = Color(0xFF0C1519),
    onBackground = Color(0xFFF0F7F6),
    onSurface = Color(0xFFF0F7F6),
    error = Color(0xFFFF6B6B)
)

@Composable
fun AiFotoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColors,
        content = content
    )
}
