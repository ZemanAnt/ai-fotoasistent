# AI FotoAsistent pro Samsung Galaxy S22 Ultra

Nativní Android fotoaparát v Kotlinu a Jetpack Compose. Aplikace sleduje živý obraz, rozpoznává typ scény pomocí lokálního modelu ML Kit a kombinuje výsledek s vlastním měřením světla, kontrastu, přepalů, stínů, detailu a pohybu.

## Co umí verze 0.1

- živý náhled z hlavního zadního fotoaparátu;
- offline AI rozpoznávání více než 400 kategorií objektů a scén;
- režimy portrét, noc, krajina, jídlo, dokument, architektura, sport, zvíře, makro a protisvětlo;
- doporučení objektivu, času, ISO, EV, vyvážení bílé, ostření a HDR;
- automatické použití dostupného zoomu a korekce expozice;
- tlačítka 0,6× / 1× / 3× / 10× podle rozsahu, který telefon zpřístupní přes CameraX;
- ostření a měření expozice klepnutím do náhledu;
- histogram, mřížka třetin a elektronická vodováha;
- blesk vypnuto / auto / zapnuto;
- ukládání fotografií do `Obrázky/AI FotoAsistent`;
- české rozhraní a zpracování obrazu přímo v telefonu.

## Otevření v Android Studiu

1. Rozbalte ZIP.
2. V Android Studiu zvolte **Open** a vyberte kořenovou složku `AI-FotoAsistent-S22-Ultra`.
3. Použijte JDK 17 a nainstalovaný Android SDK 36.
4. Nechte proběhnout Gradle Sync.
5. Připojte S22 Ultra s povoleným laděním USB a stiskněte **Run**.

Projekt používá Gradle 8.13, Android Gradle Plugin 8.11.1, CameraX 1.6.1 a target SDK 36. Přiložený malý bootstrap `gradle-wrapper.jar` stáhne deklarovanou distribuci Gradlu při prvním sestavení.

### Sestavení APK ve Windows

```bat
gradlew.bat testDebugUnitTest assembleDebug
```

Výsledné APK:

```text
app\build\outputs\apk\debug\app-debug.apk
```

### Sestavení APK v Linuxu nebo macOS

```bash
./gradlew testDebugUnitTest assembleDebug
```

## Jak funguje doporučení

Každých přibližně 650 ms se zmenšeně analyzuje jasová složka snímku. Vypočítá se průměrný jas, kontrast, podíl hlubokých stínů a přepalů, změna proti minulému snímku a energie hran. Současně ML Kit vrátí pravděpodobné štítky obsahu. `SceneAdvisor` obě skupiny dat spojí a vytvoří fotografické doporučení.

Tlačítko **Použít zoom + EV** záměrně nastavuje jen parametry, které CameraX spolehlivě zpřístupňuje napříč variantami S22 Ultra. Doporučené ISO, čas a WB se zatím zobrazují jako fotografická rada. Plně manuální řízení přes Camera2 je připravené pro další verzi.

## Omezení první verze

- Přístup k fyzickým objektivům závisí na tom, jak je firmware telefonu zveřejní jako logický vícefotoaparátový systém. Nedostupné hodnoty zoomu se v aplikaci ztlumí.
- Výpočetní zpracování není totožné s originální aplikací Samsung Camera nebo Expert RAW.
- CameraX vendor extensions pro Samsung Night/HDR/Bokeh ještě nejsou zapojené.
- AI štítky jsou obecné; specializovaný fotografický model bude přesnější hlavně pro noční město, produktové fotografie a archeologickou dokumentaci.

## Doporučené pokračování 0.2

- Camera2 manual mode: ISO, čas, manuální ostření a WB;
- automatická dostupnost HDR, Night a Bokeh Extensions;
- specializovaný LiteRT model pro fotografické scény;
- detekce obličejů a očí;
- RAW/DNG + JPEG;
- sériové snímání pro sport a zvířata;
- galerie s porovnáním doporučení a výsledné fotografie;
- profil „archeologie“ pro dokumentaci nálezů, výkopů a objektů.

## Soukromí

Aplikace nemá síťové oprávnění. Model rozpoznávání je součástí APK a analýza probíhá lokálně. Fotografie se ukládají pouze do systémové galerie zařízení.
