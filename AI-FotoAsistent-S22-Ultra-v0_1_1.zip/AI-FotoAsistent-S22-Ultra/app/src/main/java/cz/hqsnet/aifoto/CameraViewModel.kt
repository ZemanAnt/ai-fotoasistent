package cz.hqsnet.aifoto

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import cz.hqsnet.aifoto.model.SceneAdvice
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val _advice = MutableStateFlow(SceneAdvice.Initial)
    val advice: StateFlow<SceneAdvice> = _advice.asStateFlow()

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<CameraEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<CameraEvent> = _events.asSharedFlow()

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null

    fun attachCamera(camera: Camera, imageCapture: ImageCapture) {
        this.camera = camera
        this.imageCapture = imageCapture
        val zoomState = camera.cameraInfo.zoomState.value
        _uiState.update {
            it.copy(
                minZoom = zoomState?.minZoomRatio ?: 1f,
                maxZoom = zoomState?.maxZoomRatio ?: 10f,
                selectedZoom = zoomState?.zoomRatio ?: 1f,
                cameraReady = true
            )
        }
        applyFlashMode(_uiState.value.flashMode)
    }

    fun detachCamera() {
        camera = null
        imageCapture = null
        _uiState.update { it.copy(cameraReady = false) }
    }

    fun onAdvice(advice: SceneAdvice) {
        _advice.value = advice
    }

    fun setZoom(requestedZoom: Float) {
        val activeCamera = camera ?: return
        val state = activeCamera.cameraInfo.zoomState.value
        val min = state?.minZoomRatio ?: _uiState.value.minZoom
        val max = state?.maxZoomRatio ?: _uiState.value.maxZoom
        val zoom = requestedZoom.coerceIn(min, max)
        activeCamera.cameraControl.setZoomRatio(zoom)
        _uiState.update { it.copy(selectedZoom = zoom) }
    }

    fun applyCurrentAdvice() {
        val recommendation = _advice.value
        setZoom(recommendation.zoomRatio)
        applyExposureCompensation(recommendation.exposureCompensation)
        _events.tryEmit(
            CameraEvent.Message(
                "Použito: ${recommendation.lensLabel}, EV ${formatEv(recommendation.exposureCompensation)}"
            )
        )
    }

    private fun applyExposureCompensation(ev: Float) {
        val activeCamera = camera ?: return
        val exposureState = activeCamera.cameraInfo.exposureState
        if (!exposureState.isExposureCompensationSupported) return

        val step = exposureState.exposureCompensationStep.toFloat()
        if (step <= 0f) return
        val range = exposureState.exposureCompensationRange
        val index = (ev / step).roundToInt().coerceIn(range.lower, range.upper)
        activeCamera.cameraControl.setExposureCompensationIndex(index)
    }

    fun focusAt(previewView: PreviewView, x: Float, y: Float) {
        val activeCamera = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        )
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        activeCamera.cameraControl.startFocusAndMetering(action)
        _uiState.update { it.copy(focusPoint = FocusPoint(x, y), focusPulse = it.focusPulse + 1) }
    }

    fun cycleFlash() {
        val next = when (_uiState.value.flashMode) {
            FlashMode.OFF -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.ON
            FlashMode.ON -> FlashMode.OFF
        }
        _uiState.update { it.copy(flashMode = next) }
        applyFlashMode(next)
    }

    private fun applyFlashMode(mode: FlashMode) {
        imageCapture?.flashMode = when (mode) {
            FlashMode.OFF -> ImageCapture.FLASH_MODE_OFF
            FlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
            FlashMode.ON -> ImageCapture.FLASH_MODE_ON
        }
    }

    fun takePhoto(context: Context) {
        val capture = imageCapture
        if (capture == null) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (_uiState.value.isSaving) return

        _uiState.update { it.copy(isSaving = true) }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_Foto_$timestamp")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
            }
        }
        val collection: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val options = ImageCapture.OutputFileOptions.Builder(
            context.contentResolver,
            collection,
            values
        ).build()

        capture.takePicture(
            options,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    _uiState.update { it.copy(isSaving = false) }
                    _events.tryEmit(
                        CameraEvent.PhotoSaved(
                            outputFileResults.savedUri,
                            "Fotografie byla uložena do alba AI FotoAsistent."
                        )
                    )
                }

                override fun onError(exception: ImageCaptureException) {
                    _uiState.update { it.copy(isSaving = false) }
                    _events.tryEmit(CameraEvent.Message("Fotografii se nepodařilo uložit: ${exception.message}"))
                }
            }
        )
    }

    private fun formatEv(ev: Float): String = when {
        ev > 0f -> "+%.1f".format(Locale.US, ev)
        ev < 0f -> "%.1f".format(Locale.US, ev)
        else -> "0"
    }
}

data class CameraUiState(
    val cameraReady: Boolean = false,
    val selectedZoom: Float = 1f,
    val minZoom: Float = 1f,
    val maxZoom: Float = 10f,
    val flashMode: FlashMode = FlashMode.AUTO,
    val isSaving: Boolean = false,
    val focusPoint: FocusPoint? = null,
    val focusPulse: Int = 0
)

data class FocusPoint(val x: Float, val y: Float)

enum class FlashMode(val label: String) {
    OFF("Blesk vyp."),
    AUTO("Blesk auto"),
    ON("Blesk zap.")
}

sealed interface CameraEvent {
    data class Message(val text: String) : CameraEvent
    data class PhotoSaved(val uri: Uri?, val text: String) : CameraEvent
}
