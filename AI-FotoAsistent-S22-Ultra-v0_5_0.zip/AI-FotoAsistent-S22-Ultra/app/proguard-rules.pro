# ML Kit and CameraX ship consumer rules, but both reach for classes via
# reflection and JNI at runtime, so keep the entry points R8 cannot see.

# --- CameraX --------------------------------------------------------------
-keep class androidx.camera.** { *; }
-dontwarn androidx.camera.**

# JNI bridges (libimage_processing_util_jni.so, libsurface_util_jni.so).
-keepclasseswithmembernames class * { native <methods>; }

# --- ML Kit ---------------------------------------------------------------
# Components are discovered through the manifest at runtime.
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_** { *; }
-dontwarn com.google.mlkit.**

# Bundled TFLite interpreter for the image labeling model.
-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.lite.**

-dontwarn com.google.android.gms.**

# --- Kotlin coroutines ----------------------------------------------------
-keepclassmembers class kotlinx.coroutines.** { volatile <fields>; }
-dontwarn kotlinx.coroutines.**

# --- App models -----------------------------------------------------------
# Data classes carry the analyzer output; keep names for readable crash logs.
-keep class cz.hqsnet.aifoto.model.** { *; }

# --- Diagnostics ----------------------------------------------------------
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod
# Keep line numbers so release stack traces stay readable.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
