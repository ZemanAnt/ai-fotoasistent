package cz.hqsnet.aifoto.analysis

import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.sqrt

class SceneAnalyzer(
    private val onAdvice: (SceneAdvice) -> Unit
) : ImageAnalysis.Analyzer, AutoCloseable {

    private val labeler = ImageLabeling.getClient(
        ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.45f)
            .build()
    )
    private val processing = AtomicBoolean(false)
    private var lastAnalysisAt = 0L
    private var previousSamples: IntArray? = null

    /**
     * Volitelný odběratel snímků pro noční skládání. Když je nastavený, dostane
     * každý snímek ještě před throttlingem analýzy - proto skládání běží na plný
     * frame-rate a nezávisí na druhém, křehkém ImageAnalysis use-casu. Vrací
     * true, když už má nasbíráno dost a další snímky nechce.
     */
    @Volatile
    var frameSink: ((ImageProxy) -> Boolean)? = null

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        // Noční skládání má přednost: pokud sbírá snímky, dodáme mu je bez
        // ohledu na throttling analýzy scény, jinak by 8 snímků trvalo přes
        // pět sekund jen kvůli intervalu mezi rozbory.
        val sink = frameSink
        if (sink != null) {
            val done = try {
                sink(imageProxy)
            } catch (_: Throwable) {
                true
            }
            if (done) frameSink = null
            imageProxy.close()
            return
        }

        val now = System.currentTimeMillis()
        if (processing.get() || now - lastAnalysisAt < ANALYSIS_INTERVAL_MS) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        processing.set(true)
        lastAnalysisAt = now

        try {
            val metrics = calculateMetrics(imageProxy)
            val inputImage = InputImage.fromMediaImage(
                mediaImage,
                imageProxy.imageInfo.rotationDegrees
            )

            labeler.process(inputImage)
                .addOnSuccessListener { labels ->
                    val recognized = labels.map { it.text to it.confidence }
                    onAdvice(SceneAdvisor.recommend(metrics, recognized))
                }
                .addOnFailureListener {
                    onAdvice(SceneAdvisor.recommend(metrics, emptyList()))
                }
                .addOnCompleteListener {
                    processing.set(false)
                    imageProxy.close()
                }
        } catch (_: Throwable) {
            processing.set(false)
            imageProxy.close()
        }
    }

    /**
     * Vzorkuje snímek na PEVNÉ mřížce GRID_WIDTH x GRID_HEIGHT.
     *
     * Dříve se krokovalo po SAMPLE_STEP pixelech, takže počet vzorků závisel na
     * rozlišení snímku. Při každé změně rozlišení nebo rotaci se délka pole
     * rozešla s previousSamples, calculateMotion vracelo 0f a scéna ACTION se
     * nemusela vůbec detekovat. Pevná mřížka drží délku pole konstantní.
     */
    private fun calculateMetrics(imageProxy: ImageProxy): FrameMetrics {
        val plane = imageProxy.planes.first()
        val buffer = plane.buffer.duplicate()
        val width = imageProxy.width
        val height = imageProxy.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride

        val samples = IntArray(GRID_WIDTH * GRID_HEIGHT)
        val histogram = IntArray(16)
        val previousRow = IntArray(GRID_WIDTH)

        var index = 0
        var sum = 0.0
        var sumSquares = 0.0
        var shadows = 0
        var highlights = 0
        var edgeTotal = 0.0
        var edgeComparisons = 0

        var gridY = 0
        while (gridY < GRID_HEIGHT) {
            // Střed buňky mřížky, aby se nevzorkoval jen levý horní okraj.
            val y = (((gridY + 0.5f) / GRID_HEIGHT) * height).toInt().coerceIn(0, height - 1)
            var left = -1
            var gridX = 0
            while (gridX < GRID_WIDTH) {
                val x = (((gridX + 0.5f) / GRID_WIDTH) * width).toInt().coerceIn(0, width - 1)
                val position = y * rowStride + x * pixelStride
                val luma = if (position < buffer.limit()) {
                    buffer.get(position).toInt() and 0xFF
                } else {
                    0
                }
                samples[index++] = luma
                histogram[(luma / 16).coerceIn(0, 15)]++
                sum += luma
                sumSquares += luma.toDouble() * luma.toDouble()
                if (luma < 28) shadows++
                if (luma > 235) highlights++

                if (left >= 0) {
                    edgeTotal += abs(luma - left)
                    edgeComparisons++
                }
                if (gridY > 0) {
                    edgeTotal += abs(luma - previousRow[gridX])
                    edgeComparisons++
                }
                previousRow[gridX] = luma
                left = luma
                gridX++
            }
            gridY++
        }

        val count = samples.size
        val mean = (sum / count).toFloat()
        val variance = (sumSquares / count - mean * mean).coerceAtLeast(0.0)
        val contrast = sqrt(variance).toFloat()
        val motion = calculateMotion(samples)
        previousSamples = samples

        val normalizedHistogram = histogram.map { it.toFloat() / count.toFloat() }
        return FrameMetrics(
            meanLuma = mean,
            contrast = contrast,
            shadowRatio = shadows.toFloat() / count,
            highlightRatio = highlights.toFloat() / count,
            motion = motion,
            edgeEnergy = if (edgeComparisons == 0) 0f else (edgeTotal / edgeComparisons).toFloat(),
            histogram = normalizedHistogram
        )
    }

    private fun calculateMotion(current: IntArray): Float {
        val previous = previousSamples ?: return 0f
        if (previous.size != current.size || current.isEmpty()) return 0f

        var difference = 0L
        for (i in current.indices) {
            difference += abs(current[i] - previous[i])
        }
        return (difference.toFloat() / current.size.toFloat() / 255f).coerceIn(0f, 1f)
    }

    override fun close() {
        labeler.close()
    }

    private companion object {
        const val ANALYSIS_INTERVAL_MS = 650L

        // Pevná vzorkovací mřížka (4:3). 1728 vzorků je dost na metriky
        // i na detekci pohybu a je nezávislá na rozlišení a rotaci snímku.
        const val GRID_WIDTH = 48
        const val GRID_HEIGHT = 36
    }
}
