package cz.hqsnet.aifoto.analysis

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import kotlin.math.max

object SceneAdvisor {

    /**
     * Práh hustoty hran pro makro. Hodnota je vázaná na vzorkovací mřížku
     * v SceneAnalyzeru (48×36) - řidší mřížka dává vyšší hodnoty, takže při
     * její změně je potřeba práh přeměřit, jinak se běžné scény začnou
     * klasifikovat jako makro.
     */
    private const val MACRO_EDGE_ENERGY = 60f

    fun recommend(metrics: FrameMetrics, labels: List<Pair<String, Float>>): SceneAdvice {
        val normalized = labels.map { it.first.lowercase() to it.second }
        val scene = classify(metrics, normalized)
        val labelConfidence = normalized.maxOfOrNull { it.second } ?: 0f
        val metricConfidence = when (scene) {
            SceneKind.NIGHT -> ((90f - metrics.meanLuma) / 70f).coerceIn(0.35f, 0.98f)
            SceneKind.BACKLIGHT -> (metrics.shadowRatio + metrics.highlightRatio).coerceIn(0.35f, 0.95f)
            SceneKind.ACTION -> (metrics.motion * 2.4f).coerceIn(0.35f, 0.95f)
            else -> 0.46f
        }
        val confidence = max(labelConfidence, metricConfidence).coerceIn(0f, 0.99f)
        val labelNames = labels
            .filter { it.second >= 0.55f }
            .sortedByDescending { it.second }
            .take(4)
            .map { it.first }

        return adviceFor(scene, metrics, confidence, labelNames)
    }

    private fun classify(
        metrics: FrameMetrics,
        labels: List<Pair<String, Float>>
    ): SceneKind {
        fun has(vararg keywords: String, threshold: Float = 0.52f): Boolean =
            labels.any { (name, confidence) ->
                confidence >= threshold && keywords.any { keyword -> name.contains(keyword) }
            }

        val severeBacklight = metrics.highlightRatio > 0.055f && metrics.shadowRatio > 0.16f
        if (severeBacklight) return SceneKind.BACKLIGHT

        // NOC MUSÍ PŘED POHYBEM. Ve tmě ML Kit z šumu často vrátí "vehicle"
        // nebo "sport" a šum mezi snímky vypadá jako pohyb - bez této priority
        // se tmavá scéna chybně klasifikuje jako ACTION a dostane rychlý čas,
        // což dá černý snímek. Tmavá scéna je noc bez ohledu na labely.
        val clearlyDark = metrics.meanLuma < 88f
        if (clearlyDark && !has("night", "darkness")) {
            // Skutečný rychlý pohyb ve tmě (blesk, jasné světlo objektu) může
            // existovat, ale musí být silný - jinak vyhrává noc.
            if (metrics.motion <= 0.30f) return SceneKind.NIGHT
        }

        if (metrics.motion > 0.135f || has("sport", "running", "vehicle", "dance", "skateboard")) {
            return SceneKind.ACTION
        }
        if (has("person", "face", "selfie", "smile", "portrait", threshold = 0.48f)) {
            return SceneKind.PORTRAIT
        }
        if (has("dog", "cat", "pet", "animal", "bird", "horse")) {
            return SceneKind.PET
        }
        if (has("food", "dish", "meal", "dessert", "fruit", "vegetable", "drink")) {
            return SceneKind.FOOD
        }
        if (has("document", "paper", "text", "receipt", "book", "handwriting")) {
            return SceneKind.DOCUMENT
        }
        if (has("building", "architecture", "tower", "church", "house", "bridge", "monument")) {
            return SceneKind.ARCHITECTURE
        }
        if (has("flower", "insect", "jewelry", "close-up", "macro")) {
            return SceneKind.MACRO
        }
        if (has("landscape", "mountain", "sky", "sea", "forest", "field", "beach", "sunset")) {
            return SceneKind.LANDSCAPE
        }
        // Vysoká hustota hran sama o sobě znamená makro jen tehdy, když scénu
        // nerozpoznal žádný konkrétnější štítek. Texturovaná krajina (tráva,
        // listí, dav) dává podobně vysokou hodnotu jako skutečný detail, takže
        // štítky mají přednost. Práh je vztažený k mřížce v SceneAnalyzeru -
        // při její změně je nutné ho překalibrovat.
        if (metrics.edgeEnergy > MACRO_EDGE_ENERGY && labels.isEmpty()) {
            return SceneKind.MACRO
        }
        if (metrics.meanLuma < 88f || has("night", "darkness", "fireworks", "moon")) {
            return SceneKind.NIGHT
        }
        return SceneKind.GENERAL
    }

    private fun adviceFor(
        scene: SceneKind,
        metrics: FrameMetrics,
        confidence: Float,
        labels: List<String>
    ): SceneAdvice {
        val highlightWarning = metrics.highlightRatio > 0.04f
        val lowLight = metrics.meanLuma < 82f

        val base = when (scene) {
            SceneKind.PORTRAIT -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 3f,
                lensLabel = "3× portrétní",
                shutter = "1/125 s nebo rychleji",
                iso = if (lowLight) "Auto, max. 1600" else "50–400",
                exposureCompensation = if (highlightWarning) -0.7f else -0.3f,
                whiteBalance = "Auto / pleť",
                focus = "Oči a obličej",
                hdr = "Auto",
                mainTip = "Ustupte o krok a použijte 3×. Pozadí bude klidnější a obličej přirozenější.",
                secondaryTip = "Ostřete na bližší oko a hlídejte světlo v obličeji."
            )

            SceneKind.NIGHT -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = if (metrics.motion > 0.08f) "1/60 s" else "1/15–1/8 s",
                iso = if (metrics.motion > 0.08f) "Auto, max. 3200" else "400–1600",
                // U statické scény vytáhneme expozici co nejvýš (kód si vezme
                // maximum, které čip dovolí) - jinak v analytickém režimu
                // nemáme jak scénu prosvětlit. U pohybu ne, rozmazalo by se.
                exposureCompensation = if (metrics.motion > 0.08f) 0.3f else 2f,
                whiteBalance = "3 800–4 500 K",
                focus = "Jednorázové AF",
                hdr = "Noční / Auto",
                mainTip = if (metrics.motion > 0.08f)
                    "Ve scéně je pohyb. Držte čas kolem 1/60 s a počítejte s vyšším ISO."
                else
                    "Opřete telefon o pevnou oporu a vyfoťte. Pro blízké objekty zapněte svítilnu (ikona 🔦).",
                secondaryTip = "Vzdálené noční panorama blesk nedosvítí - nechte ho vypnutý. Po stisku spouště chvíli nehýbejte."
            )

            SceneKind.LANDSCAPE -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = if (metrics.highlightRatio < 0.03f) 0.6f else 1f,
                lensLabel = if (metrics.highlightRatio < 0.03f) "0,6× široký" else "1× hlavní",
                shutter = "1/125–1/500 s",
                iso = "50–100",
                exposureCompensation = if (highlightWarning) -0.7f else -0.3f,
                whiteBalance = "Denní / Auto",
                focus = "Vzdálený plán",
                hdr = if (highlightWarning) "Zapnout" else "Auto",
                mainTip = "Srovnejte horizont a chraňte kresbu v obloze mírnou zápornou korekcí.",
                secondaryTip = "Širokoúhlý objektiv použijte jen tehdy, když jsou důležité i okraje scény."
            )

            SceneKind.FOOD -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = "1/100 s nebo rychleji",
                iso = "50–800",
                exposureCompensation = 0.3f,
                whiteBalance = "Auto, bez žlutého nádechu",
                focus = "Na hlavní detail jídla",
                hdr = "Auto",
                mainTip = "Přibližte se fyzicky, ale nenechte telefon stínit scénu. Ostřete na nejvýraznější detail.",
                secondaryTip = "Měkké boční světlo obvykle funguje lépe než blesk."
            )

            SceneKind.DOCUMENT -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = "1/125 s nebo rychleji",
                iso = "Auto, max. 800",
                exposureCompensation = 0.3f,
                whiteBalance = "Auto",
                focus = "Střed dokumentu",
                hdr = "Vypnout / Auto",
                mainTip = "Držte telefon rovnoběžně s papírem a vyplňte dokumentem většinu obrazu.",
                secondaryTip = "Vyhněte se odleskům a stínu telefonu."
            )

            SceneKind.ARCHITECTURE -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = "1/125–1/500 s",
                iso = "50–200",
                exposureCompensation = if (highlightWarning) -0.7f else -0.3f,
                whiteBalance = "Auto / denní",
                focus = "Střední vzdálenost",
                hdr = "Auto",
                mainTip = "Držte telefon co nejvíce svisle. Tím omezíte sbíhání stěn a věží.",
                secondaryTip = "Raději ustupte než používat příliš široký záběr."
            )

            SceneKind.ACTION -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 3f,
                lensLabel = "3× podle vzdálenosti",
                shutter = "1/500–1/1000 s",
                iso = if (lowLight) "Auto, max. 3200" else "Auto, max. 1600",
                exposureCompensation = -0.3f,
                whiteBalance = "Auto",
                focus = "Průběžné AF",
                hdr = "Vypnout / Auto",
                mainTip = "Sledujte objekt plynule a začněte fotit těsně před vrcholem pohybu.",
                secondaryTip = "Rychlý čas je důležitější než nízké ISO."
            )

            SceneKind.PET -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 3f,
                lensLabel = "3× z odstupu",
                shutter = "1/500 s",
                iso = "Auto, max. 3200",
                exposureCompensation = 0f,
                whiteBalance = "Auto",
                focus = "Oči zvířete",
                hdr = "Auto",
                mainTip = "Snižte telefon do úrovně očí zvířete a nechte před pohledem volný prostor.",
                secondaryTip = "Použijte rychlý čas; srst snese trochu vyšší ISO lépe než rozmazání."
            )

            SceneKind.MACRO -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = "1/250 s",
                iso = "Auto, max. 1600",
                exposureCompensation = 0f,
                whiteBalance = "Auto",
                focus = "Klepnutím na detail",
                hdr = "Auto",
                mainTip = "Nepřibližujte telefon pod minimální ostřicí vzdálenost. Raději lehce ustupte a ořízněte.",
                secondaryTip = "Podepřete ruce; u detailu je vidět i velmi malé chvění."
            )

            SceneKind.BACKLIGHT -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = "1/125 s nebo rychleji",
                iso = "Auto",
                exposureCompensation = -1f,
                whiteBalance = "Auto",
                focus = "Na hlavní objekt",
                hdr = "Zapnout",
                mainTip = "Ve scéně jsou současně hluboké stíny a jasné přepaly. Zapněte HDR a chraňte světla.",
                secondaryTip = "Klepněte na hlavní objekt; siluetu lze vytvořit ještě nižší expozicí."
            )

            SceneKind.GENERAL -> SceneAdvice(
                scene = scene,
                confidence = confidence,
                zoomRatio = 1f,
                lensLabel = "1× hlavní",
                shutter = if (metrics.motion > 0.07f) "1/250 s" else "1/100 s",
                iso = if (lowLight) "Auto, max. 1600" else "Auto, max. 800",
                exposureCompensation = when {
                    highlightWarning -> -0.7f
                    metrics.meanLuma < 72f -> 0.3f
                    else -> 0f
                },
                whiteBalance = "Auto",
                focus = "Průběžné AF",
                hdr = if (highlightWarning) "Zapnout" else "Auto",
                mainTip = when {
                    highlightWarning -> "Snižte expozici, aby se neztratila kresba v nejsvětlejších místech."
                    metrics.motion > 0.07f -> "Telefon nebo objekt se pohybuje. Použijte rychlejší čas a pevnější úchop."
                    lowLight -> "Je málo světla. Použijte hlavní 1× objektiv a opřete ruce."
                    else -> "Klepněte na hlavní objekt a zkontrolujte rušivé prvky u okrajů obrazu."
                },
                secondaryTip = "Hlavní 1× fotoaparát obvykle nabízí nejlepší kvalitu a dynamický rozsah."
            )
        }

        return base.copy(metrics = metrics, labels = labels)
    }
}
