package cz.hqsnet.aifoto.capture

import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera

/**
 * Zamyká expozici a vyvážení bílé po dobu skládání snímků.
 *
 * Automatika mezi snímky dolaďuje jas i barvy, takže by se průměrovaly
 * snímky s odlišnou expozicí. Průměrování takovou odchylku neodstraní -
 * není náhodná jako šum, ale systematická, takže se do výsledku propíše.
 * Při kolísání kolem ±20 % vzroste chyba výsledku zhruba o polovinu.
 *
 * Interop je best-effort: když ho zařízení nepodpoří, skládání proběhne
 * i bez zámku, jen s o něco horším výsledkem.
 */
object ExposureLock {

    /**
     * Zamkne AE a AWB. Vrací true, pokud se požadavek podařilo odeslat -
     * neznamená to záruku, že zařízení zámek skutečně respektuje.
     */
    fun lock(camera: Camera): Boolean = apply(camera, locked = true)

    /** Uvolní zámek zpět na automatiku. */
    fun unlock(camera: Camera): Boolean = apply(camera, locked = false)

    @OptIn(ExperimentalCamera2Interop::class)
    private fun apply(camera: Camera, locked: Boolean): Boolean = try {
        val control = Camera2CameraControl.from(camera.cameraControl)
        val options = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, locked)
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, locked)
            .build()
        control.setCaptureRequestOptions(options)
        true
    } catch (_: Throwable) {
        // Starší nebo nestandardní zařízení interop nemusí podporovat.
        false
    }
}
