package cz.hqsnet.aifoto.capture

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy

/**
 * Samostatný ImageAnalysis.Analyzer výhradně pro sběr snímků do FrameStackeru.
 *
 * Záměrně oddělený od SceneAnalyzeru (ML Kit), aby si oba use-casy
 * nekonkurovaly o snímky a stacking běžel na plný frame-rate bez throttlingu.
 * Aktivní je jen když je nastaven [stacker] (tj. probíhá noční snímání).
 *
 * [onFrame] se volá po každém přidaném snímku s aktuálním progressem (0..1)
 * a příznakem dokončení – ViewModel podle toho aktualizuje UI a spustí uložení.
 */
class StackAnalyzer(
    private val onFrame: (progress: Float, done: Boolean) -> Unit
) : ImageAnalysis.Analyzer {

    @Volatile
    var stacker: FrameStacker? = null

    override fun analyze(imageProxy: ImageProxy) {
        val s = stacker
        if (s == null) { imageProxy.close(); return }
        try {
            val done = s.addFrame(imageProxy)
            onFrame(s.progress, done)
            if (done) stacker = null // dosbíráno – přestaň konzumovat další snímky
        } catch (t: Throwable) {
            stacker = null
            onFrame(0f, true)
        } finally {
            imageProxy.close()
        }
    }
}
