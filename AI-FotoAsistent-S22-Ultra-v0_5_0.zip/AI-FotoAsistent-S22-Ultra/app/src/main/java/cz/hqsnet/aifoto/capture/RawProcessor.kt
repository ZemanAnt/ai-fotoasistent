package cz.hqsnet.aifoto.capture

import android.hardware.camera2.CameraCharacteristics
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera

/**
 * Převádí surová data ze snímače na zobrazitelný obraz.
 *
 * Snímek z RAW není hotová fotka - je to jen odečet jednotlivých buněk
 * snímače. Každá buňka vidí přes barevný filtr jen jednu složku (Bayerova
 * mřížka), data jsou lineární, nevyvážená a posunutá o černou úroveň.
 * Než z toho vznikne obraz, musí projít čtyřmi kroky, které jinak dělá
 * procesor fotoaparátu sám:
 *
 *  1. odečtení černé úrovně - snímač i v naprosté tmě hlásí nenulovou hodnotu,
 *  2. vyvážení bílé - v Bayerově mřížce jsou dvě zelené buňky na jednu
 *     červenou a modrou, takže bez korekce vyjde obraz zeleně,
 *  3. demozaikace - dopočítání chybějících dvou složek u každého pixelu,
 *  4. gama - lineární data vypadají na displeji velmi tmavě, protože oko
 *     vnímá jas logaritmicky.
 *
 * Proč to stojí za tu práci: v nejtmavší desetině rozsahu má osmibitový JPEG
 * kolem pětadvaceti úrovní jasu, dvanáctibitový RAW přes čtyři sta. Noční
 * scéna se odehrává právě tam a jemnější odstupňování znamená, že vytažení
 * stínů nezpůsobí pásy.
 */
object RawProcessor {

    /** Uspořádání barevných filtrů na snímači. */
    enum class CfaPattern { RGGB, GRBG, GBRG, BGGR }

    /**
     * Co je potřeba vědět o snímači, aby se data dala správně přečíst.
     * Hodnoty se čtou ze zařízení; když je nelze zjistit, použijí se
     * rozumné výchozí.
     */
    data class SensorParams(
        val blackLevel: Int = DEFAULT_BLACK_LEVEL,
        val whiteLevel: Int = DEFAULT_WHITE_LEVEL,
        val pattern: CfaPattern = CfaPattern.RGGB,
        /** Násobky pro vyrovnání barev; zelená bývá 1.0. */
        val gainR: Float = DEFAULT_GAIN_R,
        val gainG: Float = 1f,
        val gainB: Float = DEFAULT_GAIN_B
    )

    /**
     * Vyčte parametry snímače ze zařízení.
     *
     * Každý snímač má jiné uspořádání barevných filtrů i jinou černou úroveň,
     * takže hádat se nedá - špatný Bayerův vzor prohodí červenou s modrou.
     * Když se údaje zjistit nepodaří, vrátí se běžné výchozí hodnoty.
     */
    @OptIn(ExperimentalCamera2Interop::class)
    fun readSensorParams(camera: Camera): SensorParams {
        return try {
            val info = Camera2CameraInfo.from(camera.cameraInfo)

            val arrangement = info.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT
            )
            val pattern = when (arrangement) {
                CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_RGGB -> CfaPattern.RGGB
                CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_GRBG -> CfaPattern.GRBG
                CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_GBRG -> CfaPattern.GBRG
                CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT_BGGR -> CfaPattern.BGGR
                else -> CfaPattern.RGGB
            }

            val whiteLevel = info.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL
            ) ?: DEFAULT_WHITE_LEVEL

            // Černá úroveň se udává zvlášť pro každou ze čtyř buněk mřížky;
            // pro naše účely stačí jejich průměr.
            val blackPattern = info.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN
            )
            val blackLevel = if (blackPattern != null) {
                val values = IntArray(4)
                blackPattern.copyTo(values, 0)
                values.average().toInt()
            } else {
                DEFAULT_BLACK_LEVEL
            }

            SensorParams(
                blackLevel = blackLevel,
                whiteLevel = whiteLevel,
                pattern = pattern
            )
        } catch (_: Throwable) {
            SensorParams()
        }
    }

    /**
     * Zpracuje surová data na pixely ve formátu ARGB_8888.
     *
     * @param raw hodnoty buněk snímače, jeden kanál v Bayerově mřížce
     * @param gamma převodní křivka; vyšší hodnota víc zesvětlí stíny
     */
    fun process(
        raw: IntArray,
        width: Int,
        height: Int,
        params: SensorParams,
        gamma: Float = DEFAULT_GAMMA
    ): IntArray {
        if (width <= 0 || height <= 0 || raw.isEmpty()) return IntArray(0)

        // Rozsah po odečtení černé. Kdyby snímač hlásil nesmysl, ať se nedělí nulou.
        val span = (params.whiteLevel - params.blackLevel).coerceAtLeast(1)

        // Gama i převod na osm bitů jsou pro všechny pixely stejné, takže se
        // spočítají jednou do tabulky. Bez ní by se u dvanácti megapixelů
        // počítala mocnina čtyřikrát pro každý pixel.
        val lut = buildGammaLut(gamma)

        val out = IntArray(width * height)
        for (y in 0 until height) {
            val yUp = if (y > 0) y - 1 else 1.coerceAtMost(height - 1)
            val yDown = if (y < height - 1) y + 1 else (height - 2).coerceAtLeast(0)
            val rowOffset = y * width
            val upOffset = yUp * width
            val downOffset = yDown * width

            for (x in 0 until width) {
                val xLeft = if (x > 0) x - 1 else 1.coerceAtMost(width - 1)
                val xRight = if (x < width - 1) x + 1 else (width - 2).coerceAtLeast(0)

                // Která složka je přímo na téhle buňce.
                val color = colorAt(x, y, params.pattern)
                val center = raw[rowOffset + x]

                val r: Int
                val g: Int
                val b: Int
                when (color) {
                    RED -> {
                        r = center
                        g = (raw[rowOffset + xLeft] + raw[rowOffset + xRight] +
                            raw[upOffset + x] + raw[downOffset + x]) shr 2
                        b = (raw[upOffset + xLeft] + raw[upOffset + xRight] +
                            raw[downOffset + xLeft] + raw[downOffset + xRight]) shr 2
                    }
                    BLUE -> {
                        b = center
                        g = (raw[rowOffset + xLeft] + raw[rowOffset + xRight] +
                            raw[upOffset + x] + raw[downOffset + x]) shr 2
                        r = (raw[upOffset + xLeft] + raw[upOffset + xRight] +
                            raw[downOffset + xLeft] + raw[downOffset + xRight]) shr 2
                    }
                    GREEN_ON_RED_ROW -> {
                        g = center
                        r = (raw[rowOffset + xLeft] + raw[rowOffset + xRight]) shr 1
                        b = (raw[upOffset + x] + raw[downOffset + x]) shr 1
                    }
                    else -> { // zelená na modrém řádku
                        g = center
                        b = (raw[rowOffset + xLeft] + raw[rowOffset + xRight]) shr 1
                        r = (raw[upOffset + x] + raw[downOffset + x]) shr 1
                    }
                }

                out[rowOffset + x] = toPixel(r, g, b, params, span, lut)
            }
        }
        return out
    }

    /** Odečte černou, vyrovná barvy a převede přes gamu na osm bitů. */
    private fun toPixel(
        r: Int,
        g: Int,
        b: Int,
        params: SensorParams,
        span: Int,
        lut: IntArray
    ): Int {
        val black = params.blackLevel
        val nr = ((r - black).coerceAtLeast(0) * params.gainR / span).coerceIn(0f, 1f)
        val ng = ((g - black).coerceAtLeast(0) * params.gainG / span).coerceIn(0f, 1f)
        val nb = ((b - black).coerceAtLeast(0) * params.gainB / span).coerceIn(0f, 1f)

        val ir = lut[(nr * LUT_MAX).toInt()]
        val ig = lut[(ng * LUT_MAX).toInt()]
        val ib = lut[(nb * LUT_MAX).toInt()]
        return (0xFF shl 24) or (ir shl 16) or (ig shl 8) or ib
    }

    /**
     * Tabulka převodu lineární hodnoty na osmibitovou s gamou.
     * Vstup je index 0..[LUT_MAX], výstup 0..255.
     */
    private fun buildGammaLut(gamma: Float): IntArray {
        val safeGamma = if (gamma <= 0f) DEFAULT_GAMMA else gamma
        val inverse = 1.0 / safeGamma
        return IntArray(LUT_SIZE) { i ->
            val linear = i.toDouble() / LUT_MAX
            (255.0 * Math.pow(linear, inverse)).toInt().coerceIn(0, 255)
        }
    }

    /** Vrátí, jakou složku snímá buňka na daných souřadnicích. */
    private fun colorAt(x: Int, y: Int, pattern: CfaPattern): Int {
        val evenRow = (y and 1) == 0
        val evenCol = (x and 1) == 0
        return when (pattern) {
            CfaPattern.RGGB -> when {
                evenRow && evenCol -> RED
                evenRow -> GREEN_ON_RED_ROW
                evenCol -> GREEN_ON_BLUE_ROW
                else -> BLUE
            }
            CfaPattern.BGGR -> when {
                evenRow && evenCol -> BLUE
                evenRow -> GREEN_ON_BLUE_ROW
                evenCol -> GREEN_ON_RED_ROW
                else -> RED
            }
            CfaPattern.GRBG -> when {
                evenRow && evenCol -> GREEN_ON_RED_ROW
                evenRow -> RED
                evenCol -> BLUE
                else -> GREEN_ON_BLUE_ROW
            }
            CfaPattern.GBRG -> when {
                evenRow && evenCol -> GREEN_ON_BLUE_ROW
                evenRow -> BLUE
                evenCol -> RED
                else -> GREEN_ON_RED_ROW
            }
        }
    }

    private const val RED = 0
    private const val GREEN_ON_RED_ROW = 1
    private const val GREEN_ON_BLUE_ROW = 2
    private const val BLUE = 3

    private const val LUT_SIZE = 4096
    private const val LUT_MAX = LUT_SIZE - 1

    /** Typický offset snímače; skutečnou hodnotu čteme ze zařízení. */
    private const val DEFAULT_BLACK_LEVEL = 64

    /** Horní mez desetibitového snímače. */
    private const val DEFAULT_WHITE_LEVEL = 1023

    // Výchozí vyvážení zhruba pro denní světlo. Skutečné hodnoty dodá snímač.
    private const val DEFAULT_GAIN_R = 1.9f
    private const val DEFAULT_GAIN_B = 1.6f

    /**
     * Noční snímky potřebují výraznější křivku než obvyklých 2.2, aby se
     * ze stínů vytáhlo, co v nich je.
     */
    const val DEFAULT_GAMMA = 2.4f
}
