package cz.hqsnet.aifoto.ui

import android.view.Surface
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import cz.hqsnet.aifoto.CameraViewModel
import cz.hqsnet.aifoto.analysis.SceneAnalyzer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

@Composable
fun CameraPreview(
    viewModel: CameraViewModel,
    modifier: Modifier = Modifier,
    overlay: @Composable (PreviewView) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val analyzer = remember(viewModel) { SceneAnalyzer(viewModel::onAdvice) }

    DisposableEffect(lifecycleOwner, previewView) {
        val disposed = AtomicBoolean(false)
        val providerFuture = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null

        providerFuture.addListener({
            if (disposed.get()) return@addListener
            try {
                provider = providerFuture.get()
                val preview = Preview.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                    .build()
                    .also { it.surfaceProvider = previewView.surfaceProvider }

                // Zjistíme, zda zařízení umí RAW (DNG). S22 Ultra a Pixely ano,
                // ale ověřujeme to - jinak tichý návrat k samotnému JPEG.
                val cameraInfo = provider?.getCameraInfo(CameraSelector.DEFAULT_BACK_CAMERA)
                val rawSupported = cameraInfo != null &&
                    ImageCapture.getImageCaptureCapabilities(cameraInfo)
                        .supportedOutputFormats
                        .contains(ImageCapture.OUTPUT_FORMAT_RAW_JPEG)

                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setTargetRotation(previewView.display?.rotation ?: Surface.ROTATION_0)
                    .apply {
                        // RAW+JPEG: JPEG pro rychlý náhled a sdílení,
                        // DNG pro maximum informace ve stínech (noční scény).
                        if (rawSupported) {
                            setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW_JPEG)
                        }
                    }
                    .build()

                val analysis = ImageAnalysis.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                    .build()
                    .also { it.setAnalyzer(cameraExecutor, analyzer) }

                provider?.unbindAll()

                // Jediný analysis use-case. Sběr snímků pro noční skládání jde
                // přes něj (frameSink v analyzeru), ne přes druhý bind - ten
                // se čtyřmi streamy na řadě zařízení selhal a noční režim pak
                // tiše nefungoval.
                val camera = provider?.bindToLifecycle(
                    lifecycleOwner,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    capture,
                    analysis
                )

                if (camera != null) {
                    // Most z ViewModelu do analyzeru: dodá stacker jako odběratele
                    // snímků, nebo ho odpojí (null). Po každém snímku hlásí postup.
                    viewModel.onStackerChanged = { stacker ->
                        analyzer.frameSink = if (stacker != null) {
                            { proxy ->
                                val done = stacker.addFrame(proxy)
                                viewModel.onStackProgress(stacker.progress, done)
                                done
                            }
                        } else {
                            null
                        }
                    }
                    viewModel.attachCamera(camera, capture, rawSupported, stackingSupported = true)
                }
            } catch (error: Throwable) {
                // Dříve se chyba spolkla a uživatel viděl jen černý náhled.
                viewModel.onCameraError(error.message)
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            disposed.set(true)
            viewModel.onStackerChanged = null
            analyzer.frameSink = null
            provider?.unbindAll()
            viewModel.detachCamera()
            analyzer.close()
            cameraExecutor.shutdown()
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(previewView) {
                    detectTapGestures { offset ->
                        viewModel.focusAt(previewView, offset.x, offset.y)
                    }
                }
        ) {
            overlay(previewView)
        }
    }
}
