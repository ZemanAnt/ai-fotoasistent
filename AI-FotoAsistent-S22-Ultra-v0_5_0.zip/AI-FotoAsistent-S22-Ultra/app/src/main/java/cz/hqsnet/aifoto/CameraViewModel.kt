package cz.hqsnet.aifoto

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cz.hqsnet.aifoto.capture.ExposureLock
import cz.hqsnet.aifoto.capture.FrameStacker
import cz.hqsnet.aifoto.capture.PostProcess
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val _advice = MutableStateFlow(SceneAdvice.Initial)
    val advice: StateFlow<SceneAdvice> = _advice.asStateFlow()

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<CameraEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<CameraEvent> = _events.asSharedFlow()

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var rawEnabled: Boolean = false

    // Noční skládání snímků (frame averaging).
    @Volatile private var activeStacker: FrameStacker? = null
    private var stackTimeoutJob: Job? = null
    /** Drží se zámek expozice? Musí se uvolnit na každé cestě ven. */
    private var exposureLocked = false
    /** Běží ruční expozice? Musí se vrátit na automatiku na každé cestě ven. */
    private var manualExposureActive = false
    /** Čas jednoho snímku při posledním nočním snímání - pro odhad délky. */
    private var lastExposureNanos = 0L


    fun attachCamera(
        camera: Camera,
        imageCapture: ImageCapture,
        rawSupported: Boolean = false,
        stackingSupported: Boolean = true
    ) {
        this.camera = camera
        this.imageCapture = imageCapture
        this.rawEnabled = rawSupported
        val zoomState = camera.cameraInfo.zoomState.value
        _uiState.update {
            it.copy(
                minZoom = zoomState?.minZoomRatio ?: 1f,
                maxZoom = zoomState?.maxZoomRatio ?: 10f,
                selectedZoom = zoomState?.zoomRatio ?: 1f,
                cameraReady = true
            )
        }
        applyFlashMode(_uiState.value.flashMode)
        _uiState.update {
            it.copy(
                torchAvailable = camera.cameraInfo.hasFlashUnit(),
                rawEnabled = rawSupported,
                stackingAvailable = stackingSupported
            )
        }
    }

    fun detachCamera() {
        releaseExposureLock()
        camera = null
        imageCapture = null
        activeStacker = null
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        _uiState.update { it.copy(cameraReady = false, stacking = false, stackProgress = 0f) }
    }

    /** Kamera se nepodařila spustit - dej o tom vědět místo tichého selhání. */
    fun onCameraError(reason: String?) {
        detachCamera()
        _events.tryEmit(
            CameraEvent.Message("Fotoaparát se nepodařilo spustit: ${reason ?: "neznámá chyba"}")
        )
    }

    fun onAdvice(advice: SceneAdvice) {
        _advice.value = advice
        // Pohyb se hlídá i během snímání. Snímky se nezarovnávají, takže
        // rozhýbaný telefon by dal rozmazaný výsledek - lepší je skončit hned
        // a říct proč, než uložit nepoužitelnou fotku.
        if (activeStacker != null && advice.metrics.motion > ABORT_STACK_MOTION) {
            cancelNightStack("Telefon se rozhýbal - noční snímání zrušeno.")
        }
    }

    fun setZoom(requestedZoom: Float) {
        val activeCamera = camera ?: return
        val state = activeCamera.cameraInfo.zoomState.value
        val min = state?.minZoomRatio ?: _uiState.value.minZoom
        val max = state?.maxZoomRatio ?: _uiState.value.maxZoom
        val zoom = requestedZoom.coerceIn(min, max)
        activeCamera.cameraControl.setZoomRatio(zoom)
        _uiState.update { it.copy(selectedZoom = zoom) }
    }

    fun applyCurrentAdvice() {
        val recommendation = _advice.value
        setZoom(recommendation.zoomRatio)
        applyExposureCompensation(recommendation.exposureCompensation)

        val flash = recommendedFlash(recommendation.scene)
        _uiState.update { it.copy(flashMode = flash) }
        applyFlashMode(flash)

        _events.tryEmit(
            CameraEvent.Message(
                "Použito: ${recommendation.lensLabel}, EV " +
                    "${formatEv(recommendation.exposureCompensation)}, ${flash.label}"
            )
        )
    }

    /**
     * Blesk má smysl jen u blízkých objektů. U vzdálených scén nedosvítí,
     * ale rozhodí měření expozice - typicky noční panorama vyfocené s ISO 2000+.
     *
     * Dříve spadaly do OFF všechny scény kromě PORTRAIT a GENERAL, takže se
     * u protisvětla nenavrhlo přisvícení, i když je to přesně ten případ,
     * kdy blesk pomůže (vyrovnání tmavého popředí).
     */
    private fun recommendedFlash(scene: SceneKind): FlashMode = when (scene) {
        // Blízké objekty - blesk dosvítí a pomůže.
        SceneKind.PORTRAIT, SceneKind.GENERAL, SceneKind.FOOD, SceneKind.MACRO, SceneKind.PET ->
            FlashMode.AUTO
        // Protisvětlo: popředí je tmavé, přisvícení je žádoucí.
        SceneKind.BACKLIGHT -> FlashMode.ON
        // Vzdálené nebo pohybové scény - blesk nedosvítí, jen rozhodí expozici.
        SceneKind.NIGHT, SceneKind.LANDSCAPE, SceneKind.ACTION,
        SceneKind.ARCHITECTURE, SceneKind.DOCUMENT -> FlashMode.OFF
    }

    private fun applyExposureCompensation(ev: Float) {
        val activeCamera = camera ?: return
        val exposureState = activeCamera.cameraInfo.exposureState
        if (!exposureState.isExposureCompensationSupported) return

        val step = exposureState.exposureCompensationStep.toFloat()
        if (step <= 0f) return
        val range = exposureState.exposureCompensationRange
        val index = (ev / step).roundToInt().coerceIn(range.lower, range.upper)
        activeCamera.cameraControl.setExposureCompensationIndex(index)
    }

    fun focusAt(previewView: PreviewView, x: Float, y: Float) {
        val activeCamera = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        )
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        activeCamera.cameraControl.startFocusAndMetering(action)
        _uiState.update { it.copy(focusPoint = FocusPoint(x, y), focusPulse = it.focusPulse + 1) }
    }

    fun cycleFlash() {
        val next = when (_uiState.value.flashMode) {
            FlashMode.OFF -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.ON
            FlashMode.ON -> FlashMode.OFF
        }
        _uiState.update { it.copy(flashMode = next) }
        applyFlashMode(next)
    }

    /**
     * Svítilna jako trvalé přisvícení. Na rozdíl od blesku nerozhodí měření
     * expozice - má smysl pro blízké objekty v noci (do ~2 m).
     */
    fun toggleTorch() {
        val activeCamera = camera ?: return
        if (!activeCamera.cameraInfo.hasFlashUnit()) {
            _events.tryEmit(CameraEvent.Message("Toto zařízení nemá svítilnu."))
            return
        }
        val next = !_uiState.value.torchOn
        activeCamera.cameraControl.enableTorch(next)
        _uiState.update { it.copy(torchOn = next) }
    }

    private fun applyFlashMode(mode: FlashMode) {
        imageCapture?.flashMode = when (mode) {
            FlashMode.OFF -> ImageCapture.FLASH_MODE_OFF
            FlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
            FlashMode.ON -> ImageCapture.FLASH_MODE_ON
        }
    }

    fun takePhoto(context: Context) {
        val capture = imageCapture
        if (capture == null) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (_uiState.value.isSaving || _uiState.value.stacking) return

        _uiState.update { it.copy(isSaving = true) }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val resolver = context.contentResolver
        val collection: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        fun values(mime: String) = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_Foto_$timestamp")
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
            }
        }

        val jpegOptions = ImageCapture.OutputFileOptions.Builder(
            resolver, collection, values("image/jpeg")
        ).build()

        if (rawEnabled) {
            // RAW+JPEG: callback přijde DVAKRÁT - zvlášť pro DNG a pro JPEG.
            // Stav "ukládám" vypneme až po druhém, hlášku pošleme jen jednou.
            val rawOptions = ImageCapture.OutputFileOptions.Builder(
                resolver, collection, values("image/x-adobe-dng")
            ).build()

            // Callbacky chodí na hlavní vlákno, takže prosté proměnné stačí.
            var remaining = 2
            var savedUri: Uri? = null
            var failure: String? = null

            fun settle() {
                if (remaining > 0) return
                _uiState.update { it.copy(isSaving = false) }
                val error = failure
                _events.tryEmit(
                    when {
                        // Aspoň jeden soubor se uložil - fotku uživatel má.
                        error != null && savedUri != null ->
                            CameraEvent.PhotoSaved(savedUri, "Uložen jen jeden formát: $error")
                        error != null ->
                            CameraEvent.Message("Fotografii se nepodařilo uložit: $error")
                        else ->
                            CameraEvent.PhotoSaved(
                                savedUri,
                                "Uloženo JPEG + RAW (DNG) do alba AI FotoAsistent."
                            )
                    }
                )
            }

            capture.takePicture(
                rawOptions,
                jpegOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        // Callback nerozlišuje, který formát dorazil. Pro otevření
                        // v galerii je vhodnější JPEG, takže si první URI necháme
                        // a přepíšeme ho jen tehdy, když ještě žádné nemáme.
                        if (savedUri == null) savedUri = outputFileResults.savedUri
                        remaining -= 1
                        settle()
                    }

                    override fun onError(exception: ImageCaptureException) {
                        // Dřív se po chybě jednoho formátu druhý callback nikdy
                        // nedopočítal a tlačítko spouště zůstalo zablokované.
                        failure = exception.message ?: "neznámá chyba"
                        remaining -= 1
                        settle()
                    }
                }
            )
        } else {
            capture.takePicture(
                jpegOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        val savedUri = outputFileResults.savedUri
                        val metrics = _advice.value.metrics
                        if (savedUri != null &&
                            PostProcess.isWorthEnhancing(metrics.meanLuma, metrics.shadowRatio)
                        ) {
                            enhanceSavedPhoto(context, savedUri)
                        } else {
                            _uiState.update { it.copy(isSaving = false) }
                            _events.tryEmit(
                                CameraEvent.PhotoSaved(
                                    savedUri,
                                    "Fotografie byla uložena do alba AI FotoAsistent."
                                )
                            )
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        _uiState.update { it.copy(isSaving = false) }
                        _events.tryEmit(
                            CameraEvent.Message("Fotografii se nepodařilo uložit: ${exception.message}")
                        )
                    }
                }
            )
        }
    }

    // ---------------------------------------------------------------------
    // Noční režim: skládání více snímků (frame averaging)
    // ---------------------------------------------------------------------

    /**
     * Spustí sběr N snímků, které se zprůměrují do jedné fotky. Šum je mezi
     * snímky nekorelovaný, takže průměr N snímků ho potlačí zhruba √N krát.
     *
     * Snímky se neregistrují (nezarovnávají), takže pohyb by se rozmazal -
     * proto se režim odmítne spustit, když scéna není dost klidná.
     */
    fun startNightStack() {
        if (activeStacker != null || _uiState.value.isSaving) return
        if (!_uiState.value.cameraReady) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (!_uiState.value.stackingAvailable) {
            _events.tryEmit(CameraEvent.Message("Noční skládání není na tomto zařízení dostupné."))
            return
        }

        val metrics = _advice.value.metrics
        if (metrics.motion > MAX_STACK_MOTION) {
            _events.tryEmit(
                CameraEvent.Message("Scéna se hýbe - noční režim potřebuje klidný záběr (opřete telefon).")
            )
            return
        }

        val frames = FrameStacker.recommendedFrames(metrics.meanLuma)
        val stacker = FrameStacker(targetFrames = frames)
        activeStacker = stacker

        val activeCamera = camera
        val activeCapture = imageCapture
        if (activeCamera == null || activeCapture == null) {
            activeStacker = null
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }

        // Delší expozice jednotlivých snímků je to hlavní, co dělá noční fotku
        // použitelnou. Snímky se berou z fotoaparátu (ImageCapture), který
        // ruční dlouhý čas respektuje - narozdíl od analytického streamu, jenž
        // běží na krátkém náhledovém čase, takže by výsledek zůstal tmavý.
        exposureLocked = if (ExposureLock.supportsManualExposure(activeCamera)) {
            val limits = ExposureLock.readLimits(activeCamera)
            val (exposure, iso) = ExposureLock.suggestExposure(metrics.meanLuma, limits)
            manualExposureActive = ExposureLock.setManualExposure(activeCamera, exposure, iso)
            if (manualExposureActive) lastExposureNanos = exposure
            manualExposureActive
        } else {
            lastExposureNanos = 0L
            ExposureLock.lock(activeCamera)
        }

        _uiState.update { it.copy(stacking = true, stackProgress = 0f) }
        val seconds = frames * lastExposureNanos / 1_000_000_000.0
        _events.tryEmit(
            CameraEvent.Message(
                if (seconds >= 1.0) {
                    "Noční režim: držte telefon v klidu asi %.0f s...".format(Locale.US, seconds)
                } else {
                    "Noční režim: držte telefon v klidu..."
                }
            )
        )

        // Sériové snímání: každý snímek se po dokončení uloží do stackeru a hned
        // se spustí další. Manuální expozice se aplikuje na tuto capture cestu.
        captureNextStackFrame(activeCapture, stacker)

        // Pojistka: kdyby se snímání zaseklo, po timeoutu zpracujeme, co je.
        stackTimeoutJob?.cancel()
        stackTimeoutJob = viewModelScope.launch {
            delay(STACK_TIMEOUT_MS)
            if (activeStacker === stacker) {
                if (stacker.collectedFrames >= MIN_USABLE_FRAMES) {
                    finishNightStack()
                } else {
                    cancelNightStack("Snímání se nepodařilo dokončit.")
                }
            }
        }
    }

    /**
     * Vyfotí jeden snímek do paměti, přidá ho do stackeru a pokud je potřeba
     * víc, spustí další. Snímky jdou přes ImageCapture, takže mají plné
     * rozlišení a drží nastavenou dlouhou expozici.
     */
    private fun captureNextStackFrame(capture: ImageCapture, stacker: FrameStacker) {
        val context = getApplication<Application>()
        capture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    if (activeStacker !== stacker) {
                        image.close()
                        return
                    }
                    val done = try {
                        val bitmap = image.toBitmap()
                        val rotation = image.imageInfo.rotationDegrees
                        val complete = stacker.addBitmap(bitmap, rotation)
                        bitmap.recycle()
                        complete
                    } catch (_: Throwable) {
                        true
                    } finally {
                        image.close()
                    }
                    _uiState.update { it.copy(stackProgress = stacker.progress) }
                    if (done) {
                        finishNightStack()
                    } else {
                        captureNextStackFrame(capture, stacker)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    // Když se snímek nepovede, dokončíme s tím, co máme.
                    if (activeStacker === stacker) {
                        if (stacker.collectedFrames >= MIN_USABLE_FRAMES) {
                            finishNightStack()
                        } else {
                            cancelNightStack("Noční snímek se nepodařilo pořídit.")
                        }
                    }
                }
            }
        )
    }

    /**
     * Uvolní zámek expozice. Kdyby zůstal, fotoaparát by dál držel jas
     * z okamžiku snímání a přestal reagovat na změnu světla.
     */
    private fun releaseExposureLock() {
        if (!exposureLocked && !manualExposureActive) return
        val activeCamera = camera
        if (manualExposureActive) {
            // Bez tohoto by fotoaparát zůstal na dlouhém času a další fotky
            // by byly rozmazané nebo přepálené.
            manualExposureActive = false
            lastExposureNanos = 0L
            activeCamera?.let { ExposureLock.clearManualExposure(it) }
        } else {
            activeCamera?.let { ExposureLock.unlock(it) }
        }
        exposureLocked = false
    }

    /** Zruší probíhající skládání a uvolní stav. */
    fun cancelNightStack(reason: String? = null) {
        val stacker = activeStacker ?: return
        activeStacker = null
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        releaseExposureLock()
        stacker.reset()
        _uiState.update { it.copy(stacking = false, stackProgress = 0f) }
        reason?.let { _events.tryEmit(CameraEvent.Message(it)) }
    }


    private fun finishNightStack() {
        val stacker = activeStacker ?: return
        activeStacker = null
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        releaseExposureLock()

        val frames = stacker.collectedFrames
        val rotation = stacker.rotationDegrees
        viewModelScope.launch(Dispatchers.Default) {
            val bitmap = stacker.buildBitmap()
            stacker.reset()

            if (bitmap == null) {
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(stacking = false, stackProgress = 0f) }
                    _events.tryEmit(CameraEvent.Message("Skládání snímků se nezdařilo."))
                }
                return@launch
            }

            val uri = saveStackedBitmap(getApplication(), bitmap, frames, rotation)
            bitmap.recycle()

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(stacking = false, stackProgress = 0f) }
                if (uri != null) {
                    _events.tryEmit(
                        CameraEvent.PhotoSaved(uri, "Noční snímek uložen - složeno z $frames snímků.")
                    )
                } else {
                    _events.tryEmit(CameraEvent.Message("Noční snímek se nepodařilo uložit."))
                }
            }
        }
    }

    private fun saveStackedBitmap(
        context: Context,
        bitmap: Bitmap,
        frames: Int,
        rotationDegrees: Int
    ): Uri? {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_Foto_${timestamp}_noc")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            writeStackExif(context, uri, frames, rotationDegrees)
            uri
        } catch (_: Throwable) {
            resolver.delete(uri, null, null)
            null
        }
    }

    /**
     * Doplní metadata do uložené fotky.
     *
     * Bez orientace by galerie zobrazila snímek otočený - analyzér dodává
     * obraz v orientaci snímače, ne v té, jak telefon držíme. Poznámka
     * o počtu složených snímků se hodí při pozdějším porovnávání výsledků.
     */
    private fun writeStackExif(context: Context, uri: Uri, frames: Int, rotationDegrees: Int) {
        try {
            context.contentResolver.openFileDescriptor(uri, "rw")?.use { descriptor ->
                val exif = ExifInterface(descriptor.fileDescriptor)
                exif.setAttribute(
                    ExifInterface.TAG_ORIENTATION,
                    when (rotationDegrees) {
                        90 -> ExifInterface.ORIENTATION_ROTATE_90
                        180 -> ExifInterface.ORIENTATION_ROTATE_180
                        270 -> ExifInterface.ORIENTATION_ROTATE_270
                        else -> ExifInterface.ORIENTATION_NORMAL
                    }.toString()
                )
                exif.setAttribute(ExifInterface.TAG_SOFTWARE, "AI FotoAsistent")
                exif.setAttribute(
                    ExifInterface.TAG_IMAGE_DESCRIPTION,
                    "Nocni rezim - slozeno z $frames snimku"
                )
                exif.setAttribute(
                    ExifInterface.TAG_DATETIME,
                    SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
                        .format(System.currentTimeMillis())
                )
                exif.saveAttributes()
            }
        } catch (_: Throwable) {
            // Metadata jsou doplněk - fotka je uložená i bez nich.
        }
    }

    /**
     * Dotáhne už uloženou fotku - odšumí a vytáhne stíny.
     *
     * Snímek se nejdřív uloží tak, jak přišel z fotoaparátu, a upraví se až
     * potom. Kdyby úprava selhala nebo na ni nebyla paměť, zůstane na disku
     * původní fotka, ne poškozený soubor.
     */
    private fun enhanceSavedPhoto(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.Default) {
            val enhanced = runCatching {
                val resolver = context.contentResolver
                val source = resolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                } ?: return@runCatching false

                try {
                    val width = source.width
                    val height = source.height
                    if (width <= 0 || height <= 0) return@runCatching false
                    // Úprava potřebuje několik mezikroků o velikosti snímku.
                    // U plného rozlišení by součet přesáhl dostupnou paměť,
                    // takže radši necháme fotku tak, jak ji uložil fotoaparát.
                    if (width.toLong() * height.toLong() > MAX_ENHANCE_PIXELS) {
                        return@runCatching false
                    }

                    val pixels = IntArray(width * height)
                    source.getPixels(pixels, 0, width, 0, 0, width, height)
                    // Dekódovaná bitmapa už není potřeba a zabírá tolik co
                    // celé pole pixelů - uvolníme ji dřív, než se alokují
                    // mezikroky úpravy.
                    source.recycle()

                    val adjusted = PostProcess.enhancePixels(pixels, width, height)

                    // Přepisujeme původní soubor, čímž se ztratí EXIF z
                    // fotoaparátu - orientaci si proto přečteme a vrátíme zpět,
                    // jinak by se snímek v galerii otočil.
                    val orientation = readOrientation(context, uri)
                    val output = Bitmap.createBitmap(
                        adjusted, width, height, Bitmap.Config.ARGB_8888
                    )
                    try {
                        resolver.openOutputStream(uri, "wt")?.use { stream ->
                            output.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                        } ?: return@runCatching false
                    } finally {
                        output.recycle()
                    }
                    restoreOrientation(context, uri, orientation)
                    true
                } finally {
                    source.recycle()
                }
            }.getOrDefault(false)

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(isSaving = false) }
                _events.tryEmit(
                    CameraEvent.PhotoSaved(
                        uri,
                        if (enhanced) {
                            "Fotografie uložena a dotažena (stíny a šum)."
                        } else {
                            "Fotografie byla uložena do alba AI FotoAsistent."
                        }
                    )
                )
            }
        }
    }

    private fun readOrientation(context: Context, uri: Uri): String? = try {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
            ExifInterface(descriptor.fileDescriptor)
                .getAttribute(ExifInterface.TAG_ORIENTATION)
        }
    } catch (_: Throwable) {
        null
    }

    private fun restoreOrientation(context: Context, uri: Uri, orientation: String?) {
        try {
            context.contentResolver.openFileDescriptor(uri, "rw")?.use { descriptor ->
                val exif = ExifInterface(descriptor.fileDescriptor)
                orientation?.let { exif.setAttribute(ExifInterface.TAG_ORIENTATION, it) }
                exif.setAttribute(ExifInterface.TAG_SOFTWARE, "AI FotoAsistent")
                exif.saveAttributes()
            }
        } catch (_: Throwable) {
            // Bez metadat je fotka pořád v pořádku.
        }
    }

    private fun formatEv(ev: Float): String = when {
        ev > 0f -> "+%.1f".format(Locale.US, ev)
        ev < 0f -> "%.1f".format(Locale.US, ev)
        else -> "0"
    }

    private companion object {
        /** Nad tuto hodnotu pohybu by se skládané snímky rozmazaly. */
        const val MAX_STACK_MOTION = 0.12f

        /**
         * Strop pro dokončovací úpravu uložené fotky. Úprava drží v paměti
         * několik polí o velikosti snímku; při 12 MPix je špička kolem 140 MB,
         * což ještě projde, ale výš už hrozí vyčerpání paměti.
         */
        const val MAX_ENHANCE_PIXELS = 12_500_000L

        /**
         * Práh pro přerušení už běžícího snímání. Je vyšší než vstupní, aby
         * drobné chvění nezrušilo snímání hned po startu - zrušit se má až
         * zjevný pohyb, ne mikroskopické zachvění ruky.
         */
        const val ABORT_STACK_MOTION = 0.22f

        /** Po této době snímání ukončíme, i když nedorazily všechny snímky. */
        const val STACK_TIMEOUT_MS = 15_000L

        /** Méně snímků už šum znatelně nepotlačí, výsledek by nestál za to. */
        const val MIN_USABLE_FRAMES = 3
    }
}

data class CameraUiState(
    val cameraReady: Boolean = false,
    val selectedZoom: Float = 1f,
    val minZoom: Float = 1f,
    val maxZoom: Float = 10f,
    val flashMode: FlashMode = FlashMode.OFF,
    val torchOn: Boolean = false,
    val torchAvailable: Boolean = false,
    val rawEnabled: Boolean = false,
    val isSaving: Boolean = false,
    val focusPoint: FocusPoint? = null,
    val focusPulse: Int = 0,
    /** Probíhá noční skládání snímků. */
    val stacking: Boolean = false,
    /** Postup skládání 0f..1f. */
    val stackProgress: Float = 0f,
    /** Zařízení uneslo bind se sběrem snímků pro noční režim. */
    val stackingAvailable: Boolean = false
)

data class FocusPoint(val x: Float, val y: Float)

enum class FlashMode(val label: String) {
    OFF("Blesk vyp."),
    AUTO("Blesk auto"),
    ON("Blesk zap.")
}

sealed interface CameraEvent {
    data class Message(val text: String) : CameraEvent
    data class PhotoSaved(val uri: Uri?, val text: String) : CameraEvent
}
