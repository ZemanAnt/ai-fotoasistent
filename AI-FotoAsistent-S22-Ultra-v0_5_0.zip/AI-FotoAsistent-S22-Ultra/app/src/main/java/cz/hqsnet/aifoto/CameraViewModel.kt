package cz.hqsnet.aifoto

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cz.hqsnet.aifoto.capture.FrameStacker
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val _advice = MutableStateFlow(SceneAdvice.Initial)
    val advice: StateFlow<SceneAdvice> = _advice.asStateFlow()

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<CameraEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<CameraEvent> = _events.asSharedFlow()

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var rawEnabled: Boolean = false

    // Noční skládání snímků (frame averaging).
    @Volatile private var activeStacker: FrameStacker? = null
    private var stackTimeoutJob: Job? = null

    /**
     * Most do StackAnalyzeru v CameraPreview. Non-null stacker znamená "sbírej
     * snímky", null znamená "přestaň". Nastavuje CameraPreview při bindu.
     */
    var onStackerChanged: ((FrameStacker?) -> Unit)? = null

    fun attachCamera(
        camera: Camera,
        imageCapture: ImageCapture,
        rawSupported: Boolean = false,
        stackingSupported: Boolean = true
    ) {
        this.camera = camera
        this.imageCapture = imageCapture
        this.rawEnabled = rawSupported
        val zoomState = camera.cameraInfo.zoomState.value
        _uiState.update {
            it.copy(
                minZoom = zoomState?.minZoomRatio ?: 1f,
                maxZoom = zoomState?.maxZoomRatio ?: 10f,
                selectedZoom = zoomState?.zoomRatio ?: 1f,
                cameraReady = true
            )
        }
        applyFlashMode(_uiState.value.flashMode)
        _uiState.update {
            it.copy(
                torchAvailable = camera.cameraInfo.hasFlashUnit(),
                rawEnabled = rawSupported,
                stackingAvailable = stackingSupported
            )
        }
    }

    fun detachCamera() {
        camera = null
        imageCapture = null
        activeStacker = null
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        _uiState.update { it.copy(cameraReady = false, stacking = false, stackProgress = 0f) }
    }

    /** Kamera se nepodařila spustit - dej o tom vědět místo tichého selhání. */
    fun onCameraError(reason: String?) {
        detachCamera()
        _events.tryEmit(
            CameraEvent.Message("Fotoaparát se nepodařilo spustit: ${reason ?: "neznámá chyba"}")
        )
    }

    fun onAdvice(advice: SceneAdvice) {
        _advice.value = advice
    }

    fun setZoom(requestedZoom: Float) {
        val activeCamera = camera ?: return
        val state = activeCamera.cameraInfo.zoomState.value
        val min = state?.minZoomRatio ?: _uiState.value.minZoom
        val max = state?.maxZoomRatio ?: _uiState.value.maxZoom
        val zoom = requestedZoom.coerceIn(min, max)
        activeCamera.cameraControl.setZoomRatio(zoom)
        _uiState.update { it.copy(selectedZoom = zoom) }
    }

    fun applyCurrentAdvice() {
        val recommendation = _advice.value
        setZoom(recommendation.zoomRatio)
        applyExposureCompensation(recommendation.exposureCompensation)

        val flash = recommendedFlash(recommendation.scene)
        _uiState.update { it.copy(flashMode = flash) }
        applyFlashMode(flash)

        _events.tryEmit(
            CameraEvent.Message(
                "Použito: ${recommendation.lensLabel}, EV " +
                    "${formatEv(recommendation.exposureCompensation)}, ${flash.label}"
            )
        )
    }

    /**
     * Blesk má smysl jen u blízkých objektů. U vzdálených scén nedosvítí,
     * ale rozhodí měření expozice - typicky noční panorama vyfocené s ISO 2000+.
     *
     * Dříve spadaly do OFF všechny scény kromě PORTRAIT a GENERAL, takže se
     * u protisvětla nenavrhlo přisvícení, i když je to přesně ten případ,
     * kdy blesk pomůže (vyrovnání tmavého popředí).
     */
    private fun recommendedFlash(scene: SceneKind): FlashMode = when (scene) {
        // Blízké objekty - blesk dosvítí a pomůže.
        SceneKind.PORTRAIT, SceneKind.GENERAL, SceneKind.FOOD, SceneKind.MACRO, SceneKind.PET ->
            FlashMode.AUTO
        // Protisvětlo: popředí je tmavé, přisvícení je žádoucí.
        SceneKind.BACKLIGHT -> FlashMode.ON
        // Vzdálené nebo pohybové scény - blesk nedosvítí, jen rozhodí expozici.
        SceneKind.NIGHT, SceneKind.LANDSCAPE, SceneKind.ACTION,
        SceneKind.ARCHITECTURE, SceneKind.DOCUMENT -> FlashMode.OFF
    }

    private fun applyExposureCompensation(ev: Float) {
        val activeCamera = camera ?: return
        val exposureState = activeCamera.cameraInfo.exposureState
        if (!exposureState.isExposureCompensationSupported) return

        val step = exposureState.exposureCompensationStep.toFloat()
        if (step <= 0f) return
        val range = exposureState.exposureCompensationRange
        val index = (ev / step).roundToInt().coerceIn(range.lower, range.upper)
        activeCamera.cameraControl.setExposureCompensationIndex(index)
    }

    fun focusAt(previewView: PreviewView, x: Float, y: Float) {
        val activeCamera = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        )
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        activeCamera.cameraControl.startFocusAndMetering(action)
        _uiState.update { it.copy(focusPoint = FocusPoint(x, y), focusPulse = it.focusPulse + 1) }
    }

    fun cycleFlash() {
        val next = when (_uiState.value.flashMode) {
            FlashMode.OFF -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.ON
            FlashMode.ON -> FlashMode.OFF
        }
        _uiState.update { it.copy(flashMode = next) }
        applyFlashMode(next)
    }

    /**
     * Svítilna jako trvalé přisvícení. Na rozdíl od blesku nerozhodí měření
     * expozice - má smysl pro blízké objekty v noci (do ~2 m).
     */
    fun toggleTorch() {
        val activeCamera = camera ?: return
        if (!activeCamera.cameraInfo.hasFlashUnit()) {
            _events.tryEmit(CameraEvent.Message("Toto zařízení nemá svítilnu."))
            return
        }
        val next = !_uiState.value.torchOn
        activeCamera.cameraControl.enableTorch(next)
        _uiState.update { it.copy(torchOn = next) }
    }

    private fun applyFlashMode(mode: FlashMode) {
        imageCapture?.flashMode = when (mode) {
            FlashMode.OFF -> ImageCapture.FLASH_MODE_OFF
            FlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
            FlashMode.ON -> ImageCapture.FLASH_MODE_ON
        }
    }

    fun takePhoto(context: Context) {
        val capture = imageCapture
        if (capture == null) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (_uiState.value.isSaving || _uiState.value.stacking) return

        _uiState.update { it.copy(isSaving = true) }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val resolver = context.contentResolver
        val collection: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        fun values(mime: String) = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_Foto_$timestamp")
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
            }
        }

        val jpegOptions = ImageCapture.OutputFileOptions.Builder(
            resolver, collection, values("image/jpeg")
        ).build()

        if (rawEnabled) {
            // RAW+JPEG: callback přijde DVAKRÁT - zvlášť pro DNG a pro JPEG.
            // Stav "ukládám" vypneme až po druhém, hlášku pošleme jen jednou.
            val rawOptions = ImageCapture.OutputFileOptions.Builder(
                resolver, collection, values("image/x-adobe-dng")
            ).build()

            // Callbacky chodí na hlavní vlákno, takže prosté proměnné stačí.
            var remaining = 2
            var savedUri: Uri? = null
            var failure: String? = null

            fun settle() {
                if (remaining > 0) return
                _uiState.update { it.copy(isSaving = false) }
                val error = failure
                _events.tryEmit(
                    when {
                        // Aspoň jeden soubor se uložil - fotku uživatel má.
                        error != null && savedUri != null ->
                            CameraEvent.PhotoSaved(savedUri, "Uložen jen jeden formát: $error")
                        error != null ->
                            CameraEvent.Message("Fotografii se nepodařilo uložit: $error")
                        else ->
                            CameraEvent.PhotoSaved(
                                savedUri,
                                "Uloženo JPEG + RAW (DNG) do alba AI FotoAsistent."
                            )
                    }
                )
            }

            capture.takePicture(
                rawOptions,
                jpegOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        // Callback nerozlišuje, který formát dorazil. Pro otevření
                        // v galerii je vhodnější JPEG, takže si první URI necháme
                        // a přepíšeme ho jen tehdy, když ještě žádné nemáme.
                        if (savedUri == null) savedUri = outputFileResults.savedUri
                        remaining -= 1
                        settle()
                    }

                    override fun onError(exception: ImageCaptureException) {
                        // Dřív se po chybě jednoho formátu druhý callback nikdy
                        // nedopočítal a tlačítko spouště zůstalo zablokované.
                        failure = exception.message ?: "neznámá chyba"
                        remaining -= 1
                        settle()
                    }
                }
            )
        } else {
            capture.takePicture(
                jpegOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        _uiState.update { it.copy(isSaving = false) }
                        _events.tryEmit(
                            CameraEvent.PhotoSaved(
                                outputFileResults.savedUri,
                                "Fotografie byla uložena do alba AI FotoAsistent."
                            )
                        )
                    }

                    override fun onError(exception: ImageCaptureException) {
                        _uiState.update { it.copy(isSaving = false) }
                        _events.tryEmit(
                            CameraEvent.Message("Fotografii se nepodařilo uložit: ${exception.message}")
                        )
                    }
                }
            )
        }
    }

    // ---------------------------------------------------------------------
    // Noční režim: skládání více snímků (frame averaging)
    // ---------------------------------------------------------------------

    /**
     * Spustí sběr N snímků, které se zprůměrují do jedné fotky. Šum je mezi
     * snímky nekorelovaný, takže průměr N snímků ho potlačí zhruba √N krát.
     *
     * Snímky se neregistrují (nezarovnávají), takže pohyb by se rozmazal -
     * proto se režim odmítne spustit, když scéna není dost klidná.
     */
    fun startNightStack() {
        if (activeStacker != null || _uiState.value.isSaving) return
        if (!_uiState.value.cameraReady) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (!_uiState.value.stackingAvailable) {
            _events.tryEmit(CameraEvent.Message("Noční skládání není na tomto zařízení dostupné."))
            return
        }

        val metrics = _advice.value.metrics
        if (metrics.motion > MAX_STACK_MOTION) {
            _events.tryEmit(
                CameraEvent.Message("Scéna se hýbe - noční režim potřebuje klidný záběr (opřete telefon).")
            )
            return
        }

        val frames = FrameStacker.recommendedFrames(metrics.meanLuma)
        val stacker = FrameStacker(targetFrames = frames)
        activeStacker = stacker
        _uiState.update { it.copy(stacking = true, stackProgress = 0f) }
        _events.tryEmit(CameraEvent.Message("Noční režim: držte telefon v klidu, snímám $frames snímků..."))
        onStackerChanged?.invoke(stacker)

        // Kdyby analyzer přestal dodávat snímky (zakrytý objektiv, přerušená
        // session), zůstalo by UI zablokované ve stavu "snímám". Po timeoutu
        // zpracujeme, co se stihlo nasbírat.
        stackTimeoutJob?.cancel()
        stackTimeoutJob = viewModelScope.launch {
            delay(STACK_TIMEOUT_MS)
            if (activeStacker === stacker) {
                if (stacker.collectedFrames >= MIN_USABLE_FRAMES) {
                    finishNightStack()
                } else {
                    cancelNightStack("Snímání se nepodařilo dokončit.")
                }
            }
        }
    }

    /** Zruší probíhající skládání a uvolní stav. */
    fun cancelNightStack(reason: String? = null) {
        val stacker = activeStacker ?: return
        activeStacker = null
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        onStackerChanged?.invoke(null)
        stacker.reset()
        _uiState.update { it.copy(stacking = false, stackProgress = 0f) }
        reason?.let { _events.tryEmit(CameraEvent.Message(it)) }
    }

    /** Volá StackAnalyzer po každém nasbíraném snímku. */
    fun onStackProgress(progress: Float, done: Boolean) {
        _uiState.update { it.copy(stackProgress = progress) }
        if (done) finishNightStack()
    }

    private fun finishNightStack() {
        val stacker = activeStacker ?: return
        activeStacker = null
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        onStackerChanged?.invoke(null)

        viewModelScope.launch(Dispatchers.Default) {
            val bitmap = stacker.buildBitmap()
            stacker.reset()

            if (bitmap == null) {
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(stacking = false, stackProgress = 0f) }
                    _events.tryEmit(CameraEvent.Message("Skládání snímků se nezdařilo."))
                }
                return@launch
            }

            val uri = saveStackedBitmap(getApplication(), bitmap)
            bitmap.recycle()

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(stacking = false, stackProgress = 0f) }
                if (uri != null) {
                    _events.tryEmit(
                        CameraEvent.PhotoSaved(uri, "Noční snímek uložen (složeno z více expozic).")
                    )
                } else {
                    _events.tryEmit(CameraEvent.Message("Noční snímek se nepodařilo uložit."))
                }
            }
        }
    }

    private fun saveStackedBitmap(context: Context, bitmap: Bitmap): Uri? {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_Foto_${timestamp}_noc")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
            uri
        } catch (_: Throwable) {
            resolver.delete(uri, null, null)
            null
        }
    }

    private fun formatEv(ev: Float): String = when {
        ev > 0f -> "+%.1f".format(Locale.US, ev)
        ev < 0f -> "%.1f".format(Locale.US, ev)
        else -> "0"
    }

    private companion object {
        /** Nad tuto hodnotu pohybu by se skládané snímky rozmazaly. */
        const val MAX_STACK_MOTION = 0.12f

        /** Po této době snímání ukončíme, i když nedorazily všechny snímky. */
        const val STACK_TIMEOUT_MS = 15_000L

        /** Méně snímků už šum znatelně nepotlačí, výsledek by nestál za to. */
        const val MIN_USABLE_FRAMES = 3
    }
}

data class CameraUiState(
    val cameraReady: Boolean = false,
    val selectedZoom: Float = 1f,
    val minZoom: Float = 1f,
    val maxZoom: Float = 10f,
    val flashMode: FlashMode = FlashMode.OFF,
    val torchOn: Boolean = false,
    val torchAvailable: Boolean = false,
    val rawEnabled: Boolean = false,
    val isSaving: Boolean = false,
    val focusPoint: FocusPoint? = null,
    val focusPulse: Int = 0,
    /** Probíhá noční skládání snímků. */
    val stacking: Boolean = false,
    /** Postup skládání 0f..1f. */
    val stackProgress: Float = 0f,
    /** Zařízení uneslo bind se sběrem snímků pro noční režim. */
    val stackingAvailable: Boolean = false
)

data class FocusPoint(val x: Float, val y: Float)

enum class FlashMode(val label: String) {
    OFF("Blesk vyp."),
    AUTO("Blesk auto"),
    ON("Blesk zap.")
}

sealed interface CameraEvent {
    data class Message(val text: String) : CameraEvent
    data class PhotoSaved(val uri: Uri?, val text: String) : CameraEvent
}
