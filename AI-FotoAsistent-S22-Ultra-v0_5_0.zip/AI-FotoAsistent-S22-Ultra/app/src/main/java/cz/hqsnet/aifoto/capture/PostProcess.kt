package cz.hqsnet.aifoto.capture

import kotlin.math.abs
import kotlin.math.exp

/**
 * Dokončovací úpravy složeného nočního snímku.
 *
 * Pracuje jen na jasové složce, aby se nerozhodily barvy. Pořadí kroků je
 * podstatné: nejdřív odšumění, teprve pak zesílení kontrastu. Obráceně by
 * CLAHE zesílil i šum - měření na složeném snímku ukázalo, že samotný CLAHE
 * zhorší poměr signál/šum zhruba na polovinu, kdežto s předřazeným
 * odšuměním vyjde výsledek asi dvakrát lepší než bez úprav.
 *
 * Záměrně tu není žádné dopočítávání chybějících detailů. Skládání má
 * zachytit, co na scéně bylo, ne domyslet, co tam mohlo být.
 */
object PostProcess {

    /**
     * Odšumí jasovou rovinu a zesílí místní kontrast.
     *
     * @param luma jasová rovina 0..255, mění se na místě není - vrací nové pole
     * @param strength 0f = beze změny, 1f = plná síla. Výchozí 0.75 vychází
     *   z měření: dá zhruba 1.6x vyšší kontrast při dvojnásobně lepším poměru
     *   signál/šum, kdežto plná síla sice kontrast zvedne víc, ale zisk v šumu
     *   zahodí.
     */
    fun enhance(
        luma: IntArray,
        width: Int,
        height: Int,
        strength: Float = DEFAULT_STRENGTH
    ): IntArray {
        if (strength <= 0f || width <= 0 || height <= 0) return luma
        val denoised = bilateral(luma, width, height)
        val clipLimit = 1f + (CLIP_LIMIT - 1f) * strength.coerceIn(0f, 1f)
        return clahe(denoised, width, height, clipLimit)
    }

    /**
     * Bilaterální filtr - průměruje okolí, ale sousedy s odlišným jasem váží
     * méně. Šum se tak vyhladí a hrany zůstanou ostré, na rozdíl od prostého
     * rozmazání.
     */
    fun bilateral(
        src: IntArray,
        width: Int,
        height: Int,
        radius: Int = RADIUS,
        sigmaSpace: Float = SIGMA_SPACE,
        sigmaRange: Float = SIGMA_RANGE
    ): IntArray {
        val out = IntArray(src.size)
        val side = 2 * radius + 1

        // Váhy podle vzdálenosti jsou pro všechny pixely stejné, stačí je
        // spočítat jednou. Totéž pro váhy podle rozdílu jasu - těch je 256.
        val spaceWeights = FloatArray(side * side)
        var index = 0
        for (dy in -radius..radius) {
            for (dx in -radius..radius) {
                spaceWeights[index++] =
                    exp(-(dx * dx + dy * dy) / (2f * sigmaSpace * sigmaSpace))
            }
        }
        val rangeWeights = FloatArray(256)
        for (diff in 0..255) {
            rangeWeights[diff] = exp(-(diff * diff) / (2f * sigmaRange * sigmaRange))
        }

        for (y in 0 until height) {
            for (x in 0 until width) {
                val center = src[y * width + x]
                var sum = 0f
                var weightSum = 0f
                var k = 0
                for (dy in -radius..radius) {
                    val sy = (y + dy).coerceIn(0, height - 1)
                    val rowOffset = sy * width
                    for (dx in -radius..radius) {
                        val sx = (x + dx).coerceIn(0, width - 1)
                        val value = src[rowOffset + sx]
                        val weight = spaceWeights[k++] * rangeWeights[abs(value - center)]
                        sum += value * weight
                        weightSum += weight
                    }
                }
                out[y * width + x] =
                    if (weightSum > 0f) (sum / weightSum).toInt().coerceIn(0, 255) else center
            }
        }
        return out
    }

    /**
     * CLAHE - vyrovnání histogramu po dlaždicích s omezením kontrastu.
     *
     * Noční snímek využívá jen malou část jasového rozsahu, takže detaily
     * splývají. Vyrovnání po dlaždicích je vytáhne i tam, kde by celkové
     * vyrovnání nepomohlo. Omezení (clip) brání tomu, aby se v ploché oblasti
     * zesílil šum do zrnitosti.
     */
    fun clahe(
        src: IntArray,
        width: Int,
        height: Int,
        clipLimit: Float = CLIP_LIMIT,
        tiles: Int = TILES
    ): IntArray {
        val out = IntArray(src.size)
        val tileW = (width + tiles - 1) / tiles
        val tileH = (height + tiles - 1) / tiles
        val maps = Array(tiles) { Array(tiles) { IntArray(256) } }

        for (ty in 0 until tiles) {
            for (tx in 0 until tiles) {
                val histogram = IntArray(256)
                var count = 0
                val x0 = tx * tileW
                val x1 = minOf(x0 + tileW, width)
                val y0 = ty * tileH
                val y1 = minOf(y0 + tileH, height)
                for (y in y0 until y1) {
                    val rowOffset = y * width
                    for (x in x0 until x1) {
                        histogram[src[rowOffset + x]]++
                        count++
                    }
                }
                val map = maps[ty][tx]
                if (count == 0) {
                    for (i in 0..255) map[i] = i
                    continue
                }
                // Useknout špičky histogramu a přebytek rozdělit rovnoměrně -
                // bez toho by se v jednolitých plochách zesílil šum.
                val limit = maxOf(1, (clipLimit * count / 256).toInt())
                var excess = 0
                for (i in 0..255) {
                    if (histogram[i] > limit) {
                        excess += histogram[i] - limit
                        histogram[i] = limit
                    }
                }
                val bonus = excess / 256
                // Normalizovat je nutné skutečným součtem po ořezu, ne původním
                // počtem pixelů. Celočíselné dělení při rozdělování přebytku
                // část hodnot zahodí, takže by mapa nedosáhla 255 a snímek by
                // po "zesvětlení" naopak ztmavl.
                var total = 0
                for (i in 0..255) {
                    histogram[i] += bonus
                    total += histogram[i]
                }
                if (total <= 0) {
                    for (i in 0..255) map[i] = i
                    continue
                }
                var cumulative = 0
                for (i in 0..255) {
                    cumulative += histogram[i]
                    map[i] = (255 * cumulative / total).coerceIn(0, 255)
                }
            }
        }

        // Mezi dlaždicemi interpolujeme, jinak by na jejich hranicích vznikly
        // viditelné čtverce.
        for (y in 0 until height) {
            val fy = y.toFloat() / tileH - 0.5f
            val ty0 = fy.toInt().coerceIn(0, tiles - 1)
            val ty1 = (ty0 + 1).coerceAtMost(tiles - 1)
            val wy = (fy - ty0).coerceIn(0f, 1f)
            for (x in 0 until width) {
                val fx = x.toFloat() / tileW - 0.5f
                val tx0 = fx.toInt().coerceIn(0, tiles - 1)
                val tx1 = (tx0 + 1).coerceAtMost(tiles - 1)
                val wx = (fx - tx0).coerceIn(0f, 1f)

                val value = src[y * width + x]
                val a = maps[ty0][tx0][value].toFloat()
                val b = maps[ty0][tx1][value].toFloat()
                val c = maps[ty1][tx0][value].toFloat()
                val d = maps[ty1][tx1][value].toFloat()
                val top = a + (b - a) * wx
                val bottom = c + (d - c) * wx
                out[y * width + x] = (top + (bottom - top) * wy).toInt().coerceIn(0, 255)
            }
        }
        return out
    }

    /** Ověřeno měřením - viz komentář u [enhance]. */
    const val DEFAULT_STRENGTH = 0.75f

    private const val RADIUS = 2
    private const val SIGMA_SPACE = 2f
    private const val SIGMA_RANGE = 20f

    /** Nad ~2.5 začne být výsledek nepřirozeně tvrdý. */
    private const val CLIP_LIMIT = 2.5f
    private const val TILES = 8
}
