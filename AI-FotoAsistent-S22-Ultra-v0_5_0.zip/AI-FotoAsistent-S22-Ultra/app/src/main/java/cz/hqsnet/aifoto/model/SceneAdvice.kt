package cz.hqsnet.aifoto.model

enum class SceneKind(val displayName: String) {
    GENERAL("Univerzální scéna"),
    PORTRAIT("Portrét"),
    NIGHT("Noční scéna"),
    LANDSCAPE("Krajina"),
    FOOD("Jídlo"),
    DOCUMENT("Dokument"),
    ARCHITECTURE("Architektura"),
    ACTION("Pohyb / sport"),
    PET("Zvíře"),
    MACRO("Detail / makro"),
    BACKLIGHT("Silné protisvětlo")
}

data class FrameMetrics(
    val meanLuma: Float = 128f,
    val contrast: Float = 0f,
    val shadowRatio: Float = 0f,
    val highlightRatio: Float = 0f,
    val motion: Float = 0f,
    val edgeEnergy: Float = 0f,
    val histogram: List<Float> = List(16) { 0f },
    /**
     * Mapa přepálených míst na vzorkovací mřížce (true = vypálené světlo).
     * Slouží k jejich zvýraznění v hledáčku, aby si jich fotograf všiml
     * dřív než doma - z přepálené oblasti už se detail vytáhnout nedá.
     */
    val clipMask: List<Boolean> = emptyList(),
    val clipMaskWidth: Int = 0,
    val clipMaskHeight: Int = 0
)

data class SceneAdvice(
    val scene: SceneKind = SceneKind.GENERAL,
    val confidence: Float = 0f,
    val zoomRatio: Float = 1f,
    val lensLabel: String = "1× hlavní",
    val shutter: String = "Auto",
    val iso: String = "Auto",
    val exposureCompensation: Float = 0f,
    val whiteBalance: String = "Auto",
    val focus: String = "Průběžné AF",
    val hdr: String = "Auto",
    val mainTip: String = "Držte telefon klidně a klepněte na hlavní objekt.",
    val secondaryTip: String = "AI průběžně vyhodnocuje světlo, pohyb a obsah scény.",
    val metrics: FrameMetrics = FrameMetrics(),
    val labels: List<String> = emptyList()
) {
    companion object {
        val Initial = SceneAdvice(
            confidence = 0f,
            mainTip = "Namiřte fotoaparát na scénu. Doporučení se objeví během okamžiku.",
            secondaryTip = "Analýza probíhá přímo v telefonu."
        )
    }
}
