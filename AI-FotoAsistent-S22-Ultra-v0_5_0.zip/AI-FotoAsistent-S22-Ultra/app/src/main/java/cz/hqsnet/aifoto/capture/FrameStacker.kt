package cz.hqsnet.aifoto.capture

import android.graphics.Bitmap
import android.graphics.ImageFormat
import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer

/**
 * Průměrování N snímků pro potlačení šumu (temporal denoise).
 *
 * Sbírá luma (Y) + chroma (U/V) roviny z [ImageProxy] do 32bit akumulátorů,
 * na konci dělí počtem snímků a převádí na RGB [Bitmap]. Šum je nekorelovaný
 * mezi snímky, takže průměr N snímků snižuje jeho směrodatnou odchylku ~√N krát
 * (8 snímků ≈ 2,8× méně šumu, 16 snímků ≈ 4×).
 *
 * Předpoklad: statická scéna (telefon na opoře). Bez zarovnávání snímků –
 * pohyb by způsobil rozmazání. Aktivuj jen když FrameMetrics.motion je nízké.
 *
 * Verze bez Camera2/RenderScript – běží přímo na YUV_420_888 z existujícího
 * ImageAnalysis pipeline. Pro RAW/DNG stacking viz komentář na konci souboru.
 */
class FrameStacker(
    private val targetFrames: Int = 8
) {
    private var width = 0
    private var height = 0

    // Akumulátory (long kvůli přetečení: 16× hodnota do 255 = max 4080, ale
    // u větších N a případného scaleu je long bezpečný).
    private var accY: IntArray? = null
    private var accU: IntArray? = null
    private var accV: IntArray? = null

    // RGB akumulátory pro skládání z ImageCapture (JPEG dekódovaný na bitmapu).
    // Snímky z fotoaparátu mají plné rozlišení a respektují ruční expozici,
    // narozdíl od analytického streamu, který běží na krátkém náhledovém čase.
    private var accR: IntArray? = null
    private var accG: IntArray? = null
    private var accB: IntArray? = null
    /** Váhy pixelů (fixed-point, 256 = jeden plný snímek) pro odmítání výchylek. */
    private var accW: IntArray? = null
    private var rgbMode = false

    /** Akumulátor surových dat ze snímače (Bayerova mřížka, jedna rovina). */
    private var accRaw: IntArray? = null
    private var rawMode = false

    /** Parametry snímače pro převod surových dat na obraz. */
    var sensorParams: RawProcessor.SensorParams? = null

    private var collected = 0

    /** Orientace snímače u prvního snímku - potřebná pro EXIF. */
    var rotationDegrees = 0
        private set

    /** Počet zatím nasbíraných snímků. */
    val collectedFrames: Int get() = collected

    val progress: Float get() = if (targetFrames == 0) 1f else collected.toFloat() / targetFrames
    val isComplete: Boolean get() = collected >= targetFrames

    /**
     * Přidá jeden snímek do akumulátoru. Vrací true, když je nasbíráno dost
     * snímků a lze volat [buildBitmap]. Volající je zodpovědný za zavření
     * [ImageProxy] (typicky ve finally analyzeru).
     */
    fun addFrame(image: ImageProxy): Boolean {
        // Bez této pojistky by další snímky přetekly přes cílový počet a
        // zkreslily průměr, kdyby analyzer dodal snímek po dokončení.
        if (isComplete) return true
        if (image.format != ImageFormat.YUV_420_888) return isComplete
        val planes = image.planes
        if (planes.size < 3) return isComplete

        val w = image.width
        val h = image.height

        if (accY == null) {
            // Tři akumulátory zabírají zhruba 6 bajtů na pixel. U velmi velkých
            // snímků raději skončíme, než abychom riskovali OutOfMemoryError
            // uprostřed snímání.
            val requiredBytes = w.toLong() * h.toLong() * 6L
            if (requiredBytes > MAX_ACCUMULATOR_BYTES) return true
            try {
                accY = IntArray(w * h)
                accU = IntArray((w / 2) * (h / 2))
                accV = IntArray((w / 2) * (h / 2))
            } catch (_: OutOfMemoryError) {
                reset()
                return true
            }
            width = w
            height = h
            rotationDegrees = image.imageInfo.rotationDegrees
        } else if (w != width || h != height) {
            // Rozměr se změnil (rotace/reconfigure) – reset, ať se pole neroz cházejí.
            reset()
            return addFrame(image)
        }

        accumulatePlane(planes[0].buffer, planes[0].rowStride, planes[0].pixelStride, w, h, accY!!)
        accumulatePlane(planes[1].buffer, planes[1].rowStride, planes[1].pixelStride, w / 2, h / 2, accU!!)
        accumulatePlane(planes[2].buffer, planes[2].rowStride, planes[2].pixelStride, w / 2, h / 2, accV!!)

        collected++
        return isComplete
    }

    /**
     * Přidá surová data ze snímače (Bayerova mřížka, jeden kanál).
     *
     * Skládání na surových datech je přesnější než na hotovém JPEG: hodnoty
     * mají víc bitů, takže se ve stínech neztrácí odstupňování, a jsou
     * lineární, takže je průměrování matematicky správné. Navíc zabírají
     * poloviční paměť, protože jde o jednu rovinu místo tří kanálů.
     *
     * Vrací true, když je nasbíráno dost snímků.
     */
    fun addRawFrame(image: ImageProxy, rotation: Int): Boolean {
        if (isComplete) return true
        val planes = image.planes
        if (planes.isEmpty()) return isComplete
        val w = image.width
        val h = image.height
        if (w <= 0 || h <= 0) return isComplete

        if (accRaw == null) {
            val requiredBytes = w.toLong() * h.toLong() * 4L
            if (requiredBytes > MAX_ACCUMULATOR_BYTES) return true
            try {
                accRaw = IntArray(w * h)
            } catch (_: OutOfMemoryError) {
                reset()
                return true
            }
            width = w
            height = h
            rotationDegrees = rotation
            rawMode = true
        } else if (w != width || h != height) {
            reset()
            return addRawFrame(image, rotation)
        }

        val buffer = planes[0].buffer
        val rowStride = planes[0].rowStride
        val pixelStride = planes[0].pixelStride
        val acc = accRaw!!

        // Surová data jsou šestnáctibitová, uložená po dvou bajtech.
        for (y in 0 until h) {
            var offset = y * rowStride
            val rowStart = y * w
            for (x in 0 until w) {
                if (offset + 1 >= buffer.limit()) break
                val low = buffer.get(offset).toInt() and 0xFF
                val high = buffer.get(offset + 1).toInt() and 0xFF
                acc[rowStart + x] += (high shl 8) or low
                offset += pixelStride
            }
        }

        collected++
        return isComplete
    }

    /**
     * Přidá snímek z fotoaparátu (plné rozlišení, respektuje ruční expozici).
     * Akumuluje přímo RGB, protože ImageCapture vrací JPEG, ne YUV roviny.
     * Volající bitmapu po návratu uvolní.
     */
    fun addBitmap(bitmap: Bitmap, rotation: Int): Boolean {
        if (isComplete) return true
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return isComplete

        if (accR == null) {
            val requiredBytes = w.toLong() * h.toLong() * 4L * 3L
            if (requiredBytes > MAX_ACCUMULATOR_BYTES) return true
            try {
                accR = IntArray(w * h)
                accG = IntArray(w * h)
                accB = IntArray(w * h)
            } catch (_: OutOfMemoryError) {
                reset()
                return true
            }
            width = w
            height = h
            rotationDegrees = rotation
            rgbMode = true
        } else if (w != width || h != height) {
            // Rozměr se změnil - zahodíme a začneme znovu, ať se pole neroz cházejí.
            reset()
            return addBitmap(bitmap, rotation)
        }

        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        val r = accR!!; val g = accG!!; val b = accB!!
        // První snímky se sečtou napřímo. Od čtvrtého porovnáváme každý pixel
        // s dosavadním průměrem - když se výrazně liší (projíždějící auto,
        // chodec, odlesk), dostane nižší váhu, aby výchylku nerozmazal do
        // výsledku. Váhy se drží v jednom poli navíc, ne kopie všech snímků.
        if (collected < CLIP_AFTER_FRAMES) {
            for (i in pixels.indices) {
                val p = pixels[i]
                r[i] += (p shr 16) and 0xFF
                g[i] += (p shr 8) and 0xFF
                b[i] += p and 0xFF
            }
            // Váhy zatím netřeba držet - všech prvních pár snímků má váhu 1,
            // takže dělitel je prostě počet snímků (accW zůstává null).
        } else {
            var weights = accW
            if (weights == null) {
                // Do téhle chvíle měl každý pixel váhu = collected (plné snímky).
                weights = IntArray(pixels.size) { collected * 256 }
                accW = weights
            }
            for (i in pixels.indices) {
                val p = pixels[i]
                val pr = (p shr 16) and 0xFF
                val pg = (p shr 8) and 0xFF
                val pb = p and 0xFF
                val wSoFar = weights[i]
                // Dosavadní průměr jasu pixelu.
                val avgLuma = if (wSoFar > 0) {
                    ((r[i] + g[i] + b[i]) * 256) / (3 * wSoFar)
                } else 0
                val luma = (pr + pg + pb) / 3
                val weight = if (kotlin.math.abs(luma - avgLuma) > CLIP_DEVIATION) {
                    CLIP_LOW_WEIGHT
                } else {
                    256
                }
                r[i] += pr * weight / 256
                g[i] += pg * weight / 256
                b[i] += pb * weight / 256
                weights[i] += weight
            }
        }

        collected++
        return isComplete
    }

    private fun accumulatePlane(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        planeW: Int,
        planeH: Int,
        acc: IntArray
    ) {
        val buf = buffer.duplicate()
        var dst = 0
        var row = 0
        while (row < planeH) {
            val rowStart = row * rowStride
            var col = 0
            while (col < planeW) {
                val idx = rowStart + col * pixelStride
                if (idx < buf.limit()) {
                    acc[dst] += buf.get(idx).toInt() and 0xFF
                }
                dst++
                col++
            }
            row++
        }
    }

    /**
     * Zprůměruje akumulátory a vytvoří výsledný RGB [Bitmap].
     * Náročné – volej mimo hlavní vlákno. Po zavolání [reset] instanci znovu použij.
     *
     * @param postProcess odšumí jas a zesílí místní kontrast. Úpravy se týkají
     *   jen jasu, barvy zůstávají beze změny.
     */
    fun buildBitmap(postProcess: Boolean = true): Bitmap? {
        val n = collected
        if (n == 0) return null

        // Surová data: zprůměrovat, převést na obraz a teprve pak doladit.
        if (rawMode) {
            val acc = accRaw ?: return null
            val w = width; val h = height
            val averaged = IntArray(acc.size) { acc[it] / n }
            val params = sensorParams ?: RawProcessor.SensorParams()
            val pixels = RawProcessor.process(averaged, w, h, params)
            if (pixels.isEmpty()) return null

            if (postProcess) {
                // RawProcessor už gamu aplikoval, takže tady jde jen o
                // odšumění a doladění místního kontrastu.
                val adjusted = PostProcess.enhancePixels(pixels, w, h)
                return Bitmap.createBitmap(adjusted, w, h, Bitmap.Config.ARGB_8888)
            }
            return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
        }

        // Snímky z fotoaparátu se akumulují v RGB. Postprodukci pustíme na
        // odvozený jas a výsledek promítneme zpět do barev, aby se nezměnil
        // barevný odstín.
        if (rgbMode) {
            val ra = accR ?: return null
            val ga = accG ?: return null
            val ba = accB ?: return null
            val w = width; val h = height
            val weights = accW
            // Když se odmítaly výchylky, každý pixel má vlastní váhu; jinak se
            // všechno dělí počtem snímků. Průměr si spočítáme jednou dopředu.
            val avgR = IntArray(w * h)
            val avgG = IntArray(w * h)
            val avgB = IntArray(w * h)
            for (i in avgR.indices) {
                val divisor = if (weights != null && weights[i] > 0) weights[i] else n * 256
                avgR[i] = (ra[i] * 256) / divisor
                avgG[i] = (ga[i] * 256) / divisor
                avgB[i] = (ba[i] * 256) / divisor
            }
            val pixels = IntArray(w * h)
            if (postProcess) {
                val luma = IntArray(w * h)
                for (i in luma.indices) {
                    luma[i] = ((77 * avgR[i] + 150 * avgG[i] + 29 * avgB[i]) shr 8).coerceIn(0, 255)
                }
                val adjusted = PostProcess.enhance(luma, w, h)
                for (i in pixels.indices) {
                    val r = avgR[i]
                    val g = avgG[i]
                    val b = avgB[i]
                    val original = luma[i]
                    val target = adjusted[i]
                    if (original == target) {
                        pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    } else {
                        val nr: Int; val ng: Int; val nb: Int
                        if (original == 0) {
                            nr = target; ng = target; nb = target
                        } else {
                            val brightest = maxOf(r, maxOf(g, b))
                            var ratio = target.toFloat() / original
                            if (brightest > 0 && ratio > 1f) {
                                ratio = minOf(ratio, 255f / brightest)
                            }
                            nr = (r * ratio).toInt().coerceIn(0, 255)
                            ng = (g * ratio).toInt().coerceIn(0, 255)
                            nb = (b * ratio).toInt().coerceIn(0, 255)
                        }
                        pixels[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                    }
                }
            } else {
                for (i in pixels.indices) {
                    pixels[i] = (0xFF shl 24) or
                        (avgR[i].coerceIn(0, 255) shl 16) or
                        (avgG[i].coerceIn(0, 255) shl 8) or
                        avgB[i].coerceIn(0, 255)
                }
            }
            return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
        }

        if (accY == null) return null
        val y = accY!!; val u = accU!!; val v = accV!!
        val w = width; val h = height
        val cw = w / 2

        // Průměrovaný jas si připravíme zvlášť, aby na něj šly pustit úpravy
        // dřív, než se smíchá s barvou.
        val lumaPlane = IntArray(w * h)
        for (i in lumaPlane.indices) {
            lumaPlane[i] = y[i] / n
        }
        val luma = if (postProcess) {
            PostProcess.enhance(lumaPlane, w, h)
        } else {
            lumaPlane
        }

        val pixels = IntArray(w * h)
        var p = 0
        var row = 0
        while (row < h) {
            val uvRow = (row / 2) * cw
            var col = 0
            while (col < w) {
                val yy = luma[p]
                val uvIdx = uvRow + (col / 2)
                val uu = u[uvIdx] / n - 128
                val vv = v[uvIdx] / n - 128

                // BT.601 YUV -> RGB
                var r = yy + ((91881 * vv) shr 16)
                var g = yy - ((22554 * uu + 46802 * vv) shr 16)
                var b = yy + ((116130 * uu) shr 16)
                r = if (r < 0) 0 else if (r > 255) 255 else r
                g = if (g < 0) 0 else if (g > 255) 255 else g
                b = if (b < 0) 0 else if (b > 255) 255 else b

                pixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                p++
                col++
            }
            row++
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }

    fun reset() {
        accY = null; accU = null; accV = null
        accR = null; accG = null; accB = null; accW = null
        accRaw = null
        rgbMode = false
        rawMode = false
        collected = 0
        width = 0; height = 0
        rotationDegrees = 0
    }

    companion object {
        /** Strop pro akumulátory (~96 MB), aby velké snímky neshodily aplikaci. */
        /** Od kolikátého snímku se začnou odmítat výchylky (první se sečtou napřímo). */
        private const val CLIP_AFTER_FRAMES = 3
        /** O kolik se pixel smí lišit od průměru, než se pokládá za výchylku. */
        private const val CLIP_DEVIATION = 50
        /** Váha výchylky (fixed-point, 256 = plná). 38/256 ≈ 0.15. */
        private const val CLIP_LOW_WEIGHT = 38

        // RGB skládání drží tři pole o velikosti snímku (R, G, B). Při 12 MPix
        // to je kolem 140 MB, což na běžném heapu projde. Vyšší rozlišení už
        // radši odmítneme, než abychom riskovali vyčerpání paměti.
        private const val MAX_ACCUMULATOR_BYTES = 160L * 1024L * 1024L

        /**
         * Kolik snímků složit. Počty jsou nižší, než by odpovídalo samotnému
         * potlačení šumu - při delší expozici jednotlivých snímků totiž nese
         * každý z nich mnohem víc signálu a rozhoduje, jak dlouho se dá telefon
         * udržet v klidu. Osm snímků po půl sekundě znamená čtyři sekundy
         * snímání, což je zhruba hranice únosnosti z ruky.
         */
        fun recommendedFrames(meanLuma: Float): Int = when {
            meanLuma < 40f -> 10
            meanLuma < 70f -> 8
            meanLuma < 95f -> 6
            else -> 4
        }.coerceIn(4, 24)
    }
}

/*
 * ── Cesta k plnému RAW/DNG stackingu (příští krok) ────────────────────────
 *
 * YUV averaging výše je 8bit a rychlý – ideální pro náhled a "dobré dost"
 * výsledky. Pro maximální kvalitu (12–14bit, žádná ztráta gama křivkou):
 *
 *  1. Camera2 interop přes Camera2CameraControl / Camera2Interop na existujícím
 *     CameraX bindu, NEBO paralelní čistý Camera2 ImageReader se
 *     surfaceFormat = ImageFormat.RAW_SENSOR.
 *  2. Zamknout AE/AWB/AF (CONTROL_AE_LOCK, CONTROL_AWB_LOCK) před burstem,
 *     aby všechny snímky měly stejnou expozici.
 *  3. captureBurst(List<CaptureRequest>) o N identických requestech.
 *  4. Akumulovat 16bit RAW hodnoty do IntArray/LongArray – stejná logika jako
 *     accumulatePlane, jen 2 byty na pixel (respektovat CameraCharacteristics
 *     SENSOR_INFO_WHITE_LEVEL a color filter arrangement / Bayer vzor).
 *  5. Výstup zapsat přes DngCreator.writeImage() s průměrovaným RAW bufferem.
 *
 * NEON/JNI zrychlení: krok accumulatePlane je hot-loop kandidát pro
 * libimage_processing_util_jni.so. Nativní verze se signaturou
 * nativeAccumulate(ByteBuffer src, long[] acc, int rowStride, int pixelStride,
 * int w, int h) přes vld1/vaddw NEON instrukce zvládne 4–8 pixelů na iteraci.
 */
