package cz.hqsnet.aifoto.capture

import android.graphics.Bitmap
import android.graphics.ImageFormat
import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer

/**
 * Průměrování N snímků pro potlačení šumu (temporal denoise).
 *
 * Sbírá luma (Y) + chroma (U/V) roviny z [ImageProxy] do 32bit akumulátorů,
 * na konci dělí počtem snímků a převádí na RGB [Bitmap]. Šum je nekorelovaný
 * mezi snímky, takže průměr N snímků snižuje jeho směrodatnou odchylku ~√N krát
 * (8 snímků ≈ 2,8× méně šumu, 16 snímků ≈ 4×).
 *
 * Předpoklad: statická scéna (telefon na opoře). Bez zarovnávání snímků –
 * pohyb by způsobil rozmazání. Aktivuj jen když FrameMetrics.motion je nízké.
 *
 * Verze bez Camera2/RenderScript – běží přímo na YUV_420_888 z existujícího
 * ImageAnalysis pipeline. Pro RAW/DNG stacking viz komentář na konci souboru.
 */
class FrameStacker(
    private val targetFrames: Int = 8
) {
    private var width = 0
    private var height = 0

    // Akumulátory (long kvůli přetečení: 16× hodnota do 255 = max 4080, ale
    // u větších N a případného scaleu je long bezpečný).
    private var accY: IntArray? = null
    private var accU: IntArray? = null
    private var accV: IntArray? = null

    private var collected = 0

    /** Počet zatím nasbíraných snímků. */
    val collectedFrames: Int get() = collected

    val progress: Float get() = if (targetFrames == 0) 1f else collected.toFloat() / targetFrames
    val isComplete: Boolean get() = collected >= targetFrames

    /**
     * Přidá jeden snímek do akumulátoru. Vrací true, když je nasbíráno dost
     * snímků a lze volat [buildBitmap]. Volající je zodpovědný za zavření
     * [ImageProxy] (typicky ve finally analyzeru).
     */
    fun addFrame(image: ImageProxy): Boolean {
        // Bez této pojistky by další snímky přetekly přes cílový počet a
        // zkreslily průměr, kdyby analyzer dodal snímek po dokončení.
        if (isComplete) return true
        if (image.format != ImageFormat.YUV_420_888) return isComplete
        val planes = image.planes
        if (planes.size < 3) return isComplete

        val w = image.width
        val h = image.height

        if (accY == null) {
            // Tři akumulátory zabírají zhruba 6 bajtů na pixel. U velmi velkých
            // snímků raději skončíme, než abychom riskovali OutOfMemoryError
            // uprostřed snímání.
            val requiredBytes = w.toLong() * h.toLong() * 6L
            if (requiredBytes > MAX_ACCUMULATOR_BYTES) return true
            try {
                accY = IntArray(w * h)
                accU = IntArray((w / 2) * (h / 2))
                accV = IntArray((w / 2) * (h / 2))
            } catch (_: OutOfMemoryError) {
                reset()
                return true
            }
            width = w
            height = h
        } else if (w != width || h != height) {
            // Rozměr se změnil (rotace/reconfigure) – reset, ať se pole neroz cházejí.
            reset()
            return addFrame(image)
        }

        accumulatePlane(planes[0].buffer, planes[0].rowStride, planes[0].pixelStride, w, h, accY!!)
        accumulatePlane(planes[1].buffer, planes[1].rowStride, planes[1].pixelStride, w / 2, h / 2, accU!!)
        accumulatePlane(planes[2].buffer, planes[2].rowStride, planes[2].pixelStride, w / 2, h / 2, accV!!)

        collected++
        return isComplete
    }

    private fun accumulatePlane(
        buffer: ByteBuffer,
        rowStride: Int,
        pixelStride: Int,
        planeW: Int,
        planeH: Int,
        acc: IntArray
    ) {
        val buf = buffer.duplicate()
        var dst = 0
        var row = 0
        while (row < planeH) {
            val rowStart = row * rowStride
            var col = 0
            while (col < planeW) {
                val idx = rowStart + col * pixelStride
                if (idx < buf.limit()) {
                    acc[dst] += buf.get(idx).toInt() and 0xFF
                }
                dst++
                col++
            }
            row++
        }
    }

    /**
     * Zprůměruje akumulátory a vytvoří výsledný RGB [Bitmap].
     * Náročné – volej mimo hlavní vlákno. Po zavolání [reset] instanci znovu použij.
     */
    fun buildBitmap(): Bitmap? {
        val n = collected
        if (n == 0 || accY == null) return null
        val y = accY!!; val u = accU!!; val v = accV!!
        val w = width; val h = height
        val cw = w / 2

        val pixels = IntArray(w * h)
        var p = 0
        var row = 0
        while (row < h) {
            val uvRow = (row / 2) * cw
            var col = 0
            while (col < w) {
                val yy = y[p] / n
                val uvIdx = uvRow + (col / 2)
                val uu = u[uvIdx] / n - 128
                val vv = v[uvIdx] / n - 128

                // BT.601 YUV -> RGB
                var r = yy + ((91881 * vv) shr 16)
                var g = yy - ((22554 * uu + 46802 * vv) shr 16)
                var b = yy + ((116130 * uu) shr 16)
                r = if (r < 0) 0 else if (r > 255) 255 else r
                g = if (g < 0) 0 else if (g > 255) 255 else g
                b = if (b < 0) 0 else if (b > 255) 255 else b

                pixels[p] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                p++
                col++
            }
            row++
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }

    fun reset() {
        accY = null; accU = null; accV = null
        collected = 0
        width = 0; height = 0
    }

    companion object {
        /** Strop pro akumulátory (~96 MB), aby velké snímky neshodily aplikaci. */
        private const val MAX_ACCUMULATOR_BYTES = 96L * 1024L * 1024L

        /** Doporučený počet snímků podle úrovně světla (mean luma 0..255). */
        fun recommendedFrames(meanLuma: Float): Int = when {
            meanLuma < 40f -> 16
            meanLuma < 70f -> 12
            meanLuma < 95f -> 8
            else -> 4
        }.coerceIn(4, 24)
    }
}

/*
 * ── Cesta k plnému RAW/DNG stackingu (příští krok) ────────────────────────
 *
 * YUV averaging výše je 8bit a rychlý – ideální pro náhled a "dobré dost"
 * výsledky. Pro maximální kvalitu (12–14bit, žádná ztráta gama křivkou):
 *
 *  1. Camera2 interop přes Camera2CameraControl / Camera2Interop na existujícím
 *     CameraX bindu, NEBO paralelní čistý Camera2 ImageReader se
 *     surfaceFormat = ImageFormat.RAW_SENSOR.
 *  2. Zamknout AE/AWB/AF (CONTROL_AE_LOCK, CONTROL_AWB_LOCK) před burstem,
 *     aby všechny snímky měly stejnou expozici.
 *  3. captureBurst(List<CaptureRequest>) o N identických requestech.
 *  4. Akumulovat 16bit RAW hodnoty do IntArray/LongArray – stejná logika jako
 *     accumulatePlane, jen 2 byty na pixel (respektovat CameraCharacteristics
 *     SENSOR_INFO_WHITE_LEVEL a color filter arrangement / Bayer vzor).
 *  5. Výstup zapsat přes DngCreator.writeImage() s průměrovaným RAW bufferem.
 *
 * NEON/JNI zrychlení: krok accumulatePlane je hot-loop kandidát pro
 * libimage_processing_util_jni.so. Nativní verze se signaturou
 * nativeAccumulate(ByteBuffer src, long[] acc, int rowStride, int pixelStride,
 * int w, int h) přes vld1/vaddw NEON instrukce zvládne 4–8 pixelů na iteraci.
 */
