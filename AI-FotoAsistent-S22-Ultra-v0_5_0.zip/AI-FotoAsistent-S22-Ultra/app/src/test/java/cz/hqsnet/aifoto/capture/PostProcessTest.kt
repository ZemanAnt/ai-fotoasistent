package cz.hqsnet.aifoto.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class PostProcessTest {

    private fun gradient(width: Int, height: Int): IntArray =
        IntArray(width * height) { i ->
            val x = i % width
            val y = i / width
            (30 + x / 8 + y / 8).coerceIn(0, 255)
        }

    private fun standardDeviation(values: IntArray): Double {
        val mean = values.average()
        var sum = 0.0
        for (v in values) sum += (v - mean) * (v - mean)
        return sqrt(sum / values.size)
    }

    @Test
    fun outputStaysInValidRange() {
        val src = gradient(64, 48)
        val result = PostProcess.enhance(src, 64, 48)
        assertEquals(src.size, result.size)
        for (v in result) {
            assertTrue("hodnota mimo rozsah: $v", v in 0..255)
        }
    }

    @Test
    fun enhanceIncreasesLocalContrast() {
        // Tmavý snímek využívá jen část rozsahu - úpravy ho mají roztáhnout.
        val src = gradient(64, 48)
        val result = PostProcess.enhance(src, 64, 48)
        assertTrue(
            "kontrast se nezvýšil",
            standardDeviation(result) > standardDeviation(src)
        )
    }

    @Test
    fun zeroStrengthLeavesImageUntouched() {
        val src = gradient(32, 24)
        val result = PostProcess.enhance(src, 32, 24, strength = 0f)
        assertTrue(src.contentEquals(result))
    }

    @Test
    fun bilateralReducesNoise() {
        // Konstantní plocha se šumem: filtr má šum potlačit.
        val width = 48
        val height = 48
        val clean = IntArray(width * height) { 120 }
        val random = java.util.Random(7)
        val noisy = IntArray(clean.size) {
            (clean[it] + random.nextInt(41) - 20).coerceIn(0, 255)
        }

        fun errorAgainstClean(values: IntArray): Double {
            var sum = 0.0
            for (i in values.indices) {
                val d = (values[i] - clean[i]).toDouble()
                sum += d * d
            }
            return sqrt(sum / values.size)
        }

        val filtered = PostProcess.bilateral(noisy, width, height)
        assertTrue(
            "filtr šum nesnížil",
            errorAgainstClean(filtered) < errorAgainstClean(noisy)
        )
    }

    @Test
    fun bilateralKeepsEdge() {
        // Ostrý přechod uprostřed musí zůstat ostrý, jinak by filtr jen rozmazával.
        val width = 32
        val height = 32
        val src = IntArray(width * height) { i -> if (i % width < width / 2) 40 else 210 }
        val filtered = PostProcess.bilateral(src, width, height)

        val row = height / 2
        val leftSide = filtered[row * width + width / 4]
        val rightSide = filtered[row * width + 3 * width / 4]
        assertTrue("hrana se rozmazala: $leftSide vs $rightSide", rightSide - leftSide > 140)
    }

    @Test
    fun claheHandlesFlatImage() {
        // Jednolitá plocha nemá co vyrovnávat - nesmí spadnout ani vyrobit NaN.
        val src = IntArray(32 * 32) { 100 }
        val result = PostProcess.clahe(src, 32, 32)
        assertEquals(src.size, result.size)
        for (v in result) {
            assertTrue(v in 0..255)
        }
    }

    @Test
    fun brightPhotoIsNotWorthEnhancing() {
        // Dobře exponovaný snímek úpravou skoro nezíská, tak se nemá sahat.
        assertTrue(!PostProcess.isWorthEnhancing(meanLuma = 130f, shadowRatio = 0.0f))
    }

    @Test
    fun darkPhotoIsWorthEnhancing() {
        assertTrue(PostProcess.isWorthEnhancing(meanLuma = 50f, shadowRatio = 0.16f))
    }

    @Test
    fun crushedShadowsTriggerEnhancementEvenWhenBright() {
        // Protisvětlo: průměr vypadá dobře, ale popředí je utopené ve stínu.
        assertTrue(PostProcess.isWorthEnhancing(meanLuma = 140f, shadowRatio = 0.24f))
    }

    @Test
    fun enhancePixelsKeepsHue() {
        // Úprava jasu nesmí posunout barvy - jinak by fotky zežloutly.
        val width = 32
        val height = 32
        val pixels = IntArray(width * height) { i ->
            val base = 20 + (i % 40)
            (0xFF shl 24) or (base shl 16) or ((base / 3) shl 8) or (base / 4)
        }
        val result = PostProcess.enhancePixels(pixels, width, height)

        var maxShift = 0f
        for (i in pixels.indices) {
            val before = hueOf(pixels[i])
            val after = hueOf(result[i])
            if (before < 0f || after < 0f) continue
            var diff = kotlin.math.abs(after - before)
            if (diff > 180f) diff = 360f - diff
            if (diff > maxShift) maxShift = diff
        }
        assertTrue("odstín se posunul o $maxShift stupňů", maxShift < 5f)
    }

    @Test
    fun enhancePixelsBrightensDarkPhoto() {
        val width = 32
        val height = 32
        val pixels = IntArray(width * height) { i ->
            val base = 15 + (i % 25)
            (0xFF shl 24) or (base shl 16) or (base shl 8) or base
        }
        val result = PostProcess.enhancePixels(pixels, width, height)

        fun averageLuma(values: IntArray): Double = values.map {
            (77 * ((it shr 16) and 0xFF) + 150 * ((it shr 8) and 0xFF) + 29 * (it and 0xFF)) shr 8
        }.average()

        assertTrue(averageLuma(result) > averageLuma(pixels))
    }

    @Test
    fun extremelyDarkSceneGetsLifted() {
        // Skutečný případ z nočního snímku telefonu: téměř celá plocha měla
        // jas pod 28. Samotné vyrovnání histogramu zvedlo průměr jen z 16 na
        // 24 a snímek zůstal černý - proto je před ním ještě gama korekce.
        val width = 64
        val height = 48
        val random = java.util.Random(3)
        val dark = IntArray(width * height) {
            // Převážně černá plocha s několika světlými body, jako noční scéna.
            if (it % 97 == 0) 90 + random.nextInt(60) else 8 + random.nextInt(14)
        }

        val result = PostProcess.enhance(dark, width, height)

        val crushedBefore = dark.count { it < 28 }.toFloat() / dark.size
        val crushedAfter = result.count { it < 28 }.toFloat() / result.size
        assertTrue("vstup nebyl dost tmavý pro tento test", crushedBefore > 0.8f)
        assertTrue(
            "snímek zůstal černý: $crushedAfter podílu pod 28",
            crushedAfter < 0.3f
        )
        assertTrue(
            "průměrný jas se nezvedl: ${dark.average()} -> ${result.average()}",
            result.average() > dark.average() * 2
        )
    }

    private fun hueOf(pixel: Int): Float {
        val r = ((pixel shr 16) and 0xFF) / 255f
        val g = ((pixel shr 8) and 0xFF) / 255f
        val b = (pixel and 0xFF) / 255f
        val max = maxOf(r, g, b)
        val min = minOf(r, g, b)
        val delta = max - min
        if (delta < 1e-6f) return -1f
        val hue = when (max) {
            r -> 60 * (((g - b) / delta) % 6)
            g -> 60 * (((b - r) / delta) + 2)
            else -> 60 * (((r - g) / delta) + 4)
        }
        return (hue + 360) % 360
    }
}
