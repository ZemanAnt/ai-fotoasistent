package cz.hqsnet.aifoto.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class PostProcessTest {

    private fun gradient(width: Int, height: Int): IntArray =
        IntArray(width * height) { i ->
            val x = i % width
            val y = i / width
            (30 + x / 8 + y / 8).coerceIn(0, 255)
        }

    private fun standardDeviation(values: IntArray): Double {
        val mean = values.average()
        var sum = 0.0
        for (v in values) sum += (v - mean) * (v - mean)
        return sqrt(sum / values.size)
    }

    @Test
    fun outputStaysInValidRange() {
        val src = gradient(64, 48)
        val result = PostProcess.enhance(src, 64, 48)
        assertEquals(src.size, result.size)
        for (v in result) {
            assertTrue("hodnota mimo rozsah: $v", v in 0..255)
        }
    }

    @Test
    fun enhanceIncreasesLocalContrast() {
        // Tmavý snímek využívá jen část rozsahu - úpravy ho mají roztáhnout.
        val src = gradient(64, 48)
        val result = PostProcess.enhance(src, 64, 48)
        assertTrue(
            "kontrast se nezvýšil",
            standardDeviation(result) > standardDeviation(src)
        )
    }

    @Test
    fun zeroStrengthLeavesImageUntouched() {
        val src = gradient(32, 24)
        val result = PostProcess.enhance(src, 32, 24, strength = 0f)
        assertTrue(src.contentEquals(result))
    }

    @Test
    fun bilateralReducesNoise() {
        // Konstantní plocha se šumem: filtr má šum potlačit.
        val width = 48
        val height = 48
        val clean = IntArray(width * height) { 120 }
        val random = java.util.Random(7)
        val noisy = IntArray(clean.size) {
            (clean[it] + random.nextInt(41) - 20).coerceIn(0, 255)
        }

        fun errorAgainstClean(values: IntArray): Double {
            var sum = 0.0
            for (i in values.indices) {
                val d = (values[i] - clean[i]).toDouble()
                sum += d * d
            }
            return sqrt(sum / values.size)
        }

        val filtered = PostProcess.bilateral(noisy, width, height)
        assertTrue(
            "filtr šum nesnížil",
            errorAgainstClean(filtered) < errorAgainstClean(noisy)
        )
    }

    @Test
    fun bilateralKeepsEdge() {
        // Ostrý přechod uprostřed musí zůstat ostrý, jinak by filtr jen rozmazával.
        val width = 32
        val height = 32
        val src = IntArray(width * height) { i -> if (i % width < width / 2) 40 else 210 }
        val filtered = PostProcess.bilateral(src, width, height)

        val row = height / 2
        val leftSide = filtered[row * width + width / 4]
        val rightSide = filtered[row * width + 3 * width / 4]
        assertTrue("hrana se rozmazala: $leftSide vs $rightSide", rightSide - leftSide > 140)
    }

    @Test
    fun claheHandlesFlatImage() {
        // Jednolitá plocha nemá co vyrovnávat - nesmí spadnout ani vyrobit NaN.
        val src = IntArray(32 * 32) { 100 }
        val result = PostProcess.clahe(src, 32, 32)
        assertEquals(src.size, result.size)
        for (v in result) {
            assertTrue(v in 0..255)
        }
    }
}
