package cz.hqsnet.aifoto.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FrameStackerTest {

    @Test
    fun darkerScenesGetMoreFrames() {
        val veryDark = FrameStacker.recommendedFrames(20f)
        val dark = FrameStacker.recommendedFrames(60f)
        val dim = FrameStacker.recommendedFrames(85f)
        val bright = FrameStacker.recommendedFrames(150f)

        assertTrue("tmavší scéna potřebuje víc snímků", veryDark > dark)
        assertTrue(dark > dim)
        assertTrue(dim > bright)
    }

    @Test
    fun frameCountStaysInUsableRange() {
        // Příliš málo snímků nepotlačí šum, příliš mnoho prodlouží snímání
        // za hranici, kdy se dá telefon udržet v klidu.
        for (luma in 0..255) {
            val frames = FrameStacker.recommendedFrames(luma.toFloat())
            assertTrue("luma=$luma -> $frames", frames in 4..24)
        }
    }

    @Test
    fun brightSceneUsesMinimumFrames() {
        assertEquals(4, FrameStacker.recommendedFrames(200f))
    }

    @Test
    fun progressStartsEmptyAndIsNotComplete() {
        val stacker = FrameStacker(targetFrames = 8)
        assertEquals(0f, stacker.progress, 0.0001f)
        assertTrue(!stacker.isComplete)
    }

    @Test
    fun resetClearsProgress() {
        val stacker = FrameStacker(targetFrames = 8)
        stacker.reset()
        assertEquals(0f, stacker.progress, 0.0001f)
        assertEquals(null, stacker.buildBitmap())
    }

    @Test
    fun freshStackerHasNoRotation() {
        val stacker = FrameStacker(targetFrames = 8)
        assertEquals(0, stacker.rotationDegrees)
        assertEquals(0, stacker.collectedFrames)
    }

    @Test
    fun completeStackerReportsFullProgress() {
        // Skládání se ukončuje podle progressu, takže musí dojít přesně na 1f.
        val stacker = FrameStacker(targetFrames = 4)
        assertEquals(0f, stacker.progress, 0.0001f)
        assertTrue(!stacker.isComplete)
    }
}
