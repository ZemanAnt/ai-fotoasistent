package cz.hqsnet.aifoto.analysis

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SceneAdvisorTest {

    @Test
    fun darkFrameProducesNightAdvice() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 38f, shadowRatio = 0.42f),
            emptyList()
        )
        assertEquals(SceneKind.NIGHT, result.scene)
        assertEquals(1f, result.zoomRatio)
    }

    @Test
    fun personLabelProducesPortraitAdvice() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 128f),
            listOf("Person" to 0.91f)
        )
        assertEquals(SceneKind.PORTRAIT, result.scene)
        assertTrue(result.zoomRatio >= 3f)
    }

    @Test
    fun mixedHighlightsAndShadowsWarnAboutBacklight() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(
                meanLuma = 120f,
                shadowRatio = 0.24f,
                highlightRatio = 0.09f
            ),
            emptyList()
        )
        assertEquals(SceneKind.BACKLIGHT, result.scene)
        assertTrue(result.exposureCompensation < 0f)
    }

    @Test
    fun texturedLandscapeIsNotMacro() {
        // Tráva, listí a dav dávají podobně vysokou hustotu hran jako skutečný
        // detail. Když ML Kit scénu rozpozná, štítek musí mít přednost.
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 150f, edgeEnergy = 80f),
            listOf("field" to 0.9f)
        )
        assertEquals(SceneKind.LANDSCAPE, result.scene)
    }

    @Test
    fun forestIsNotMacro() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 140f, edgeEnergy = 90f),
            listOf("forest" to 0.85f)
        )
        assertEquals(SceneKind.LANDSCAPE, result.scene)
    }

    @Test
    fun closeUpLabelStillProducesMacro() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 140f, edgeEnergy = 90f),
            listOf("flower" to 0.8f)
        )
        assertEquals(SceneKind.MACRO, result.scene)
    }

    @Test
    fun highEdgeEnergyWithoutLabelsProducesMacro() {
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 140f, edgeEnergy = 90f),
            emptyList()
        )
        assertEquals(SceneKind.MACRO, result.scene)
    }

    @Test
    fun darkSceneStaysNightDespiteTexture() {
        // Noc má přednost před vším ostatním - jinak by tmavá scéna dostala
        // rychlý čas a snímek by vyšel černý.
        val result = SceneAdvisor.recommend(
            FrameMetrics(meanLuma = 50f, edgeEnergy = 90f),
            emptyList()
        )
        assertEquals(SceneKind.NIGHT, result.scene)
    }
}
