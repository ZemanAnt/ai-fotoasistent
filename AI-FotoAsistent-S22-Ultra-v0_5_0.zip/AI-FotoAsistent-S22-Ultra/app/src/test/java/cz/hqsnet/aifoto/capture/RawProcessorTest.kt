package cz.hqsnet.aifoto.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class RawProcessorTest {

    private val width = 32
    private val height = 32
    private val black = 64
    private val white = 1023

    private val params = RawProcessor.SensorParams(
        blackLevel = black,
        whiteLevel = white,
        pattern = RawProcessor.CfaPattern.RGGB
    )

    private fun red(pixel: Int) = (pixel shr 16) and 0xFF
    private fun green(pixel: Int) = (pixel shr 8) and 0xFF
    private fun blue(pixel: Int) = pixel and 0xFF

    /** Mřížka, ve které po vyvážení bílé vyjde neutrální šedá. */
    private fun neutralGrayBayer(greenLevel: Int): IntArray {
        val r = (black + (greenLevel - black) / params.gainR).toInt()
        val b = (black + (greenLevel - black) / params.gainB).toInt()
        return IntArray(width * height) { i ->
            val x = i % width
            val y = i / width
            val evenRow = y % 2 == 0
            val evenCol = x % 2 == 0
            when {
                evenRow && evenCol -> r
                !evenRow && !evenCol -> b
                else -> greenLevel
            }
        }
    }

    @Test
    fun neutralSceneStaysNeutral() {
        // Bez vyvážení bílé by snímek zezelenal - v mřížce jsou dvě zelené
        // buňky na jednu červenou a modrou.
        val result = RawProcessor.process(neutralGrayBayer(500), width, height, params)
        val center = result[(height / 2) * width + width / 2]
        assertTrue(
            "barvy nejsou neutrální: ${red(center)}/${green(center)}/${blue(center)}",
            abs(red(center) - green(center)) < 12 && abs(green(center) - blue(center)) < 12
        )
    }

    @Test
    fun blackLevelIsSubtracted() {
        // Snímač hlásí i v naprosté tmě nenulovou hodnotu; bez odečtení by
        // černá vyšla šedá a snímek by ztratil kontrast.
        val allBlack = IntArray(width * height) { black }
        val result = RawProcessor.process(allBlack, width, height, params)
        val center = result[(height / 2) * width + width / 2]
        assertEquals(0, red(center))
        assertEquals(0, green(center))
        assertEquals(0, blue(center))
    }

    @Test
    fun gammaLiftsShadows() {
        // Surová data jsou lineární. Desetina rozsahu musí po převodu vyjít
        // výrazně výš než desetina z 255, jinak by noční snímek zůstal černý.
        val level = black + ((white - black) * 0.1f).toInt()
        val flat = IntArray(width * height) { level }
        val neutral = params.copy(gainR = 1f, gainG = 1f, gainB = 1f)
        val result = RawProcessor.process(flat, width, height, neutral)
        val value = red(result[(height / 2) * width + width / 2])
        assertTrue("stíny se nevytáhly: $value", value > 50)
    }

    @Test
    fun whitePointDoesNotOverflow() {
        val allWhite = IntArray(width * height) { white }
        val result = RawProcessor.process(allWhite, width, height, params)
        val center = result[(height / 2) * width + width / 2]
        assertEquals(255, red(center))
        assertEquals(255, green(center))
        assertEquals(255, blue(center))
    }

    @Test
    fun outputStaysInValidRange() {
        val random = java.util.Random(3)
        val noise = IntArray(width * height) { random.nextInt(white + 1) }
        val result = RawProcessor.process(noise, width, height, params)
        for (pixel in result) {
            assertTrue(red(pixel) in 0..255)
            assertTrue(green(pixel) in 0..255)
            assertTrue(blue(pixel) in 0..255)
        }
    }

    @Test
    fun allBayerPatternsProduceOutput() {
        // Špatně určený vzor by prohodil červenou s modrou, ale žádný
        // z nich nesmí skončit chybou.
        val source = neutralGrayBayer(500)
        for (pattern in RawProcessor.CfaPattern.values()) {
            val result = RawProcessor.process(
                source, width, height, params.copy(pattern = pattern)
            )
            assertEquals(width * height, result.size)
        }
    }

    @Test
    fun emptyInputIsHandled() {
        val result = RawProcessor.process(IntArray(0), 0, 0, params)
        assertEquals(0, result.size)
    }

    @Test
    fun brighterSceneGivesBrighterOutput() {
        val dark = RawProcessor.process(neutralGrayBayer(200), width, height, params)
        val bright = RawProcessor.process(neutralGrayBayer(800), width, height, params)
        val darkValue = green(dark[(height / 2) * width + width / 2])
        val brightValue = green(bright[(height / 2) * width + width / 2])
        assertTrue("jas neroste: $darkValue vs $brightValue", brightValue > darkValue)
    }
}
