# Changelog

## 0.5.0

- noční režim: skládání 4-16 snímků do jedné fotky s nižším šumem
  (průměrování potlačí šum zhruba √N krát);
- oprava detekce pohybu: vzorkování na pevné mřížce 48×36 místo kroku
  závislého na rozlišení - dřív se při změně rozlišení délka vzorků
  rozešla a pohyb se vyhodnotil jako nulový;
- doporučení blesku pokrývá všechny typy scén; u protisvětla se nově
  navrhne přisvícení, dřív spadlo všechno kromě portrétu a univerzální
  scény do "vypnuto";
- selhání startu fotoaparátu se ohlásí místo tichého černého náhledu;
- release build: zapnutý R8 a shrinkResources, vypnutá záloha dat;
- opraveno chybné vyhodnocení texturované krajiny (tráva, listí, les) jako
  makra - štítek scény má nově přednost před hustotou hran;
- po trvalém odmítnutí přístupu k fotoaparátu nabídne aplikace otevření
  nastavení; dřív tlačítko nedělalo nic a uživatel uvízl na úvodní obrazovce;
- při ukládání JPEG+RAW se chyba jednoho formátu už nezasekne na stavu
  "ukládám" a fotka se nabídne, pokud se uložil aspoň jeden soubor;
- noční snímání se ukončí po 15 s, i když přestanou chodit snímky;
- poloviční spotřeba paměti při skládání (akumulátory Int místo Long)
  a pojistka proti vyčerpání paměti u velkých rozlišení.

## 0.1.0

- první funkční CameraX fotoaparát;
- lokální AI rozpoznávání scén;
- fotografický poradce pro deset typů scén;
- histogram, vodováha, mřížka a dotykové ostření;
- zoom, korekce expozice, blesk a ukládání do MediaStore;
- české mobilní rozhraní.
