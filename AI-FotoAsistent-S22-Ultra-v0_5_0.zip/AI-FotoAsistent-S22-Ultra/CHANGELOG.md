# Changelog

## 0.5.0

- noční režim: skládání 4-16 snímků do jedné fotky s nižším šumem
  (průměrování potlačí šum zhruba √N krát);
- oprava detekce pohybu: vzorkování na pevné mřížce 48×36 místo kroku
  závislého na rozlišení - dřív se při změně rozlišení délka vzorků
  rozešla a pohyb se vyhodnotil jako nulový;
- doporučení blesku pokrývá všechny typy scén; u protisvětla se nově
  navrhne přisvícení, dřív spadlo všechno kromě portrétu a univerzální
  scény do "vypnuto";
- selhání startu fotoaparátu se ohlásí místo tichého černého náhledu;
- release build: zapnutý R8 a shrinkResources, vypnutá záloha dat;
- opraveno chybné vyhodnocení texturované krajiny (tráva, listí, les) jako
  makra - štítek scény má nově přednost před hustotou hran;
- po trvalém odmítnutí přístupu k fotoaparátu nabídne aplikace otevření
  nastavení; dřív tlačítko nedělalo nic a uživatel uvízl na úvodní obrazovce;
- při ukládání JPEG+RAW se chyba jednoho formátu už nezasekne na stavu
  "ukládám" a fotka se nabídne, pokud se uložil aspoň jeden soubor;
- noční snímání se ukončí po 15 s, i když přestanou chodit snímky;
- poloviční spotřeba paměti při skládání (akumulátory Int místo Long)
  a pojistka proti vyčerpání paměti u velkých rozlišení;
- během nočního snímání se zamyká expozice a vyvážení bílé; bez zámku
  automatika mezi snímky dolaďovala jas a průměr se rozmazal o odchylku,
  kterou skládání neodstraní;
- pohyb se nově hlídá i v průběhu snímání - rozhýbaný telefon snímání
  zruší místo uložení rozmazané fotky;
- složená fotka dostala metadata: orientaci (jinak se v galerii zobrazila
  otočená), počet složených snímků a název aplikace;
- dokončovací úpravy nočního snímku: hranově citlivé odšumění a místní
  vyrovnání jasu. Pořadí je podstatné - odšumit až po zesílení kontrastu
  by zesílilo i šum. Měření na složeném snímku: zhruba 1,6x vyšší kontrast
  při dvojnásobně lepším poměru signál/šum;
- běžná fotka se po uložení dotáhne, ale jen když na tom získá - tedy
  u tmavých snímků a u ztracených stínů. Dobře exponovaný snímek zůstane
  beze změny, protože úpravou skoro nezíská. Úprava se dotýká jen jasu,
  barevné odstíny zůstávají (ověřeno: posun pod 1 stupeň);
- velmi tmavé snímky se nově zvedají i gama korekcí. Na skutečné noční
  fotce z telefonu mělo 96 % plochy jas pod 28 a samotné vyrovnání
  histogramu zvedlo průměr jen z 16 na 24 - snímek zůstal černý.
  S gamou vychází 62 a černá plocha zmizí úplně;
- noční režim nově exponuje jednotlivé snímky ručně, typicky 1/4 až 1/2,5 s
  místo náhledových zhruba 1/30 s. To je to hlavní, co dělalo rozdíl proti
  telefonům s dobrým nočním režimem: sedm snímků z náhledu nasbírá dohromady
  jen zlomek sekundy světla, kdežto s delší expozicí je nasbíraného světla
  zhruba patnáctkrát víc. Snímků proto stačí méně (10 místo 16) a snímání
  trvá do čtyř sekund. Když snímač ruční expozici neumí, zůstane aspoň
  zámek automatiky jako dřív.

## 0.1.0

- první funkční CameraX fotoaparát;
- lokální AI rozpoznávání scén;
- fotografický poradce pro deset typů scén;
- histogram, vodováha, mřížka a dotykové ostření;
- zoom, korekce expozice, blesk a ukládání do MediaStore;
- české mobilní rozhraní.
