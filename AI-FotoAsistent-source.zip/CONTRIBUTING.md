# Přispívání do AI FotoAsistenta

Díky za zájem o projekt. Cílem je zachovat pravdivé ovládání fotoaparátu: aplikace nesmí vydávat požadované ISO, čas, objektiv nebo zoom za skutečně použitou hodnotu, dokud je nepotvrdí telemetrie zařízení.

## Než začnete

1. Zkontrolujte existující issues a roadmapu v `CHANGELOG.md`.
2. Pro větší změnu nejprve založte issue s návrhem řešení.
3. Nevkládejte do repozitáře fotografie uživatelů, GPS metadata, APK, AAB, keystore ani přístupové údaje.

## Vývojové prostředí

- Android Studio s JDK 17
- Android SDK 36
- skutečné zařízení pro testy Camera2/CameraX, přednostně Galaxy S22 Ultra

```bash
./gradlew lintDebug testDebugUnitTest assembleDebug
```

Na Windows:

```bat
gradlew.bat lintDebug testDebugUnitTest assembleDebug
```

## Pull request

- vytvořte větev z `main`;
- udržujte změnu úzce zaměřenou;
- doplňte nebo upravte jednotkové testy;
- u změn fotoaparátu přiložte anonymizovaný záznam zařízení a výsledek podle odpovídajícího testovacího plánu v `docs/`;
- aktualizujte `CHANGELOG.md`, mění-li se chování uživatele;
- potvrďte, že aplikace zůstává bez oprávnění `INTERNET`, pokud síť není výslovným tématem schváleného návrhu.

## Styl

- Kotlin, čtyři mezery, UTF-8;
- jasná jména místo zkratek;
- rozhodovací jádra držte pokud možno jako čistý Kotlin bez Android závislostí;
- každé doporučení AI musí mít vysvětlitelný důvod a bezpečný fallback;
- selhání OEM nebo fyzického objektivu nesmí skončit černým náhledem.

Odesláním příspěvku souhlasíte s jeho licencováním pod Apache License 2.0.
