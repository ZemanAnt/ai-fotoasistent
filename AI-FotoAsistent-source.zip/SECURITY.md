# Security policy

## Supported versions

Security fixes are applied to the latest development branch and the newest published release.
Older ZIP snapshots are not maintained after a replacement release is available.

| Version | Supported |
| --- | --- |
| 0.9.x | Yes |
| 0.8.x and older | No |

## Reporting a vulnerability

Please do **not** publish exploitable details in a public issue.

Use GitHub's private vulnerability reporting or open a private security advisory in the repository's **Security** tab. Include:

- affected version or commit;
- device and Android version;
- reproducible steps;
- expected and actual behavior;
- logs with personal paths, photos, GPS data and signing material removed.

The project does not intentionally use networking. Reports involving unexpected network access, unsafe file handling, camera permission bypass, EXIF leakage or signing-key exposure are treated as high priority.
