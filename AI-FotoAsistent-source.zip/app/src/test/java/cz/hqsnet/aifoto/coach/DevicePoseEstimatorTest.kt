package cz.hqsnet.aifoto.coach

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class DevicePoseEstimatorTest {

    @Test
    fun portraitAndLandscapeBothResolveToLevel() {
        val portrait = DevicePoseEstimator()
        repeat(12) { portrait.update(0f, 9.81f, 0f, true) }
        assertTrue(abs(portrait.update(0f, 9.81f, 0f, true).levelErrorDegrees) < 0.5f)

        val landscape = DevicePoseEstimator()
        repeat(12) { landscape.update(9.81f, 0f, 0f, true) }
        assertTrue(abs(landscape.update(9.81f, 0f, 0f, true).levelErrorDegrees) < 0.5f)
    }

    @Test
    fun flatPhoneReportsHighFlatness() {
        val estimator = DevicePoseEstimator()
        var pose = DevicePose()
        repeat(16) { pose = estimator.update(0f, 0f, 9.81f, true) }
        assertTrue(pose.flatness > 0.95f)
    }
}
