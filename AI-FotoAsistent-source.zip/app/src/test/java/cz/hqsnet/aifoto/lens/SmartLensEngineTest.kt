package cz.hqsnet.aifoto.lens

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartLensEngineTest {
    private val ultra = lens("u", LensRole.ULTRA_WIDE, 0.6f, "0,6× ultra")
    private val main = lens("m", LensRole.WIDE, 1f, "1× hlavní")
    private val tele = lens("t", LensRole.TELEPHOTO, 3f, "3× tele")
    private val superTele = lens("s", LensRole.SUPER_TELEPHOTO, 10f, "10× tele")
    private val catalog = LensCatalogState(
        logicalCameraId = "0",
        profiles = listOf(ultra, main, tele, superTele),
        mainLensId = main.id,
        logicalMultiCamera = true
    )

    @Test
    fun nightAlwaysUsesMainAndCanRequestOemNight() {
        val result = SmartLensEngine.recommend(
            advice(SceneKind.NIGHT, luma = 40f),
            catalog,
            ExtensionAvailability(night = true)
        )
        assertEquals(main.id, result.lensId)
        assertEquals(OemExtensionMode.NIGHT, result.extensionMode)
        assertTrue(result.warning!!.contains("Teleobjektiv"))
    }

    @Test
    fun brightStableLandscapeUsesOpticalUltraWide() {
        val result = SmartLensEngine.recommend(
            advice(SceneKind.LANDSCAPE, luma = 150f, motion = 0.02f),
            catalog
        )
        assertEquals(ultra.id, result.lensId)
        assertEquals(0.6f, result.equivalentZoom)
    }

    @Test
    fun darkPortraitRejectsTelephoto() {
        val result = SmartLensEngine.recommend(
            advice(SceneKind.PORTRAIT, luma = 76f),
            catalog
        )
        assertEquals(main.id, result.lensId)
        assertTrue(result.warning!!.contains("digitálního 3×"))
    }

    @Test
    fun brightPortraitUsesThreeTimesPhysicalLens() {
        val result = SmartLensEngine.recommend(
            advice(SceneKind.PORTRAIT, luma = 140f, motion = 0.03f),
            catalog
        )
        assertEquals(tele.id, result.lensId)
    }

    @Test
    fun tenTimesIsNotSelectedForGenericPet() {
        val result = SmartLensEngine.recommend(
            advice(SceneKind.PET, luma = 180f, motion = 0.01f, labels = listOf("cat")),
            catalog
        )
        assertFalse(result.lensId == superTele.id)
    }

    @Test
    fun brightStableBirdCanUseSuperTeleEvenWhenClassifiedAsPet() {
        val result = SmartLensEngine.recommend(
            advice(SceneKind.PET, luma = 180f, motion = 0.01f, labels = listOf("bird")),
            catalog
        )
        assertEquals(superTele.id, result.lensId)
    }

    @Test
    fun recommendationNeedsThreeMatchingSamplesToBeStable() {
        val stabilizer = LensRecommendationStabilizer(requiredSamples = 3)
        val input = LensRecommendation(main.id, 1f, "1×", "test")
        assertFalse(stabilizer.update(input).stable)
        assertFalse(stabilizer.update(input).stable)
        assertTrue(stabilizer.update(input).stable)
    }

    @Test
    fun stableLensDoesNotSwitchUntilThreeNewMatchingSamples() {
        val stabilizer = LensRecommendationStabilizer(requiredSamples = 3)
        val wide = LensRecommendation(main.id, 1f, "1×", "wide")
        val portrait = LensRecommendation(tele.id, 3f, "3×", "portrait")
        repeat(3) { stabilizer.update(wide) }

        assertEquals(main.id, stabilizer.update(portrait).lensId)
        assertEquals(main.id, stabilizer.update(portrait).lensId)
        val switched = stabilizer.update(portrait)
        assertEquals(tele.id, switched.lensId)
        assertTrue(switched.stable)
    }

    private fun advice(
        scene: SceneKind,
        luma: Float,
        motion: Float = 0f,
        labels: List<String> = emptyList()
    ) = SceneAdvice(
        scene = scene,
        metrics = FrameMetrics(meanLuma = luma, motion = motion),
        labels = labels
    )

    private fun lens(id: String, role: LensRole, zoom: Float, name: String) = LensProfile(
        id = id,
        selectorCameraId = "0",
        physicalCameraId = id,
        role = role,
        displayName = name,
        shortLabel = zoom.toString(),
        equivalentZoom = zoom,
        focalLengthMm = zoom
    )
}
