package cz.hqsnet.aifoto.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NightAlignmentTest {
    @Test
    fun detectsKnownTranslation() {
        val reference = patternedFrame(96, 72)
        val current = shifted(reference, dx = 4, dy = -3)

        val result = NightAlignment.estimate(
            reference = reference,
            current = current,
            maxShift = 8,
            maxAlignmentError = 0.25f
        )

        assertEquals(4, result.offsetX)
        assertEquals(-3, result.offsetY)
        assertTrue(result.error < 0.08f)
        assertTrue(result.confidence > 0.25f)
    }

    @Test
    fun resultDoesNotDependOnOddOrLargeSearchWindow() {
        val reference = patternedFrame(96, 72)
        val current = shifted(reference, dx = 4, dy = -3)

        for (window in listOf(8, 9, 12, 18, 24)) {
            val result = NightAlignment.estimate(reference, current, window, 0.25f)
            assertEquals("window=$window", 4, result.offsetX)
            assertEquals("window=$window", -3, result.offsetY)
            assertTrue("window=$window error=${result.error}", result.error < 0.08f)
        }
    }

    @Test
    fun texturelessFrameNeverInventsAConfidentShift() {
        val flat = LumaFrame(96, 72, ByteArray(96 * 72) { 42 })
        val result = NightAlignment.estimate(flat, flat, maxShift = 18, maxAlignmentError = 0.25f)

        assertEquals(0, result.offsetX)
        assertEquals(0, result.offsetY)
        assertEquals(0f, result.confidence, 0.0001f)
    }

    @Test
    fun movingRatioFindsChangedRegion() {
        val reference = patternedFrame(80, 64)
        val changed = reference.data.copyOf()
        for (y in 20 until 44) {
            for (x in 25 until 55) changed[y * reference.width + x] = 255.toByte()
        }
        val current = LumaFrame(reference.width, reference.height, changed)
        val ratio = NightAlignment.movingRatio(
            reference,
            current,
            FrameAlignment(),
            threshold = 20
        )
        assertTrue(ratio > 0.08f)
        assertTrue(ratio < 0.30f)
    }

    private fun patternedFrame(width: Int, height: Int): LumaFrame {
        val data = ByteArray(width * height)
        var seed = 123456789
        for (y in 0 until height) {
            for (x in 0 until width) {
                seed = seed * 1103515245 + 12345
                val noise = (seed ushr 24) and 31
                val base = ((x * 5 + y * 7 + (x * y) % 43) % 180) + 30
                data[y * width + x] = (base + noise).coerceAtMost(255).toByte()
            }
        }
        return LumaFrame(width, height, data)
    }

    private fun shifted(source: LumaFrame, dx: Int, dy: Int): LumaFrame {
        val data = ByteArray(source.data.size)
        for (y in 0 until source.height) {
            for (x in 0 until source.width) {
                val sx = x - dx
                val sy = y - dy
                data[y * source.width + x] = if (sx in 0 until source.width && sy in 0 until source.height) {
                    source.data[sy * source.width + sx]
                } else {
                    0
                }
            }
        }
        return LumaFrame(source.width, source.height, data)
    }
}
