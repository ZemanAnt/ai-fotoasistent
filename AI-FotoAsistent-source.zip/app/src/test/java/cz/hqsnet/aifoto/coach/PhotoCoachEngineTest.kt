package cz.hqsnet.aifoto.coach

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PhotoCoachEngineTest {

    @Test
    fun motionHasPriorityOverComposition() {
        val advice = advice(
            scene = SceneKind.PORTRAIT,
            metrics = baseMetrics().copy(
                motion = 0.22f,
                saliencyCenterX = 0.1f,
                saliencyCenterY = 0.1f
            ),
            faces = listOf(face(centerX = 0.1f))
        )

        val cue = PhotoCoachEngine.evaluate(
            advice,
            DevicePose(sensorAvailable = true),
            CoachExposure(exposureNanos = 40_000_000L),
            CoachMode.COACH
        )

        assertEquals(CoachCategory.STABILITY, cue.category)
        assertEquals(CoachDirection.HOLD, cue.direction)
    }

    @Test
    fun landscapeRequestsLevelBeforeComposition() {
        val cue = PhotoCoachEngine.evaluate(
            advice(SceneKind.LANDSCAPE, baseMetrics()),
            DevicePose(levelErrorDegrees = 5.2f, sensorAvailable = true),
            CoachExposure(exposureNanos = 5_000_000L),
            CoachMode.COACH
        )

        assertEquals(CoachCategory.LEVEL, cue.category)
        assertTrue(cue.title.contains("horizont", ignoreCase = true))
    }

    @Test
    fun documentRequestsParallelPhone() {
        val cue = PhotoCoachEngine.evaluate(
            advice(SceneKind.DOCUMENT, baseMetrics()),
            DevicePose(levelErrorDegrees = 0f, flatness = 0.35f, sensorAvailable = true),
            CoachExposure(),
            CoachMode.COACH
        )

        assertEquals(CoachCategory.PERSPECTIVE, cue.category)
    }

    @Test
    fun smallPortraitFaceRequestsCloserDistance() {
        val cue = PhotoCoachEngine.evaluate(
            advice(
                SceneKind.PORTRAIT,
                baseMetrics(),
                listOf(face(width = 0.12f, height = 0.18f))
            ),
            DevicePose(sensorAvailable = false),
            CoachExposure(exposureNanos = 4_000_000L),
            CoachMode.COACH
        )

        assertEquals(CoachCategory.DISTANCE, cue.category)
        assertEquals(CoachDirection.CLOSER, cue.direction)
    }

    @Test
    fun closedEyesAreDetectedBeforeFraming() {
        val cue = PhotoCoachEngine.evaluate(
            advice(
                SceneKind.PORTRAIT,
                baseMetrics(),
                listOf(
                    face(
                        width = 0.24f,
                        height = 0.32f,
                        leftEye = 0.12f,
                        rightEye = 0.18f
                    )
                )
            ),
            DevicePose(sensorAvailable = false),
            CoachExposure(exposureNanos = 4_000_000L),
            CoachMode.COACH
        )

        assertEquals(CoachCategory.FACE, cue.category)
        assertTrue(cue.title.contains("oči", ignoreCase = true))
    }

    @Test
    fun stableBalancedSceneBecomesReady() {
        val cue = PhotoCoachEngine.evaluate(
            advice(
                SceneKind.GENERAL,
                baseMetrics().copy(
                    saliencyCenterX = 0.5f,
                    saliencyCenterY = 0.5f,
                    saliencyConfidence = 0.8f,
                    sharpnessScore = 0.72f
                )
            ),
            DevicePose(levelErrorDegrees = 0.4f, sensorAvailable = true),
            CoachExposure(exposureNanos = 3_000_000L),
            CoachMode.COACH
        )

        assertEquals(CoachSeverity.READY, cue.severity)
        assertTrue(cue.score >= 80)
    }

    @Test
    fun stabilizerRequiresThreeReadySamples() {
        val stabilizer = CoachCueStabilizer()
        val warning = CoachCue(
            id = "warning",
            category = CoachCategory.EXPOSURE,
            severity = CoachSeverity.WARNING,
            title = "Pozor",
            detail = "Pozor"
        )
        val ready = CoachCue(
            id = "ready",
            category = CoachCategory.READY,
            severity = CoachSeverity.READY,
            title = "Teď můžete fotit",
            detail = "Hotovo"
        )

        assertEquals("warning", stabilizer.update(warning).id)
        assertEquals("warning", stabilizer.update(ready).id)
        assertEquals("warning", stabilizer.update(ready).id)
        assertEquals("ready", stabilizer.update(ready).id)
    }

    private fun advice(
        scene: SceneKind,
        metrics: FrameMetrics,
        faces: List<FaceObservation> = emptyList()
    ) = SceneAdvice(
        scene = scene,
        confidence = 0.9f,
        metrics = metrics,
        faces = faces
    )

    private fun baseMetrics() = FrameMetrics(
        meanLuma = 128f,
        contrast = 35f,
        motion = 0.01f,
        edgeEnergy = 28f,
        sharpnessScore = 0.65f,
        saliencyCenterX = 0.5f,
        saliencyCenterY = 0.5f,
        saliencyConfidence = 0.7f,
        highlightRatio = 0.005f
    )

    private fun face(
        centerX: Float = 0.5f,
        centerY: Float = 0.42f,
        width: Float = 0.22f,
        height: Float = 0.3f,
        leftEye: Float? = 0.9f,
        rightEye: Float? = 0.9f
    ) = FaceObservation(
        centerX = centerX,
        centerY = centerY,
        width = width,
        height = height,
        leftEyeOpenProbability = leftEye,
        rightEyeOpenProbability = rightEye
    )
}
