package cz.hqsnet.aifoto.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExposureLockTest {

    /** Zhruba to, co dovolí novější telefon. */
    private val capableSensor = ExposureLock.ExposureLimits(
        minExposureNanos = 41_666L,
        maxExposureNanos = 500_000_000L,
        minIso = 50,
        maxIso = 3200
    )

    /** Snímač, který dlouhé časy neumí. */
    private val limitedSensor = ExposureLock.ExposureLimits(
        minExposureNanos = 100_000L,
        maxExposureNanos = 100_000_000L,
        minIso = 50,
        maxIso = 3200
    )

    @Test
    fun darkerSceneGetsLongerExposure() {
        val (veryDark, _) = ExposureLock.suggestExposure(15f, capableSensor)
        val (dark, _) = ExposureLock.suggestExposure(30f, capableSensor)
        val (dim, _) = ExposureLock.suggestExposure(60f, capableSensor)
        val (bright, _) = ExposureLock.suggestExposure(120f, capableSensor)

        assertTrue(veryDark > dark)
        assertTrue(dark > dim)
        assertTrue(dim > bright)
    }

    @Test
    fun exposureStaysWithinSensorLimits() {
        for (luma in 0..255 step 5) {
            for (limits in listOf(capableSensor, limitedSensor)) {
                val (exposure, iso) = ExposureLock.suggestExposure(luma.toFloat(), limits)
                assertTrue(
                    "čas mimo meze: $exposure",
                    exposure in limits.minExposureNanos..limits.maxExposureNanos
                )
                assertTrue("ISO mimo meze: $iso", iso in limits.minIso..limits.maxIso)
            }
        }
    }

    @Test
    fun limitedSensorCompensatesWithHigherIso() {
        // Když snímač neumí dlouhý čas, musí chybějící světlo dohnat citlivostí.
        val (_, capableIso) = ExposureLock.suggestExposure(15f, capableSensor)
        val (_, limitedIso) = ExposureLock.suggestExposure(15f, limitedSensor)
        assertTrue(
            "slabší snímač měl zvýšit ISO: $capableIso vs $limitedIso",
            limitedIso > capableIso
        )
    }

    @Test
    fun nightExposureIsMuchLongerThanPreview() {
        // Náhled běží kolem 1/30 s. Noční snímek musí být výrazně delší,
        // jinak skládání nemá z čeho brát signál.
        val previewNanos = 33_000_000L
        val (exposure, _) = ExposureLock.suggestExposure(16f, capableSensor)
        assertTrue(
            "expozice není delší než náhled: $exposure",
            exposure > previewNanos * 5
        )
    }

    @Test
    fun handheldProfileCapsExposureAndRaisesIsoInstead() {
        val (exposure, iso) = ExposureLock.suggestExposure(
            meanLuma = 10f,
            limits = capableSensor,
            exposureCapNanos = 125_000_000L
        )
        assertEquals(125_000_000L, exposure)
        assertTrue(iso > capableSensor.minIso)
    }

    @Test
    fun brightSceneDoesNotUseSlowestShutter() {
        // U světlé scény by dlouhý čas jen přepálil snímek.
        val (exposure, _) = ExposureLock.suggestExposure(150f, capableSensor)
        assertTrue(exposure < 100_000_000L)
    }

    @Test
    fun totalCaptureStaysUnderTimeout() {
        // Snímání musí skončit dřív, než zasáhne pojistka proti zaseknutí.
        for (luma in listOf(10f, 16f, 30f, 60f, 120f)) {
            val (exposure, _) = ExposureLock.suggestExposure(luma, capableSensor)
            val frames = FrameStacker.recommendedFrames(luma)
            val totalMs = frames * exposure / 1_000_000L
            assertTrue("snímání trvá $totalMs ms", totalMs < 10_000L)
        }
    }

    @Test
    fun sensibleDefaultsWhenSensorUnknown() {
        // I s velmi úzkými mezemi musí vyjít platná hodnota.
        val narrow = ExposureLock.ExposureLimits(
            minExposureNanos = 1_000_000L,
            maxExposureNanos = 1_000_000L,
            minIso = 100,
            maxIso = 100
        )
        val (exposure, iso) = ExposureLock.suggestExposure(10f, narrow)
        assertEquals(1_000_000L, exposure)
        assertEquals(100, iso)
    }

    @Test
    fun captureResultConfirmsRequestedManualExposure() {
        val request = ManualExposureRequest(exposureNanos = 250_000_000L, iso = 200)
        val telemetry = CaptureTelemetry(
            exposureNanos = 248_000_000L,
            iso = 204,
            aeMode = android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE_OFF
        )
        assertTrue(telemetry.matches(request))
    }

    @Test
    fun automaticExposureCanNeverBeReportedAsVerified() {
        val request = ManualExposureRequest(exposureNanos = 250_000_000L, iso = 200)
        val telemetry = CaptureTelemetry(
            exposureNanos = 250_000_000L,
            iso = 200,
            aeMode = android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE_ON
        )
        assertTrue(!telemetry.matches(request))
    }

    @Test
    fun materiallyDifferentSensorValuesAreRejected() {
        val request = ManualExposureRequest(exposureNanos = 250_000_000L, iso = 200)
        val telemetry = CaptureTelemetry(
            exposureNanos = 80_000_000L,
            iso = 800,
            aeMode = android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE_OFF
        )
        assertTrue(!telemetry.matches(request))
    }

    @Test
    fun staleCaptureResultCannotConfirmNewRequest() {
        val request = ManualExposureRequest(
            exposureNanos = 250_000_000L,
            iso = 200,
            submittedAtNanos = 2_000L
        )
        val telemetry = CaptureTelemetry(
            exposureNanos = 250_000_000L,
            iso = 200,
            aeMode = android.hardware.camera2.CaptureRequest.CONTROL_AE_MODE_OFF,
            receivedAtNanos = 1_000L
        )
        assertTrue(!telemetry.matches(request))
    }
}
