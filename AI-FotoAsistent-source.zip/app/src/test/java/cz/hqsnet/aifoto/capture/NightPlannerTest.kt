package cz.hqsnet.aifoto.capture

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NightPlannerTest {
    @Test
    fun autoUsesPortraitProfileForPeople() {
        val plan = NightPlanner.createPlan(
            NightModePreference.AUTO,
            SceneKind.PORTRAIT,
            FrameMetrics(meanLuma = 42f, motion = 0.05f)
        )
        assertEquals(NightCaptureMode.PORTRAIT, plan.mode)
        assertTrue(plan.exposureCapNanos <= 55_000_000L)
    }

    @Test
    fun autoUsesTripodOnlyForVeryStableDarkScene() {
        val plan = NightPlanner.createPlan(
            NightModePreference.AUTO,
            SceneKind.NIGHT,
            FrameMetrics(meanLuma = 25f, motion = 0.004f)
        )
        assertEquals(NightCaptureMode.TRIPOD, plan.mode)
        assertTrue(plan.exposureCapNanos >= 500_000_000L)
        assertTrue(plan.maxAccelerationImpulse < 0.10f)
        assertTrue(plan.maxPeakAngularVelocity < 0.50f)
    }

    @Test
    fun handheldAllowsReplacementAttempts() {
        val plan = NightPlanner.createPlan(
            NightModePreference.HANDHELD,
            SceneKind.NIGHT,
            FrameMetrics(meanLuma = 55f, motion = 0.08f)
        )
        assertEquals(NightCaptureMode.HANDHELD, plan.mode)
        assertTrue(plan.maxAttempts > plan.targetFrames)
        assertTrue(plan.minimumUsableFrames < plan.targetFrames)
    }
}
