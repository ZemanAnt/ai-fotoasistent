package cz.hqsnet.aifoto.analysis

import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import cz.hqsnet.aifoto.coach.FaceObservation
import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.sqrt

class SceneAnalyzer(
    private val onAdvice: (SceneAdvice) -> Unit
) : ImageAnalysis.Analyzer, AutoCloseable {

    private val labeler = ImageLabeling.getClient(
        ImageLabelerOptions.Builder()
            .setConfidenceThreshold(0.45f)
            .build()
    )

    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_NONE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .enableTracking()
            .setMinFaceSize(0.08f)
            .build()
    )

    private val processing = AtomicBoolean(false)
    private var lastAnalysisAt = 0L
    private var previousSamples: IntArray? = null

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (processing.get() || now - lastAnalysisAt < ANALYSIS_INTERVAL_MS) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        processing.set(true)
        lastAnalysisAt = now

        try {
            val metrics = calculateMetrics(imageProxy)
            val rotation = imageProxy.imageInfo.rotationDegrees
            val inputImage = InputImage.fromMediaImage(mediaImage, rotation)
            val labelTask = labeler.process(inputImage)
            val faceTask = faceDetector.process(inputImage)

            Tasks.whenAllComplete(labelTask, faceTask)
                .addOnCompleteListener {
                    try {
                        val labels = if (labelTask.isSuccessful) {
                            labelTask.result.orEmpty().map { it.text to it.confidence }
                        } else {
                            emptyList()
                        }
                        val faces = if (faceTask.isSuccessful) {
                            normalizeFaces(
                                faceTask.result.orEmpty(),
                                imageProxy.width,
                                imageProxy.height,
                                rotation
                            )
                        } else {
                            emptyList()
                        }
                        // Detektor obličejů je pro portrét spolehlivější než obecný
                        // labeler. Přidáváme proto syntetický štítek pouze tehdy,
                        // když byl obličej skutečně nalezen.
                        val recognized = if (faces.isNotEmpty()) {
                            labels + ("face" to 0.92f)
                        } else {
                            labels
                        }
                        onAdvice(
                            SceneAdvisor.recommend(metrics, recognized).copy(faces = faces)
                        )
                    } catch (_: Throwable) {
                        // Jeden vadný výsledek nesmí zastavit živou analýzu.
                    } finally {
                        // ImageProxy musí být uzavřen i tehdy, když některý model
                        // selže nebo callback UI výjimečně vyhodí chybu. Jinak by
                        // CameraX po několika snímcích přestal dodávat další obraz.
                        processing.set(false)
                        imageProxy.close()
                    }
                }
        } catch (_: Throwable) {
            processing.set(false)
            imageProxy.close()
        }
    }

    /**
     * Vzorkuje snímek na pevné mřížce 48×36. Vedle histogramu a pohybu
     * počítá také vizuální těžiště a normalizovanou jemnou kresbu pro kouče.
     */
    private fun calculateMetrics(imageProxy: ImageProxy): FrameMetrics {
        val plane = imageProxy.planes.first()
        val buffer = plane.buffer.duplicate()
        val width = imageProxy.width
        val height = imageProxy.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride

        val samples = IntArray(GRID_WIDTH * GRID_HEIGHT)
        val histogram = IntArray(16)
        val previousRow = IntArray(GRID_WIDTH)

        var index = 0
        var sum = 0.0
        var sumSquares = 0.0
        var shadows = 0
        var highlights = 0
        var edgeTotal = 0.0
        var edgeComparisons = 0

        for (gridY in 0 until GRID_HEIGHT) {
            val y = (((gridY + 0.5f) / GRID_HEIGHT) * height)
                .toInt().coerceIn(0, height - 1)
            var left = -1
            for (gridX in 0 until GRID_WIDTH) {
                val x = (((gridX + 0.5f) / GRID_WIDTH) * width)
                    .toInt().coerceIn(0, width - 1)
                val position = y * rowStride + x * pixelStride
                val luma = if (position < buffer.limit()) {
                    buffer.get(position).toInt() and 0xFF
                } else {
                    0
                }
                samples[index++] = luma
                histogram[(luma / 16).coerceIn(0, 15)]++
                sum += luma
                sumSquares += luma.toDouble() * luma.toDouble()
                if (luma < 28) shadows++
                if (luma > CLIPPING_LUMA) highlights++

                if (left >= 0) {
                    edgeTotal += abs(luma - left)
                    edgeComparisons++
                }
                if (gridY > 0) {
                    edgeTotal += abs(luma - previousRow[gridX])
                    edgeComparisons++
                }
                previousRow[gridX] = luma
                left = luma
            }
        }

        val count = samples.size
        val mean = (sum / count).toFloat()
        val variance = (sumSquares / count - mean * mean).coerceAtLeast(0.0)
        val contrast = sqrt(variance).toFloat()
        val motion = calculateMotion(samples)
        previousSamples = samples
        val averageEdge = if (edgeComparisons == 0) 0f else {
            (edgeTotal / edgeComparisons).toFloat()
        }
        val saliency = calculateSaliency(samples, mean)

        return FrameMetrics(
            meanLuma = mean,
            contrast = contrast,
            shadowRatio = shadows.toFloat() / count,
            highlightRatio = highlights.toFloat() / count,
            motion = motion,
            edgeEnergy = averageEdge,
            sharpnessScore = ((averageEdge - 3f) / 38f).coerceIn(0f, 1f),
            saliencyCenterX = saliency.centerX,
            saliencyCenterY = saliency.centerY,
            saliencyConfidence = saliency.confidence,
            histogram = histogram.map { it.toFloat() / count.toFloat() },
            clipMask = samples.map { it > CLIPPING_LUMA },
            clipMaskWidth = GRID_WIDTH,
            clipMaskHeight = GRID_HEIGHT
        )
    }

    private fun calculateSaliency(samples: IntArray, mean: Float): SaliencyResult {
        var weightTotal = 0.0
        var xTotal = 0.0
        var yTotal = 0.0
        for (y in 1 until GRID_HEIGHT - 1) {
            for (x in 1 until GRID_WIDTH - 1) {
                val i = y * GRID_WIDTH + x
                val horizontal = abs(samples[i + 1] - samples[i - 1])
                val vertical = abs(samples[i + GRID_WIDTH] - samples[i - GRID_WIDTH])
                val localContrast = abs(samples[i] - mean)
                // Hrany mají větší váhu než samotná odlišná světlost. Velká
                // jednolitá obloha tak nepřebije malý, ale detailní hlavní motiv.
                val weight = (horizontal + vertical) * 0.72 + localContrast * 0.28
                if (weight < 8.0) continue
                val nx = (x + 0.5) / GRID_WIDTH
                val ny = (y + 0.5) / GRID_HEIGHT
                weightTotal += weight
                xTotal += nx * weight
                yTotal += ny * weight
            }
        }
        if (weightTotal <= 0.0) return SaliencyResult(0.5f, 0.5f, 0f)
        val confidence = (weightTotal / (samples.size * 58.0)).toFloat().coerceIn(0f, 1f)
        return SaliencyResult(
            centerX = (xTotal / weightTotal).toFloat().coerceIn(0f, 1f),
            centerY = (yTotal / weightTotal).toFloat().coerceIn(0f, 1f),
            confidence = confidence
        )
    }

    private fun normalizeFaces(
        faces: List<Face>,
        sourceWidth: Int,
        sourceHeight: Int,
        rotationDegrees: Int
    ): List<FaceObservation> {
        val rotated = rotationDegrees == 90 || rotationDegrees == 270
        val width = if (rotated) sourceHeight.toFloat() else sourceWidth.toFloat()
        val height = if (rotated) sourceWidth.toFloat() else sourceHeight.toFloat()
        if (width <= 0f || height <= 0f) return emptyList()

        return faces.mapNotNull { face ->
            val box = face.boundingBox
            val normalizedWidth = box.width() / width
            val normalizedHeight = box.height() / height
            if (normalizedWidth <= 0f || normalizedHeight <= 0f) return@mapNotNull null
            FaceObservation(
                trackingId = face.trackingId,
                centerX = (box.exactCenterX() / width).coerceIn(0f, 1f),
                centerY = (box.exactCenterY() / height).coerceIn(0f, 1f),
                width = normalizedWidth.coerceIn(0f, 1f),
                height = normalizedHeight.coerceIn(0f, 1f),
                leftEyeOpenProbability = face.leftEyeOpenProbability.takeIf { it >= 0f },
                rightEyeOpenProbability = face.rightEyeOpenProbability.takeIf { it >= 0f },
                smilingProbability = face.smilingProbability.takeIf { it >= 0f },
                eulerY = face.headEulerAngleY,
                eulerZ = face.headEulerAngleZ
            )
        }
    }

    private fun calculateMotion(current: IntArray): Float {
        val previous = previousSamples ?: return 0f
        if (previous.size != current.size || current.isEmpty()) return 0f

        var difference = 0L
        for (i in current.indices) difference += abs(current[i] - previous[i])
        return (difference.toFloat() / current.size.toFloat() / 255f).coerceIn(0f, 1f)
    }

    fun resetState() {
        previousSamples = null
        lastAnalysisAt = 0L
        processing.set(false)
    }

    override fun close() {
        labeler.close()
        faceDetector.close()
    }

    private data class SaliencyResult(
        val centerX: Float,
        val centerY: Float,
        val confidence: Float
    )

    private companion object {
        const val ANALYSIS_INTERVAL_MS = 650L
        const val CLIPPING_LUMA = 235
        const val GRID_WIDTH = 48
        const val GRID_HEIGHT = 36
    }
}
