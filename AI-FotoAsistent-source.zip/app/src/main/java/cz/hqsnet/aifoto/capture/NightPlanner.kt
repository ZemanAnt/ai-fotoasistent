package cz.hqsnet.aifoto.capture

import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneKind
import kotlin.math.roundToInt

/** Čistá rozhodovací logika; lze ji testovat bez Androidu a fotoaparátu. */
object NightPlanner {

    fun createPlan(
        preference: NightModePreference,
        scene: SceneKind,
        metrics: FrameMetrics
    ): NightCapturePlan {
        val mode = resolveMode(preference, scene, metrics)
        val darkness = ((105f - metrics.meanLuma) / 105f).coerceIn(0f, 1f)

        return when (mode) {
            NightCaptureMode.HANDHELD -> {
                val frames = (7 + darkness * 5f).roundToInt().coerceIn(7, 12)
                NightCapturePlan(
                    mode = mode,
                    targetFrames = frames,
                    maxAttempts = frames + 5,
                    minimumUsableFrames = 4,
                    exposureCapNanos = 125_000_000L,
                    maxGyroRadiansPerFrame = 0.032f,
                    maxPeakAngularVelocity = 1.25f,
                    maxAccelerationImpulse = 0.16f,
                    maxAlignmentShiftPx = 112,
                    maxAlignmentError = 0.19f,
                    deghostThreshold = 34,
                    maxMovingPixelRatio = 0.62f,
                    tileRows = 64,
                    timeoutMs = 22_000L,
                    explanation = "Krátké expozice, obrazové zarovnání a odmítnutí rozhýbaných snímků."
                )
            }

            NightCaptureMode.TRIPOD -> {
                val frames = (5 + darkness * 3f).roundToInt().coerceIn(5, 8)
                NightCapturePlan(
                    mode = mode,
                    targetFrames = frames,
                    maxAttempts = frames + 3,
                    minimumUsableFrames = 3,
                    exposureCapNanos = 800_000_000L,
                    maxGyroRadiansPerFrame = 0.009f,
                    maxPeakAngularVelocity = 0.35f,
                    maxAccelerationImpulse = 0.045f,
                    maxAlignmentShiftPx = 44,
                    maxAlignmentError = 0.12f,
                    deghostThreshold = 26,
                    maxMovingPixelRatio = 0.42f,
                    tileRows = 96,
                    timeoutMs = 28_000L,
                    explanation = "Delší expozice a nižší ISO; série odmítne i malé pohnutí stativem."
                )
            }

            NightCaptureMode.PORTRAIT -> {
                val frames = (6 + darkness * 2f).roundToInt().coerceIn(6, 8)
                NightCapturePlan(
                    mode = mode,
                    targetFrames = frames,
                    maxAttempts = frames + 5,
                    minimumUsableFrames = 4,
                    exposureCapNanos = 55_000_000L,
                    maxGyroRadiansPerFrame = 0.040f,
                    maxPeakAngularVelocity = 1.55f,
                    maxAccelerationImpulse = 0.20f,
                    maxAlignmentShiftPx = 96,
                    maxAlignmentError = 0.21f,
                    deghostThreshold = 24,
                    maxMovingPixelRatio = 0.78f,
                    tileRows = 64,
                    timeoutMs = 18_000L,
                    explanation = "Krátký čas chrání obličej před rozmazáním; pohyb se zachová z referenčního snímku."
                )
            }
        }
    }

    fun resolveMode(
        preference: NightModePreference,
        scene: SceneKind,
        metrics: FrameMetrics
    ): NightCaptureMode = when (preference) {
        NightModePreference.HANDHELD -> NightCaptureMode.HANDHELD
        NightModePreference.TRIPOD -> NightCaptureMode.TRIPOD
        NightModePreference.PORTRAIT -> NightCaptureMode.PORTRAIT
        NightModePreference.AUTO -> when {
            scene == SceneKind.PORTRAIT || scene == SceneKind.PET -> NightCaptureMode.PORTRAIT
            metrics.meanLuma < 48f && metrics.motion < 0.010f -> NightCaptureMode.TRIPOD
            else -> NightCaptureMode.HANDHELD
        }
    }
}
