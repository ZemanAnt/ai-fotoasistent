package cz.hqsnet.aifoto.capture

/** Uživatelská volba nočního režimu. AUTO vybere bezpečný profil podle scény. */
enum class NightModePreference(val displayName: String, val shortLabel: String) {
    AUTO("Automaticky", "AUTO"),
    HANDHELD("Z ruky", "RUKA"),
    TRIPOD("Stativ", "STAT"),
    PORTRAIT("Noční portrét", "POR")
}

/** Reálný profil použitý pro právě probíhající sérii. */
enum class NightCaptureMode(val displayName: String) {
    HANDHELD("Z ruky"),
    TRIPOD("Stativ"),
    PORTRAIT("Noční portrét")
}

/**
 * Kompletní plán jedné výpočetní noční série.
 * Hodnoty nejsou jen pro UI – používá je plánování expozice, gyroskop,
 * registrace snímků i deghosting.
 */
data class NightCapturePlan(
    val mode: NightCaptureMode,
    val targetFrames: Int,
    val maxAttempts: Int,
    val minimumUsableFrames: Int,
    val exposureCapNanos: Long,
    val maxGyroRadiansPerFrame: Float,
    val maxPeakAngularVelocity: Float,
    val maxAccelerationImpulse: Float,
    val maxAlignmentShiftPx: Int,
    val maxAlignmentError: Float,
    val deghostThreshold: Int,
    val maxMovingPixelRatio: Float,
    val tileRows: Int,
    val timeoutMs: Long,
    val explanation: String
) {
    init {
        require(targetFrames >= 2)
        require(maxAttempts >= targetFrames)
        require(minimumUsableFrames in 2..targetFrames)
        require(exposureCapNanos > 0L)
        require(maxGyroRadiansPerFrame > 0f)
        require(maxPeakAngularVelocity > 0f)
        require(maxAccelerationImpulse > 0f)
        require(maxAlignmentShiftPx >= 0)
        require(maxAlignmentError in 0f..1f)
        require(deghostThreshold in 1..255)
        require(maxMovingPixelRatio in 0f..1f)
        require(tileRows in 8..512)
    }
}

/** Pohyb naměřený od zahájení jednoho snímku do jeho doručení. */
data class NightMotionSample(
    val angularDistanceRadians: Float = 0f,
    val peakAngularVelocity: Float = 0f,
    val accelerationImpulse: Float = 0f,
    val sensorAvailable: Boolean = false
)

/** Výsledek obrazové registrace jednoho snímku vůči referenci. */
data class FrameAlignment(
    val offsetX: Int = 0,
    val offsetY: Int = 0,
    /** Normalizovaná průměrná absolutní odchylka 0..1; nižší je lepší. */
    val error: Float = 0f,
    val confidence: Float = 1f
)

enum class FrameRejectReason(val displayName: String) {
    NONE("Přijat"),
    SIZE_CHANGED("Změnil se rozměr snímku"),
    SENSOR_SHAKE("Silné chvění telefonu"),
    ALIGNMENT_FAILED("Snímek nelze spolehlivě zarovnat"),
    EXCESSIVE_SCENE_MOTION("Příliš velká část scény se pohybuje"),
    MEMORY_LIMIT("Nedostatek paměti pro bezpečné zpracování")
}

data class FrameAddResult(
    val accepted: Boolean,
    val complete: Boolean,
    val rejectReason: FrameRejectReason = FrameRejectReason.NONE,
    val alignment: FrameAlignment = FrameAlignment(),
    val movingPixelRatio: Float = 0f,
    val acceptedFrames: Int = 0,
    val attemptedFrames: Int = 0
)

data class NightStackStats(
    val acceptedFrames: Int = 0,
    val rejectedFrames: Int = 0,
    val rejectedByShake: Int = 0,
    val rejectedByAlignment: Int = 0,
    val averageAlignmentError: Float = 0f,
    val averageMovingPixelRatio: Float = 0f,
    val maximumShiftPx: Int = 0
)
