package cz.hqsnet.aifoto.coach

import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Deterministické jádro AI Photo Coach. Neprovádí I/O a je testovatelné bez Androidu.
 * V každém cyklu vrací jediný nejdůležitější pokyn, aby hledáček uživatele nezahltil.
 */
object PhotoCoachEngine {

    fun evaluate(
        advice: SceneAdvice,
        pose: DevicePose,
        telemetry: CoachExposure,
        mode: CoachMode
    ): CoachCue {
        val metrics = advice.metrics
        val faces = advice.faces.sortedByDescending { it.areaRatio }
        val primaryFace = faces.firstOrNull()
        val shutterSeconds = (telemetry.exposureNanos ?: 0L) / 1_000_000_000.0

        // 1. Kritická stabilita má přednost před kompozicí. Prah se zpřísní
        // při dlouhém skutečném čase, ne podle hodnoty, kterou aplikace pouze navrhla.
        val motionLimit = when {
            shutterSeconds >= 0.08 -> 0.035f
            shutterSeconds >= 0.03 -> 0.055f
            advice.scene == SceneKind.ACTION -> 0.18f
            else -> 0.095f
        }
        if (metrics.motion > motionLimit) {
            return CoachCue(
                id = "hold-steady",
                category = CoachCategory.STABILITY,
                severity = if (metrics.motion > motionLimit * 1.8f) CoachSeverity.URGENT else CoachSeverity.WARNING,
                title = "Zklidněte telefon",
                detail = if (shutterSeconds >= 0.03) {
                    "Opřete lokty nebo telefon. Skutečný čas je ${formatShutter(shutterSeconds)}."
                } else {
                    "Pohyb telefonu může snímek změkčit. Na okamžik se zastavte."
                },
                direction = CoachDirection.HOLD,
                score = readinessFrom(metrics.motion, 0f, motionLimit),
                rationale = "Pohyb obrazu ${(metrics.motion * 100).roundToInt()} % překročil bezpečný práh."
            )
        }

        // 2. Dokument vyžaduje rovnoběžnost s podložkou; běžná scéna rovný horizont.
        if (pose.sensorAvailable && advice.scene == SceneKind.DOCUMENT && pose.flatness < 0.82f) {
            return CoachCue(
                id = "document-parallel",
                category = CoachCategory.PERSPECTIVE,
                severity = CoachSeverity.WARNING,
                title = "Srovnejte telefon s papírem",
                detail = "Nakloňte telefon tak, aby byl displej rovnoběžně s dokumentem.",
                direction = CoachDirection.LEVEL,
                score = (pose.flatness * 100).roundToInt(),
                rationale = "Rovnoběžnost s podložkou je jen ${(pose.flatness * 100).roundToInt()} %."
            )
        }
        val levelRequired = advice.scene in setOf(
            SceneKind.LANDSCAPE,
            SceneKind.ARCHITECTURE,
            SceneKind.DOCUMENT,
            SceneKind.GENERAL
        )
        if (pose.sensorAvailable && levelRequired && abs(pose.levelErrorDegrees) > 1.8f) {
            val rotateRight = pose.levelErrorDegrees > 0f
            return CoachCue(
                id = "level-horizon",
                category = CoachCategory.LEVEL,
                severity = if (abs(pose.levelErrorDegrees) > 5f) CoachSeverity.WARNING else CoachSeverity.INFO,
                title = "Srovnejte horizont",
                detail = "Pootočte telefon ${if (rotateRight) "doprava" else "doleva"} o ${"%.1f".format(abs(pose.levelErrorDegrees))}°.",
                direction = if (rotateRight) CoachDirection.RIGHT else CoachDirection.LEFT,
                score = (100f - abs(pose.levelErrorDegrees) * 9f).roundToInt().coerceIn(0, 100),
                rationale = "Odchylka od roviny je ${"%.1f".format(abs(pose.levelErrorDegrees))}°."
            )
        }

        // 3. Přepaly jsou nevratné. V noci tolerujeme bodové zdroje světla.
        val highlightLimit = if (advice.scene == SceneKind.NIGHT) 0.09f else 0.035f
        if (metrics.highlightRatio > highlightLimit) {
            return CoachCue(
                id = "protect-highlights",
                category = CoachCategory.EXPOSURE,
                severity = if (metrics.highlightRatio > highlightLimit * 2f) CoachSeverity.WARNING else CoachSeverity.INFO,
                title = "Chraňte světlá místa",
                detail = "Snižte EV nebo změňte úhel; vypálené plochy už nepůjdou obnovit.",
                direction = CoachDirection.DOWN,
                score = readinessFrom(metrics.highlightRatio, 0f, highlightLimit),
                rationale = "Přepal zabírá ${(metrics.highlightRatio * 100).roundToInt()} % analyzované plochy."
            )
        }

        // 4. Portrétní vzdálenost, okraje a zavřené oči.
        if (primaryFace != null) {
            if (primaryFace.bothEyesLikelyClosed) {
                return CoachCue(
                    id = "eyes-closed",
                    category = CoachCategory.FACE,
                    severity = CoachSeverity.INFO,
                    title = "Počkejte na otevřené oči",
                    detail = "Kouč zachytil pravděpodobně zavřené obě oči.",
                    direction = CoachDirection.HOLD,
                    score = 35,
                    targetX = primaryFace.centerX,
                    targetY = primaryFace.centerY,
                    rationale = "Pravděpodobnost otevření obou očí je nízká."
                )
            }
            if (primaryFace.areaRatio < 0.035f && advice.scene in setOf(SceneKind.PORTRAIT, SceneKind.PET)) {
                return CoachCue(
                    id = "subject-too-small",
                    category = CoachCategory.DISTANCE,
                    severity = CoachSeverity.INFO,
                    title = "Přibližte se k hlavnímu motivu",
                    detail = "Obličej je v obraze malý. Přistupte blíž nebo použijte doporučený objektiv.",
                    direction = CoachDirection.CLOSER,
                    score = (primaryFace.areaRatio / 0.035f * 100).roundToInt().coerceIn(0, 100),
                    targetX = primaryFace.centerX,
                    targetY = primaryFace.centerY,
                    rationale = "Obličej zabírá jen ${(primaryFace.areaRatio * 100).roundToInt()} % obrazu."
                )
            }
            if (primaryFace.areaRatio > 0.42f) {
                return CoachCue(
                    id = "subject-too-large",
                    category = CoachCategory.DISTANCE,
                    severity = CoachSeverity.INFO,
                    title = "Ustupte o malý krok",
                    detail = "Kolem hlavy chybí prostor a okraje budou působit stísněně.",
                    direction = CoachDirection.FARTHER,
                    score = 55,
                    targetX = primaryFace.centerX,
                    targetY = primaryFace.centerY,
                    rationale = "Obličej zabírá ${(primaryFace.areaRatio * 100).roundToInt()} % obrazu."
                )
            }
            val edgeMarginX = primaryFace.width * 0.62f + 0.035f
            val edgeMarginY = primaryFace.height * 0.58f + 0.035f
            if (primaryFace.centerX < edgeMarginX || primaryFace.centerX > 1f - edgeMarginX) {
                val move = if (primaryFace.centerX < 0.5f) CoachDirection.LEFT else CoachDirection.RIGHT
                return CoachCue(
                    id = "face-edge-x",
                    category = CoachCategory.COMPOSITION,
                    severity = CoachSeverity.WARNING,
                    title = "Nenechte obličej uříznout okrajem",
                    detail = "Posuňte záběr ${if (move == CoachDirection.LEFT) "doleva" else "doprava"}, aby kolem obličeje zůstal prostor.",
                    direction = move,
                    score = 48,
                    targetX = primaryFace.centerX,
                    targetY = primaryFace.centerY,
                    rationale = "Obličej je příliš blízko bočního okraje."
                )
            }
            if (primaryFace.centerY < edgeMarginY) {
                return CoachCue(
                    id = "face-edge-top",
                    category = CoachCategory.COMPOSITION,
                    severity = CoachSeverity.WARNING,
                    title = "Přidejte prostor nad hlavou",
                    detail = "Posuňte záběr lehce nahoru, aby temeno nebylo na hraně.",
                    direction = CoachDirection.UP,
                    score = 52,
                    targetX = primaryFace.centerX,
                    targetY = primaryFace.centerY,
                    rationale = "Horní část obličeje je příliš blízko okraje."
                )
            }
        }

        // 5. Nízká obrazová kresba v dostatečném světle značí neostrost nebo nenalezený motiv.
        if (metrics.meanLuma > 70f && metrics.sharpnessScore < 0.22f && metrics.motion < 0.04f) {
            return CoachCue(
                id = "focus-soft",
                category = CoachCategory.FOCUS,
                severity = CoachSeverity.INFO,
                title = "Klepněte na hlavní objekt",
                detail = "Obraz má málo jemných hran. Zkontrolujte ostření a čistotu objektivu.",
                direction = CoachDirection.NONE,
                score = (metrics.sharpnessScore * 100).roundToInt(),
                targetX = metrics.saliencyCenterX,
                targetY = metrics.saliencyCenterY,
                rationale = "Skóre ostrosti je ${(metrics.sharpnessScore * 100).roundToInt()} %."
            )
        }

        // 6. Jemná kompoziční navigace podle vizuálního těžiště. V jednoduchém
        // režimu ji ukazujeme jen při velké chybě, aby aplikace nepůsobila nervózně.
        val subjectX = primaryFace?.centerX ?: metrics.saliencyCenterX
        val subjectY = primaryFace?.centerY ?: metrics.saliencyCenterY
        val target = targetFor(advice.scene, primaryFace != null, faces.size)
        val dx = subjectX - target.first
        val dy = subjectY - target.second
        val distance = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        val compositionThreshold = if (mode == CoachMode.SIMPLE) 0.24f else 0.15f
        if (metrics.saliencyConfidence > 0.12f && distance > compositionThreshold) {
            val horizontal = abs(dx) >= abs(dy)
            val direction = if (horizontal) {
                if (dx < 0f) CoachDirection.LEFT else CoachDirection.RIGHT
            } else {
                if (dy < 0f) CoachDirection.UP else CoachDirection.DOWN
            }
            return CoachCue(
                id = "composition-${direction.name.lowercase()}",
                category = CoachCategory.COMPOSITION,
                severity = CoachSeverity.INFO,
                title = "Posuňte záběr ${directionWord(direction)}",
                detail = "Hlavní motiv se přiblíží k přirozenému kompozičnímu bodu.",
                direction = direction,
                score = (100f - distance * 180f).roundToInt().coerceIn(0, 100),
                targetX = target.first,
                targetY = target.second,
                rationale = "Vizuální těžiště je od cílového bodu vzdálené ${(distance * 100).roundToInt()} % šířky obrazu."
            )
        }

        val score = calculateReadyScore(advice, pose, primaryFace)
        return CoachCue(
            id = "ready",
            category = CoachCategory.READY,
            severity = CoachSeverity.READY,
            title = if (score >= 88) "Teď můžete fotit" else "Záběr je připravený",
            detail = when (advice.scene) {
                SceneKind.PORTRAIT -> "Obličej, stabilita i světlo vypadají dobře."
                SceneKind.NIGHT -> "Držte telefon klidně ještě okamžik po stisku spouště."
                SceneKind.DOCUMENT -> "Rovina, ostrost a expozice jsou v bezpečném rozsahu."
                else -> "Kompozice, stabilita a světlo jsou v bezpečném rozsahu."
            },
            direction = CoachDirection.NONE,
            score = score,
            targetX = primaryFace?.centerX ?: metrics.saliencyCenterX,
            targetY = primaryFace?.centerY ?: metrics.saliencyCenterY,
            rationale = "Kouč nenašel kritickou překážku pro pořízení snímku."
        )
    }

    private fun targetFor(scene: SceneKind, hasFace: Boolean, faceCount: Int): Pair<Float, Float> {
        if (faceCount > 1) return 0.5f to 0.48f
        if (hasFace) return 0.5f to 0.42f
        return when (scene) {
            SceneKind.LANDSCAPE -> 0.5f to 0.58f
            SceneKind.ARCHITECTURE, SceneKind.DOCUMENT -> 0.5f to 0.5f
            SceneKind.FOOD, SceneKind.MACRO -> 0.42f to 0.48f
            else -> 0.5f to 0.5f
        }
    }

    private fun calculateReadyScore(
        advice: SceneAdvice,
        pose: DevicePose,
        face: FaceObservation?
    ): Int {
        var score = 100f
        score -= advice.metrics.motion * 170f
        score -= advice.metrics.highlightRatio * 180f
        score -= (0.30f - advice.metrics.sharpnessScore).coerceAtLeast(0f) * 80f
        if (pose.sensorAvailable) score -= (abs(pose.levelErrorDegrees) - 1f).coerceAtLeast(0f) * 2.5f
        if (face != null && face.areaRatio < 0.025f) score -= 10f
        return score.roundToInt().coerceIn(0, 100)
    }

    private fun readinessFrom(value: Float, ideal: Float, limit: Float): Int {
        if (limit <= ideal) return 0
        return (100f - ((value - ideal) / (limit - ideal) * 100f))
            .roundToInt()
            .coerceIn(0, 100)
    }

    private fun directionWord(direction: CoachDirection): String = when (direction) {
        CoachDirection.LEFT -> "doleva"
        CoachDirection.RIGHT -> "doprava"
        CoachDirection.UP -> "nahoru"
        CoachDirection.DOWN -> "dolů"
        else -> "mírně"
    }

    private fun formatShutter(seconds: Double): String = when {
        seconds >= 1.0 -> "%.1f s".format(seconds)
        seconds > 0.0 -> "1/%.0f s".format(1.0 / seconds)
        else -> "automatický"
    }
}

/**
 * Potlačuje blikání pokynu. Varování reaguje rychle, běžná kompoziční rada se
 * musí zopakovat dvakrát a stav READY třikrát.
 */
class CoachCueStabilizer {
    private var candidateId: String? = null
    private var candidateCount = 0
    private var current: CoachCue = CoachCue.Initial

    fun update(next: CoachCue): CoachCue {
        if (next.id == current.id) {
            candidateId = null
            candidateCount = 0
            current = next
            return current
        }
        if (next.severity == CoachSeverity.URGENT) {
            current = next
            candidateId = null
            candidateCount = 0
            return current
        }
        if (candidateId == next.id) candidateCount++ else {
            candidateId = next.id
            candidateCount = 1
        }
        val required = when (next.severity) {
            CoachSeverity.WARNING -> 1
            CoachSeverity.READY -> 3
            else -> 2
        }
        if (candidateCount >= required) {
            current = next
            candidateId = null
            candidateCount = 0
        }
        return current
    }

    fun reset() {
        candidateId = null
        candidateCount = 0
        current = CoachCue.Initial
    }
}
