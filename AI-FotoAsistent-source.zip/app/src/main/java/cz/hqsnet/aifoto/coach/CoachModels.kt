package cz.hqsnet.aifoto.coach

/** Množství informací, které AI kouč ukazuje v hledáčku. */
enum class CoachMode(val displayName: String, val shortLabel: String) {
    SIMPLE("Jednoduchý", "JEDN"),
    COACH("AI kouč", "KOUČ"),
    PRO("Pro", "PRO");

    fun next(): CoachMode = entries[(ordinal + 1) % entries.size]
}

enum class CoachSeverity {
    READY,
    INFO,
    WARNING,
    URGENT
}

enum class CoachDirection {
    NONE,
    LEFT,
    RIGHT,
    UP,
    DOWN,
    CLOSER,
    FARTHER,
    HOLD,
    LEVEL
}

enum class CoachCategory {
    READY,
    STABILITY,
    LEVEL,
    EXPOSURE,
    COMPOSITION,
    DISTANCE,
    FOCUS,
    FACE,
    PERSPECTIVE
}

/** Normalizovaná informace o obličeji v obraze po započtení rotace. */
data class FaceObservation(
    val trackingId: Int? = null,
    val centerX: Float,
    val centerY: Float,
    val width: Float,
    val height: Float,
    val leftEyeOpenProbability: Float? = null,
    val rightEyeOpenProbability: Float? = null,
    val smilingProbability: Float? = null,
    val eulerY: Float = 0f,
    val eulerZ: Float = 0f
) {
    val areaRatio: Float get() = (width * height).coerceIn(0f, 1f)
    val bothEyesLikelyClosed: Boolean
        get() = (leftEyeOpenProbability ?: 1f) < 0.32f &&
            (rightEyeOpenProbability ?: 1f) < 0.32f
}

/** Poloha telefonu vůči gravitaci. Hodnoty jsou už převedené do aktuální orientace obrazovky. */
data class DevicePose(
    val levelErrorDegrees: Float = 0f,
    /** 0 = telefon svisle, 1 = displej přibližně rovnoběžně se zemí. */
    val flatness: Float = 0f,
    val sensorAvailable: Boolean = false
)

/** Skutečná expozice přečtená z CaptureResult, bez závislosti jádra na Android API. */
data class CoachExposure(
    val exposureNanos: Long? = null,
    val iso: Int? = null
)

data class CoachCue(
    val id: String,
    val category: CoachCategory,
    val severity: CoachSeverity,
    val title: String,
    val detail: String,
    val direction: CoachDirection = CoachDirection.NONE,
    /** 0–100; vyjadřuje připravenost právě pro tento pokyn. */
    val score: Int = 0,
    val targetX: Float? = null,
    val targetY: Float? = null,
    val rationale: String = detail
) {
    companion object {
        val Initial = CoachCue(
            id = "initial",
            category = CoachCategory.READY,
            severity = CoachSeverity.INFO,
            title = "Namiřte na scénu",
            detail = "Kouč vyhodnotí světlo, ostrost, pohyb a kompozici.",
            score = 0
        )
    }
}

data class CoachState(
    val mode: CoachMode = CoachMode.COACH,
    val cue: CoachCue = CoachCue.Initial,
    val pose: DevicePose = DevicePose(),
    val faceCount: Int = 0,
    val compositionScore: Int = 0,
    val ready: Boolean = false,
    val lastCapturedCue: CoachCue? = null,
    val cueRevision: Long = 0L
)
