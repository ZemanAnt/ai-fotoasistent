package cz.hqsnet.aifoto.capture

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Malý luma obraz pro registraci; neobsahuje žádnou Android závislost. */
data class LumaFrame(
    val width: Int,
    val height: Int,
    val data: ByteArray
) {
    init {
        require(width > 0 && height > 0)
        require(data.size == width * height)
    }

    operator fun get(x: Int, y: Int): Int = data[y * width + x].toInt() and 0xFF
}

/** Čistý translatační registrátor, testovatelný na syntetických obrazech. */
object NightAlignment {
    fun estimate(
        reference: LumaFrame,
        current: LumaFrame,
        maxShift: Int,
        maxAlignmentError: Float
    ): FrameAlignment {
        if (reference.width != current.width || reference.height != current.height) {
            return FrameAlignment(error = 1f, confidence = 0f)
        }
        val boundedShift = maxShift.coerceIn(0, MAX_SHIFT)
        val textureConfidence = textureConfidence(reference)
        if (textureConfidence <= MIN_TEXTURE_CONFIDENCE) {
            // Jednolitá tma, obloha nebo rozostřená stěna neposkytují žádnou
            // informaci o posunu. Nulový posun je pravdivější než náhodný vítěz;
            // FrameStacker ho smí použít jen s nezávislým potvrzením senzorů.
            return FrameAlignment(
                offsetX = 0,
                offsetY = 0,
                error = error(reference, current, 0, 0, SAMPLE_STEP_FINE),
                confidence = 0f
            )
        }
        if (boundedShift == 0) {
            val zeroError = error(reference, current, 0, 0, SAMPLE_STEP_FINE)
            return FrameAlignment(
                error = zeroError,
                confidence = (
                    (1f - zeroError / max(maxAlignmentError, 0.001f)).coerceIn(0f, 1f) *
                        textureConfidence
                    )
            )
        }

        // Projdeme všechny celočíselné posuny, ale na řídkém vzorku obrazu.
        // Tím se správný posun nemůže ztratit kvůli liché/sudé paritě mřížky.
        val coarse = ArrayList<Candidate>((boundedShift * 2 + 1) * (boundedShift * 2 + 1))
        for (dy in -boundedShift..boundedShift) {
            for (dx in -boundedShift..boundedShift) {
                coarse += Candidate(dx, dy, error(reference, current, dx, dy, SAMPLE_STEP_COARSE))
            }
        }

        // Jediný hrubý vítěz nestačí: u šumové noční scény může soused správného
        // posunu dočasně prohrát s náhodnou shodou. Jemně proto ověříme několik
        // nejlepších, prostorově odlišných kandidátů.
        val seeds = coarse.sortedBy { it.error }.fold(mutableListOf<Candidate>()) { selected, candidate ->
            if (selected.size < COARSE_SEEDS && selected.none {
                    abs(it.dx - candidate.dx) <= 1 && abs(it.dy - candidate.dy) <= 1
                }
            ) {
                selected += candidate
            }
            selected
        }

        val evaluated = HashSet<Long>()
        var best = Candidate(0, 0, Float.MAX_VALUE)
        var secondBestError = Float.MAX_VALUE
        val fineRadius = 1

        fun evaluate(dx: Int, dy: Int) {
            if (dx !in -boundedShift..boundedShift || dy !in -boundedShift..boundedShift) return
            val key = (dx.toLong() shl 32) xor (dy.toLong() and 0xffffffffL)
            if (!evaluated.add(key)) return
            val candidateError = error(reference, current, dx, dy, SAMPLE_STEP_FINE)
            if (candidateError < best.error) {
                secondBestError = best.error
                best = Candidate(dx, dy, candidateError)
            } else if (candidateError < secondBestError && (dx != best.dx || dy != best.dy)) {
                secondBestError = candidateError
            }
        }

        for (seed in seeds) {
            for (fy in (seed.dy - fineRadius)..(seed.dy + fineRadius)) {
                for (fx in (seed.dx - fineRadius)..(seed.dx + fineRadius)) evaluate(fx, fy)
            }
        }
        // Nulový posun je důležitý u stativu a musí být ověřen i tehdy, když
        // se kvůli blikání světel nedostal mezi hrubé kandidáty.
        evaluate(0, 0)

        val gapConfidence = if (secondBestError.isFinite() && secondBestError > 0f) {
            ((secondBestError - best.error) / secondBestError * 4f).coerceIn(0f, 1f)
        } else 1f
        val errorConfidence = (1f - best.error / max(maxAlignmentError, 0.001f))
            .coerceIn(0f, 1f)
        // Důvěra vyžaduje současně nízkou chybu, jednoznačný vítězný posun
        // a dostatek obrazové textury. Žádná složka sama nesmí přebít ostatní.
        val confidence = (errorConfidence * gapConfidence * textureConfidence)
            .coerceIn(0f, 1f)
        return FrameAlignment(best.dx, best.dy, best.error, confidence)
    }

    private fun textureConfidence(frame: LumaFrame): Float {
        var difference = 0L
        var samples = 0
        var y = MARGIN
        while (y < frame.height - MARGIN - 1) {
            var x = MARGIN
            while (x < frame.width - MARGIN - 1) {
                val center = frame[x, y]
                difference += abs(center - frame[x + 1, y])
                difference += abs(center - frame[x, y + 1])
                samples += 2
                x += TEXTURE_SAMPLE_STEP
            }
            y += TEXTURE_SAMPLE_STEP
        }
        if (samples == 0) return 0f
        val averageDifference = difference.toFloat() / samples
        return (averageDifference / TEXTURE_FULL_CONFIDENCE_DIFFERENCE).coerceIn(0f, 1f)
    }

    fun movingRatio(
        reference: LumaFrame,
        current: LumaFrame,
        alignment: FrameAlignment,
        threshold: Int
    ): Float {
        val dx = alignment.offsetX
        val dy = alignment.offsetY
        val startX = max(0, -dx)
        val endX = min(reference.width, current.width - dx)
        val startY = max(0, -dy)
        val endY = min(reference.height, current.height - dy)
        if (endX <= startX || endY <= startY) return 1f

        var moving = 0
        var compared = 0
        var y = startY
        while (y < endY) {
            var x = startX
            while (x < endX) {
                if (abs(reference[x, y] - current[x + dx, y + dy]) > threshold) moving++
                compared++
                x += 2
            }
            y += 2
        }
        return if (compared == 0) 1f else moving.toFloat() / compared
    }

    private fun error(
        reference: LumaFrame,
        current: LumaFrame,
        dx: Int,
        dy: Int,
        sampleStep: Int
    ): Float {
        val startX = max(MARGIN, -dx + MARGIN)
        val endX = min(reference.width - MARGIN, current.width - dx - MARGIN)
        val startY = max(MARGIN, -dy + MARGIN)
        val endY = min(reference.height - MARGIN, current.height - dy - MARGIN)
        if (endX - startX < MIN_OVERLAP || endY - startY < MIN_OVERLAP) return 1f

        var sum = 0L
        var samples = 0
        var y = startY
        while (y < endY) {
            var x = startX
            while (x < endX) {
                sum += min(64, abs(reference[x, y] - current[x + dx, y + dy]))
                samples++
                x += sampleStep
            }
            y += sampleStep
        }
        return if (samples == 0) 1f else (sum.toFloat() / samples) / 64f
    }

    private data class Candidate(val dx: Int, val dy: Int, val error: Float)

    private const val MAX_SHIFT = 24
    private const val COARSE_SEEDS = 8
    private const val TEXTURE_SAMPLE_STEP = 3
    private const val TEXTURE_FULL_CONFIDENCE_DIFFERENCE = 18f
    private const val MIN_TEXTURE_CONFIDENCE = 0.04f
    private const val MARGIN = 5
    private const val MIN_OVERLAP = 24
    private const val SAMPLE_STEP_COARSE = 5
    private const val SAMPLE_STEP_FINE = 2
}
