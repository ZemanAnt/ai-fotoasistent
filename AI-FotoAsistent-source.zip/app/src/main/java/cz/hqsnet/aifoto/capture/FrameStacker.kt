package cz.hqsnet.aifoto.capture

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Výpočetní skládání nočních snímků v0.8.
 *
 * Na rozdíl od prostého průměrování:
 *  1. každý snímek se zarovná na referenci pomocí nízkofrekvenční luma mapy,
 *  2. silně rozhýbané nebo nezarovnatelné snímky se odmítnou,
 *  3. pohybující se objekty se detekují po pixelech a zůstanou z reference,
 *  4. plné rozlišení se zpracovává po dlaždicích, takže není nutné držet
 *     kopie všech snímků v paměti.
 *
 * V paměti zůstává jen průběžný RGB průměr (IntArray), počet přijatých vzorků
 * (ByteArray), malá referenční luma mapa a právě zpracovávaná Bitmap.
 */
class FrameStacker(
    private val targetFrames: Int = 8,
    private val config: NightCapturePlan = fallbackPlan(targetFrames)
) {
    private var width = 0
    private var height = 0
    private var averagePixels: IntArray? = null
    private var acceptedCounts: ByteArray? = null
    private var referenceThumbnail: LumaFrame? = null

    private var collected = 0
    private var attempts = 0
    private var rejected = 0
    private var rejectedByShake = 0
    private var rejectedByAlignment = 0
    private var alignmentErrorTotal = 0f
    private var movingRatioTotal = 0f
    private var maximumShift = 0

    var rotationDegrees: Int = 0
        private set

    val collectedFrames: Int get() = collected
    val attemptedFrames: Int get() = attempts
    val rejectedFrames: Int get() = rejected
    val progress: Float get() = if (targetFrames <= 0) 1f else collected.toFloat() / targetFrames
    val isComplete: Boolean get() = collected >= targetFrames
    val attemptsExhausted: Boolean get() = attempts >= config.maxAttempts

    val stats: NightStackStats
        get() = NightStackStats(
            acceptedFrames = collected,
            rejectedFrames = rejected,
            rejectedByShake = rejectedByShake,
            rejectedByAlignment = rejectedByAlignment,
            averageAlignmentError = if (collected > 1) alignmentErrorTotal / (collected - 1) else 0f,
            averageMovingPixelRatio = if (collected > 1) movingRatioTotal / (collected - 1) else 0f,
            maximumShiftPx = maximumShift
        )

    /** Zachová kompatibilitu se starší cestou; nová integrace používá detailní výsledek. */
    fun addBitmap(bitmap: Bitmap, rotation: Int): Boolean =
        addAlignedBitmap(bitmap, rotation, NightMotionSample()).complete

    fun addAlignedBitmap(
        bitmap: Bitmap,
        rotation: Int,
        motion: NightMotionSample
    ): FrameAddResult {
        if (isComplete || attemptsExhausted) return result(accepted = false)
        attempts++

        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return reject(FrameRejectReason.SIZE_CHANGED)

        // Gyroskop je nezávislá kontrola. Obraz může vypadat podobně i při
        // šmouze v jednolité tmavé ploše, kde registrace nemá dost detailů.
        if (motion.sensorAvailable && (
                motion.angularDistanceRadians > config.maxGyroRadiansPerFrame ||
                    motion.peakAngularVelocity > config.maxPeakAngularVelocity ||
                    motion.accelerationImpulse > config.maxAccelerationImpulse
                )
        ) {
            rejectedByShake++
            return reject(FrameRejectReason.SENSOR_SHAKE)
        }

        if (averagePixels == null) {
            val requiredBytes = w.toLong() * h.toLong() * 5L
            if (requiredBytes > MAX_WORKING_SET_BYTES) {
                return reject(FrameRejectReason.MEMORY_LIMIT)
            }
            return try {
                val initial = IntArray(w * h)
                bitmap.getPixels(initial, 0, w, 0, 0, w, h)
                averagePixels = initial
                acceptedCounts = ByteArray(w * h) { 1 }
                referenceThumbnail = createThumbnail(bitmap)
                width = w
                height = h
                rotationDegrees = rotation
                collected = 1
                result(accepted = true)
            } catch (_: OutOfMemoryError) {
                reset()
                reject(FrameRejectReason.MEMORY_LIMIT)
            }
        }

        if (w != width || h != height) {
            return reject(FrameRejectReason.SIZE_CHANGED)
        }

        val reference = referenceThumbnail ?: return reject(FrameRejectReason.ALIGNMENT_FAILED)
        val current = createThumbnail(bitmap)
        val scaleX = width.toFloat() / reference.width
        val scaleY = height.toFloat() / reference.height
        val maxThumbShift = ceil(
            config.maxAlignmentShiftPx / max(1f, min(scaleX, scaleY))
        ).toInt().coerceIn(1, MAX_THUMB_SHIFT)
        val measuredAlignment = NightAlignment.estimate(
            reference,
            current,
            maxThumbShift,
            config.maxAlignmentError
        )
        val sensorConfirmsStillness = motion.sensorAvailable &&
            motion.angularDistanceRadians <= config.maxGyroRadiansPerFrame * SENSOR_FALLBACK_FACTOR &&
            motion.peakAngularVelocity <= config.maxPeakAngularVelocity * SENSOR_FALLBACK_FACTOR &&
            motion.accelerationImpulse <= config.maxAccelerationImpulse * SENSOR_FALLBACK_FACTOR
        val alignment = when {
            measuredAlignment.error > config.maxAlignmentError -> measuredAlignment
            measuredAlignment.confidence >= MIN_ALIGNMENT_CONFIDENCE -> measuredAlignment
            sensorConfirmsStillness -> measuredAlignment.copy(offsetX = 0, offsetY = 0)
            else -> measuredAlignment
        }
        if (alignment.error > config.maxAlignmentError ||
            (alignment.confidence < MIN_ALIGNMENT_CONFIDENCE && !sensorConfirmsStillness)
        ) {
            rejectedByAlignment++
            return reject(FrameRejectReason.ALIGNMENT_FAILED, alignment)
        }

        val fullShiftX = (alignment.offsetX * width.toFloat() / reference.width).roundToInt()
            .coerceIn(-config.maxAlignmentShiftPx, config.maxAlignmentShiftPx)
        val fullShiftY = (alignment.offsetY * height.toFloat() / reference.height).roundToInt()
            .coerceIn(-config.maxAlignmentShiftPx, config.maxAlignmentShiftPx)
        val fullAlignment = alignment.copy(offsetX = fullShiftX, offsetY = fullShiftY)
        maximumShift = max(maximumShift, max(abs(fullShiftX), abs(fullShiftY)))

        // Před drahým full-res blendingem odhadneme pohyb na miniatuře.
        // Zabrání to tomu, aby chybně zarovnaný snímek částečně kontaminoval průměr.
        val movingRatioEstimate = NightAlignment.movingRatio(
            reference,
            current,
            alignment,
            max(18, config.deghostThreshold - 4)
        )
        if (movingRatioEstimate > config.maxMovingPixelRatio) {
            rejectedByAlignment++
            return reject(FrameRejectReason.EXCESSIVE_SCENE_MOTION, fullAlignment, movingRatioEstimate)
        }

        val movingRatio = blendAligned(bitmap, fullShiftX, fullShiftY)
        collected++
        alignmentErrorTotal += alignment.error
        movingRatioTotal += movingRatio

        return result(
            accepted = true,
            alignment = fullAlignment,
            movingPixelRatio = movingRatio
        )
    }

    /**
     * Vytvoří hotový snímek. Skládání už provedlo temporální odšumění;
     * závěr používá pouze šetrnou globální tónovou křivku bez destruktivního
     * doostřování, které by znovu vytáhlo potlačený šum.
     */
    fun buildBitmap(postProcess: Boolean = true): Bitmap? {
        val pixels = averagePixels ?: return null
        if (collected == 0 || width <= 0 || height <= 0) return null
        if (postProcess) applyNightToneMap(pixels)
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }

    fun reset() {
        averagePixels = null
        acceptedCounts = null
        referenceThumbnail = null
        width = 0
        height = 0
        collected = 0
        attempts = 0
        rejected = 0
        rejectedByShake = 0
        rejectedByAlignment = 0
        alignmentErrorTotal = 0f
        movingRatioTotal = 0f
        maximumShift = 0
        rotationDegrees = 0
    }

    private fun createThumbnail(bitmap: Bitmap): LumaFrame {
        val srcW = bitmap.width
        val srcH = bitmap.height
        val scale = min(1f, THUMBNAIL_LONG_EDGE.toFloat() / max(srcW, srcH))
        val thumbW = max(MIN_THUMBNAIL_EDGE, (srcW * scale).roundToInt())
        val thumbH = max(MIN_THUMBNAIL_EDGE, (srcH * scale).roundToInt())
        val data = ByteArray(thumbW * thumbH)
        val row = IntArray(srcW)

        for (ty in 0 until thumbH) {
            val sy = ((ty + 0.5f) * srcH / thumbH).toInt().coerceIn(0, srcH - 1)
            bitmap.getPixels(row, 0, srcW, 0, sy, srcW, 1)
            val dst = ty * thumbW
            for (tx in 0 until thumbW) {
                val sx = ((tx + 0.5f) * srcW / thumbW).toInt().coerceIn(0, srcW - 1)
                val p = row[sx]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                data[dst + tx] = ((77 * r + 150 * g + 29 * b) shr 8).toByte()
            }
        }
        return LumaFrame(thumbW, thumbH, data)
    }

    /** Aktualizuje průběžný průměr po dlaždicích; nealokuje full-res kopii snímku. */
    private fun blendAligned(bitmap: Bitmap, shiftX: Int, shiftY: Int): Float {
        val average = averagePixels ?: return 1f
        val counts = acceptedCounts ?: return 1f
        val tileRows = config.tileRows.coerceAtMost(height)
        val tile = IntArray(width * tileRows)
        val validXStart = max(0, -shiftX)
        val validXEnd = min(width, width - shiftX)
        if (validXEnd <= validXStart) return 1f

        var moving = 0L
        var compared = 0L
        var outTileStart = 0
        while (outTileStart < height) {
            val outTileEnd = min(height, outTileStart + tileRows)
            val validOutStart = max(outTileStart, -shiftY)
            val validOutEnd = min(outTileEnd, height - shiftY)
            if (validOutEnd > validOutStart) {
                val sourceStartY = validOutStart + shiftY
                val rows = validOutEnd - validOutStart
                bitmap.getPixels(tile, 0, width, 0, sourceStartY, width, rows)

                for (outY in validOutStart until validOutEnd) {
                    val sourceRow = (outY - validOutStart) * width
                    val outputRow = outY * width
                    for (outX in validXStart until validXEnd) {
                        val sourceX = outX + shiftX
                        val current = tile[sourceRow + sourceX]
                        val index = outputRow + outX
                        val previous = average[index]

                        val pr = (previous shr 16) and 0xFF
                        val pg = (previous shr 8) and 0xFF
                        val pb = previous and 0xFF
                        val cr = (current shr 16) and 0xFF
                        val cg = (current shr 8) and 0xFF
                        val cb = current and 0xFF
                        val previousLuma = (77 * pr + 150 * pg + 29 * pb) shr 8
                        val currentLuma = (77 * cr + 150 * cg + 29 * cb) shr 8
                        val noiseAllowance = ((255 - previousLuma) * DARK_NOISE_ALLOWANCE) / 255
                        val threshold = config.deghostThreshold + noiseAllowance
                        compared++

                        if (abs(currentLuma - previousLuma) > threshold) {
                            // Pohybující se člověk, větev nebo auto: reference zůstane
                            // ostrá, místo aby vznikl průhledný duch.
                            moving++
                            continue
                        }

                        val count = counts[index].toInt() and 0xFF
                        val divisor = min(255, count + 1)
                        val nr = pr + (cr - pr) / divisor
                        val ng = pg + (cg - pg) / divisor
                        val nb = pb + (cb - pb) / divisor
                        average[index] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                        counts[index] = divisor.toByte()
                    }
                }
            }
            outTileStart = outTileEnd
        }
        return if (compared == 0L) 1f else moving.toFloat() / compared
    }

    private fun applyNightToneMap(pixels: IntArray) {
        val histogram = IntArray(256)
        for (p in pixels) {
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            histogram[(77 * r + 150 * g + 29 * b) shr 8]++
        }
        val total = pixels.size.coerceAtLeast(1)
        val black = percentile(histogram, total, 0.006f)
        val white = max(black + 24, percentile(histogram, total, 0.997f))
        val range = (white - black).toFloat()
        val gamma = when (config.mode) {
            NightCaptureMode.TRIPOD -> 0.91f
            NightCaptureMode.PORTRAIT -> 0.86f
            NightCaptureMode.HANDHELD -> 0.88f
        }

        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val luma = ((77 * r + 150 * g + 29 * b) shr 8).coerceAtLeast(1)
            val normalized = ((luma - black) / range).coerceIn(0f, 1f)
            // Jemný shoulder chrání lampy; gamma otevírá stíny.
            val lifted = normalized.toDouble().pow(gamma.toDouble()).toFloat()
            val shoulder = lifted / (lifted + 0.075f * (1f - lifted))
            val target = (shoulder * 255f).roundToInt().coerceIn(0, 255)
            var ratio = target.toFloat() / luma
            val brightest = max(r, max(g, b))
            if (brightest > 0 && ratio > 1f) ratio = min(ratio, 255f / brightest)
            val nr = (r * ratio).roundToInt().coerceIn(0, 255)
            val ng = (g * ratio).roundToInt().coerceIn(0, 255)
            val nb = (b * ratio).roundToInt().coerceIn(0, 255)
            pixels[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
    }

    private fun percentile(histogram: IntArray, total: Int, fraction: Float): Int {
        val target = (total * fraction).roundToInt().coerceIn(0, total - 1)
        var cumulative = 0
        for (i in histogram.indices) {
            cumulative += histogram[i]
            if (cumulative >= target) return i
        }
        return 255
    }

    private fun reject(
        reason: FrameRejectReason,
        alignment: FrameAlignment = FrameAlignment(),
        movingRatio: Float = 0f
    ): FrameAddResult {
        rejected++
        return result(
            accepted = false,
            rejectReason = reason,
            alignment = alignment,
            movingPixelRatio = movingRatio
        )
    }

    private fun result(
        accepted: Boolean,
        rejectReason: FrameRejectReason = FrameRejectReason.NONE,
        alignment: FrameAlignment = FrameAlignment(),
        movingPixelRatio: Float = 0f
    ) = FrameAddResult(
        accepted = accepted,
        complete = isComplete,
        rejectReason = rejectReason,
        alignment = alignment,
        movingPixelRatio = movingPixelRatio,
        acceptedFrames = collected,
        attemptedFrames = attempts
    )

    companion object {
        private const val THUMBNAIL_LONG_EDGE = 320
        private const val MIN_THUMBNAIL_EDGE = 48
        private const val MAX_THUMB_SHIFT = 18
        private const val MIN_ALIGNMENT_CONFIDENCE = 0.05f
        private const val SENSOR_FALLBACK_FACTOR = 0.50f
        private const val DARK_NOISE_ALLOWANCE = 12
        private const val MAX_WORKING_SET_BYTES = 96L * 1024L * 1024L

        fun recommendedFrames(meanLuma: Float): Int = when {
            meanLuma < 40f -> 10
            meanLuma < 70f -> 8
            meanLuma < 95f -> 6
            else -> 4
        }.coerceIn(4, 24)

        private fun fallbackPlan(targetFrames: Int) = NightCapturePlan(
            mode = NightCaptureMode.HANDHELD,
            targetFrames = targetFrames,
            maxAttempts = targetFrames + 4,
            minimumUsableFrames = min(3, targetFrames),
            exposureCapNanos = 125_000_000L,
            maxGyroRadiansPerFrame = 0.035f,
            maxPeakAngularVelocity = 1.35f,
            maxAccelerationImpulse = 0.18f,
            maxAlignmentShiftPx = 96,
            maxAlignmentError = 0.20f,
            deghostThreshold = 34,
            maxMovingPixelRatio = 0.65f,
            tileRows = 64,
            timeoutMs = 20_000L,
            explanation = "Výchozí výpočetní noční profil."
        )
    }
}
