package cz.hqsnet.aifoto.lens

import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import kotlin.math.abs

/**
 * Čistá rozhodovací logika bez Android API. Díky tomu jde otestovat bez telefonu.
 * Engine vybírá optický modul, nikoli pouhé číslo digitálního zoomu.
 */
object SmartLensEngine {

    fun recommend(
        advice: SceneAdvice,
        catalog: LensCatalogState,
        extensions: ExtensionAvailability = ExtensionAvailability()
    ): LensRecommendation {
        val profiles = catalog.profiles
        val main = catalog.mainLens()
            ?: profiles.minByOrNull { abs(it.equivalentZoom - 1f) }
            ?: return LensRecommendation(
                lensId = null,
                equivalentZoom = 1f,
                displayLabel = "1× hlavní",
                reason = "Zařízení neposkytlo spolehlivý seznam fyzických objektivů.",
                warning = "Použije se logická zadní kamera."
            )

        val ultra = profiles
            .filter { it.role == LensRole.ULTRA_WIDE }
            .minByOrNull { abs(it.equivalentZoom - 0.6f) }
        val portraitTele = profiles
            .filter { it.role == LensRole.TELEPHOTO }
            .minByOrNull { abs(it.equivalentZoom - 3f) }
        val superTele = profiles
            .filter { it.role == LensRole.SUPER_TELEPHOTO }
            .minByOrNull { abs(it.equivalentZoom - 10f) }

        val light = advice.metrics.meanLuma
        val motion = advice.metrics.motion
        val bright = light >= 112f
        val veryBright = light >= 145f
        val stable = motion <= 0.075f
        val lowLight = light < 88f
        val severeLowLight = light < 64f
        val labelText = advice.labels.joinToString(" ").lowercase()

        fun result(
            lens: LensProfile,
            reason: String,
            warning: String? = null,
            extensionMode: OemExtensionMode = OemExtensionMode.NONE
        ) = LensRecommendation(
            lensId = lens.id,
            equivalentZoom = lens.equivalentZoom,
            displayLabel = lens.displayName,
            reason = reason,
            warning = warning,
            extensionMode = extensionMode
        )

        // Ve tmě vyhrává světelnější hlavní modul. Teleobjektivy na telefonech
        // mají menší senzory a slabší světelnost; pouhé "3×" by často znamenalo
        // více šumu nebo tajný návrat firmwaru na digitální výřez z hlavního modulu.
        if (advice.scene == SceneKind.NIGHT || severeLowLight) {
            val extension = if (extensions.night) OemExtensionMode.NIGHT else OemExtensionMode.NONE
            return result(
                main,
                reason = "Hlavní snímač má v noci největší světelnou rezervu.",
                warning = if (portraitTele != null || superTele != null) {
                    "Teleobjektiv je odmítnut: v tomto světle by zvýšil šum nebo přešel na digitální výřez."
                } else null,
                extensionMode = extension
            )
        }

        if (advice.scene == SceneKind.BACKLIGHT) {
            return result(
                main,
                reason = "Hlavní snímač nabízí nejjistější dynamický rozsah v protisvětle.",
                extensionMode = if (extensions.hdr) OemExtensionMode.HDR else OemExtensionMode.NONE
            )
        }

        if (advice.scene == SceneKind.DOCUMENT || advice.scene == SceneKind.MACRO) {
            return result(
                main,
                reason = if (advice.scene == SceneKind.DOCUMENT) {
                    "Hlavní objektiv omezuje deformaci textu a drží nejlepší detail."
                } else {
                    "Hlavní objektiv je nejbezpečnější pro detail a přesné ostření."
                },
                warning = ultra?.let { "Ultraširoký modul se nepoužije, protože deformuje okraje." }
            )
        }

        if (advice.scene == SceneKind.FOOD) {
            return result(
                main,
                reason = "Hlavní modul drží věrnější perspektivu a lepší kresbu ve stínech.",
                warning = if (lowLight) "Přibližte se fyzicky; digitální zoom by jen ztratil detail." else null
            )
        }

        if (advice.scene == SceneKind.LANDSCAPE) {
            if (ultra != null && bright && stable && advice.metrics.highlightRatio < 0.075f) {
                return result(
                    ultra,
                    reason = "Scéna je dost světlá a stabilní pro skutečný ultraširoký modul.",
                    warning = "Kontrolujte rohy obrazu; široký objektiv může protáhnout objekty u krajů."
                )
            }
            return result(
                main,
                reason = "Hlavní objektiv lépe ochrání oblohu a jemné detaily.",
                warning = ultra?.let {
                    if (!bright) "Ultraširoký modul je odmítnut kvůli slabému světlu."
                    else "Ultraširoký modul je odmítnut kvůli pohybu nebo vysokým přepalům."
                }
            )
        }

        if (advice.scene == SceneKind.ARCHITECTURE) {
            if (ultra != null && veryBright && stable && advice.metrics.highlightRatio < 0.045f) {
                return result(
                    ultra,
                    reason = "Dostatek světla dovoluje širší záběr bez zbytečného růstu šumu.",
                    warning = "Držte telefon svisle; ultraširoký objektiv zvýrazní sbíhání linií."
                )
            }
            return result(
                main,
                reason = "Hlavní objektiv omezuje perspektivní deformaci staveb.",
                warning = ultra?.let { "Pro širší záběr raději ustupte, pokud je to možné." }
            )
        }

        // Supertele je automaticky zvolen jen pro velmi světlou, téměř statickou
        // scénu a jasný vzdálený motiv. Kontrola musí proběhnout před obecnou
        // větví PET, protože pták bývá klasifikovaný právě jako zvíře.
        val distantSubject = listOf("bird", "airplane", "aircraft", "moon").any(labelText::contains)
        if (superTele != null && distantSubject && veryBright && stable) {
            return result(
                superTele,
                reason = "Rozpoznaný vzdálený motiv a silné světlo dovolují skutečný superteleobjektiv.",
                warning = "Podepřete telefon; při 10× je vidět i malé chvění."
            )
        }

        if (advice.scene == SceneKind.PORTRAIT || advice.scene == SceneKind.PET) {
            if (portraitTele != null && bright && motion < 0.14f) {
                return result(
                    portraitTele,
                    reason = "Skutečný teleobjektiv zklidní perspektivu a oddělí objekt od pozadí.",
                    warning = if (advice.scene == SceneKind.PET) "U rychlého pohybu přejděte zpět na 1×." else null
                )
            }
            return result(
                main,
                reason = "Světlo nebo pohyb nejsou dost bezpečné pro teleobjektiv.",
                warning = portraitTele?.let { "Místo digitálního 3× se přibližte fyzicky nebo přidejte světlo." }
            )
        }

        if (advice.scene == SceneKind.ACTION) {
            if (portraitTele != null && veryBright && motion < 0.24f) {
                return result(
                    portraitTele,
                    reason = "Ve velmi dobrém světle zvládne optický teleobjektiv rychlý čas.",
                    warning = "Jakmile světlo zeslábne, 1× hlavní bude ostřejší."
                )
            }
            return result(
                main,
                reason = "Hlavní modul má největší rezervu pro rychlý čas a průběžné ostření.",
                warning = portraitTele?.let { "Teleobjektiv je odmítnut, aby se pohyb nerozmazal." }
            )
        }

        return result(
            main,
            reason = "Hlavní 1× modul nabízí nejspolehlivější kvalitu pro tuto scénu.",
            extensionMode = if (extensions.auto) OemExtensionMode.AUTO else OemExtensionMode.NONE
        )
    }
}

/**
 * Zabraňuje přeskakování doporučení mezi moduly při každém kolísnutí světla.
 * Nový objektiv musí vyhrát několik analýz za sebou.
 */
class LensRecommendationStabilizer(
    private val requiredSamples: Int = 3
) {
    private var candidateId: String? = null
    private var candidateCount: Int = 0
    private var stable: LensRecommendation? = null

    fun update(input: LensRecommendation): LensRecommendation {
        if (input.lensId == candidateId && input.extensionMode == stableCandidateExtension) {
            candidateCount += 1
        } else {
            candidateId = input.lensId
            stableCandidateExtension = input.extensionMode
            candidateCount = 1
        }

        if (stable == null || candidateCount >= requiredSamples) {
            stable = input.copy(stable = candidateCount >= requiredSamples)
        }

        val current = stable ?: input
        return current.copy(
            stable = candidateCount >= requiredSamples &&
                current.lensId == input.lensId &&
                current.extensionMode == input.extensionMode,
            confirmingSamples = candidateCount.coerceAtMost(requiredSamples)
        )
    }

    fun reset() {
        candidateId = null
        candidateCount = 0
        stableCandidateExtension = OemExtensionMode.NONE
        stable = null
    }

    private var stableCandidateExtension: OemExtensionMode = OemExtensionMode.NONE
}
