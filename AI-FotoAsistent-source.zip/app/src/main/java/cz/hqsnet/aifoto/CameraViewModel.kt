package cz.hqsnet.aifoto

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import cz.hqsnet.aifoto.capture.CaptureTelemetry
import cz.hqsnet.aifoto.capture.ExposureControlState
import cz.hqsnet.aifoto.capture.ExposureLock
import cz.hqsnet.aifoto.capture.FrameStacker
import cz.hqsnet.aifoto.capture.NightCaptureMode
import cz.hqsnet.aifoto.capture.NightCapturePlan
import cz.hqsnet.aifoto.capture.NightModePreference
import cz.hqsnet.aifoto.capture.NightMotionTracker
import cz.hqsnet.aifoto.capture.NightPlanner
import cz.hqsnet.aifoto.capture.NightStackStats
import cz.hqsnet.aifoto.capture.ManualExposureRequest
import cz.hqsnet.aifoto.capture.PostProcess
import cz.hqsnet.aifoto.coach.CoachCategory
import cz.hqsnet.aifoto.coach.CoachCueStabilizer
import cz.hqsnet.aifoto.coach.CoachExposure
import cz.hqsnet.aifoto.coach.CoachMode
import cz.hqsnet.aifoto.coach.CoachSeverity
import cz.hqsnet.aifoto.coach.CoachState
import cz.hqsnet.aifoto.coach.DevicePose
import cz.hqsnet.aifoto.coach.PhotoCoachEngine
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import cz.hqsnet.aifoto.lens.ExtensionAvailability
import cz.hqsnet.aifoto.lens.LensBindingState
import cz.hqsnet.aifoto.lens.LensCatalogState
import cz.hqsnet.aifoto.lens.LensProfile
import cz.hqsnet.aifoto.lens.LensRecommendation
import cz.hqsnet.aifoto.lens.LensRecommendationStabilizer
import cz.hqsnet.aifoto.lens.LensTruth
import cz.hqsnet.aifoto.lens.OemExtensionMode
import cz.hqsnet.aifoto.lens.SmartLensEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.roundToInt

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val _advice = MutableStateFlow(SceneAdvice.Initial)
    val advice: StateFlow<SceneAdvice> = _advice.asStateFlow()

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<CameraEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<CameraEvent> = _events.asSharedFlow()

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    /** Podporuje právě navázaná CameraX session sekvenční memory capture? */
    private var currentStackingSupported: Boolean = false
    /** Umí zařízení ukládat RAW? Jestli se použije, rozhoduje uživatel. */
    private var rawSupported: Boolean = false

    /** Katalog fyzických objektivů a stabilizace AI doporučení. */
    private var lensCatalog = LensCatalogState()
    private val lensRecommendationStabilizer = LensRecommendationStabilizer()
    private val coachCueStabilizer = CoachCueStabilizer()
    private var lastPoseUpdateNanos = 0L

    /** Poslední skutečné hodnoty z Camera2 CaptureResult. */
    @Volatile private var latestTelemetry = CaptureTelemetry()
    private val telemetryHistory = ArrayDeque<CaptureTelemetry>()
    private val telemetryLock = Any()
    private var lastTelemetryUiUpdateNanos = 0L

    /** Požadavek, který čeká na potvrzení skutečným CaptureResult. */
    @Volatile private var pendingManualRequest: ManualExposureRequest? = null
    @Volatile private var activeManualRequest: ManualExposureRequest? = null
    @Volatile private var manualRequestVerified = false
    @Volatile private var manualMatchCount = 0
    private var manualRequestSubmitted = false

    // Výpočetní noční režim: gyroskop + registrace + deghosting.
    @Volatile private var activeStacker: FrameStacker? = null
    private var activeNightPlan: NightCapturePlan? = null
    private val nightMotionTracker = NightMotionTracker(application)
    private var stackTimeoutJob: Job? = null
    private var nightPreparationJob: Job? = null
    private var countdownJob: Job? = null
    /** Drží se zámek expozice? Musí se uvolnit na každé cestě ven. */
    private var exposureLocked = false
    /** Běží ruční expozice? Musí se vrátit na automatiku na každé cestě ven. */
    private var manualExposureActive = false
    /** Čas jednoho snímku při posledním nočním snímání - pro odhad délky. */
    private var lastExposureNanos = 0L
    /** Byla pro noční režim nastavena expoziční korekce? Musí se vrátit na 0. */
    private var nightEvApplied = false
    /** EV zvolené uživatelem; noční režim ho dočasně přebije a pak vrátí. */
    private var userExposureIndex = 0
    /** Hodnota EV zvolená uživatelem/AI; znovu se aplikuje po přestavbě session. */
    private var userExposureEv = 0f
    // Diagnostika posledního složeného snímku (zachycená před uvolněním expozice).
    private var lastStackExposureNanos = 0L
    private var lastStackIso = 0
    private var lastStackManual = false
    private var lastStackVerified = false
    private var lastStackEv = false
    private var stackExposureTotal = 0L
    private var stackIsoTotal = 0L
    private var stackTelemetrySamples = 0
    private var stackManualSamples = 0
    private var stackVerifiedSamples = 0


    fun attachCamera(
        camera: Camera,
        imageCapture: ImageCapture,
        rawSupported: Boolean = false,
        stackingSupported: Boolean = true,
        boundLens: LensProfile? = null,
        extensionMode: OemExtensionMode = OemExtensionMode.NONE,
        lensFallback: Boolean = false
    ) {
        this.camera = camera
        this.imageCapture = imageCapture
        this.currentStackingSupported = stackingSupported
        this.rawSupported = rawSupported
        val zoomState = camera.cameraInfo.zoomState.value
        val hasFlash = camera.cameraInfo.hasFlashUnit()
        val manualSupported = ExposureLock.supportsManualExposure(camera)
        val limits = ExposureLock.readLimits(camera)
        val capabilities = CameraCapabilities(
            cameraId = ExposureLock.cameraId(camera),
            hardwareLevel = hardwareLevelLabel(ExposureLock.hardwareLevel(camera)),
            manualExposureSupported = manualSupported,
            minExposureNanos = limits.minExposureNanos,
            maxExposureNanos = limits.maxExposureNanos,
            minIso = limits.minIso,
            maxIso = limits.maxIso,
            rawSupported = rawSupported
        )
        val baseZoom = boundLens?.equivalentZoom ?: 1f
        val bindingState = when {
            lensFallback -> LensBindingState.DIGITAL_FALLBACK
            boundLens != null -> LensBindingState.BOUND_UNVERIFIED
            else -> LensBindingState.LOGICAL_AUTO
        }
        _uiState.update {
            it.copy(
                minZoom = zoomState?.minZoomRatio ?: 1f,
                maxZoom = zoomState?.maxZoomRatio ?: 10f,
                selectedZoom = baseZoom,
                cameraReady = true,
                torchAvailable = hasFlash,
                torchOn = it.torchOn && hasFlash,
                rawSupported = rawSupported,
                rawEnabled = it.rawEnabled && rawSupported,
                stackingAvailable = stackingSupported &&
                    extensionMode == OemExtensionMode.NONE &&
                    !(it.rawEnabled && rawSupported),
                capabilities = capabilities,
                boundLensId = boundLens?.id,
                lensFallbackActive = lensFallback,
                activeExtensionMode = extensionMode,
                lensTruth = LensTruth(
                    requestedLensId = it.requestedLensId,
                    activeLensId = boundLens?.id,
                    activePhysicalCameraId = null,
                    activeLabel = boundLens?.displayName ?: "Logická kamera",
                    opticalBaseZoom = baseZoom,
                    effectiveZoom = baseZoom,
                    bindingState = bindingState,
                    verified = false
                ),
                exposureControlState = if (manualSupported) {
                    ExposureControlState.AUTO
                } else {
                    ExposureControlState.UNSUPPORTED
                }
            )
        }
        // U fyzicky připnutého modulu začínáme bez digitálního výřezu.
        if (boundLens != null && !lensFallback) {
            val min = zoomState?.minZoomRatio ?: 1f
            camera.cameraControl.setZoomRatio(1f.coerceAtLeast(min))
        }
        applyFlashMode(_uiState.value.flashMode)
        applyExposureCompensation(userExposureEv)
        if (_uiState.value.torchOn && hasFlash) {
            camera.cameraControl.enableTorch(true)
        }
    }

    fun detachCamera() {
        cancelCountdown()
        nightPreparationJob?.cancel()
        nightPreparationJob = null
        releaseExposureLock()
        camera = null
        imageCapture = null
        currentStackingSupported = false
        activeStacker = null
        activeNightPlan = null
        nightMotionTracker.stop()
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        pendingManualRequest = null
        activeManualRequest = null
        manualRequestVerified = false
        manualMatchCount = 0
        coachCueStabilizer.reset()
        synchronized(telemetryLock) { telemetryHistory.clear() }
        _uiState.update {
            it.copy(
                cameraReady = false,
                stacking = false,
                stackProgress = 0f,
                nightActiveMode = null,
                nightTargetFrames = 0,
                nightAcceptedFrames = 0,
                nightRejectedFrames = 0,
                nightStatus = "Computational Night připraven.",
                captureTelemetry = CaptureTelemetry(),
                boundLensId = null,
                lensTruth = LensTruth(
                    requestedLensId = it.requestedLensId,
                    bindingState = if (it.requestedLensId != null) {
                        LensBindingState.REQUESTED
                    } else {
                        LensBindingState.LOGICAL_AUTO
                    }
                ),
                exposureControlState = ExposureControlState.AUTO
            )
        }
    }

    /** Kamera se nepodařila spustit - dej o tom vědět místo tichého selhání. */
    fun onCameraError(reason: String?) {
        detachCamera()
        _events.tryEmit(
            CameraEvent.Message("Fotoaparát se nepodařilo spustit: ${reason ?: "neznámá chyba"}")
        )
    }

    fun onLensCatalog(catalog: LensCatalogState) {
        if (lensCatalog == catalog) return
        lensCatalog = catalog
        lensRecommendationStabilizer.reset()
        val initialRecommendation = SmartLensEngine.recommend(
            _advice.value,
            catalog,
            _uiState.value.extensionAvailability
        )
        _uiState.update {
            it.copy(
                lensCatalog = catalog,
                lensRecommendation = initialRecommendation
            )
        }
    }

    fun onExtensionAvailability(availability: ExtensionAvailability) {
        _uiState.update { state ->
            val requested = state.requestedExtensionMode
            state.copy(
                extensionAvailability = availability,
                requestedExtensionMode = if (availability.supports(requested)) {
                    requested
                } else {
                    OemExtensionMode.NONE
                }
            )
        }
    }

    fun selectLens(lensId: String) {
        if (_uiState.value.isSaving) {
            _events.tryEmit(CameraEvent.Message("Objektiv nelze změnit během ukládání snímku."))
            return
        }
        val profile = lensCatalog.profile(lensId) ?: return
        if (_uiState.value.rawEnabled && !profile.rawSupported) {
            _events.tryEmit(CameraEvent.Message("${profile.displayName} nepodporuje RAW; ukládání DNG bylo vypnuto."))
        }
        cancelCountdown()
        cancelNightStack()
        _uiState.update {
            it.copy(
                requestedLensId = profile.id,
                requestedExtensionMode = OemExtensionMode.NONE,
                rawEnabled = it.rawEnabled && profile.rawSupported,
                selectedZoom = profile.equivalentZoom,
                lensFallbackActive = false,
                lensTruth = it.lensTruth.copy(
                    requestedLensId = profile.id,
                    activeLabel = "Čeká se na ${profile.displayName}",
                    opticalBaseZoom = profile.equivalentZoom,
                    effectiveZoom = profile.equivalentZoom,
                    bindingState = LensBindingState.REQUESTED,
                    verified = false
                )
            )
        }
    }

    fun useLogicalCamera() {
        if (_uiState.value.isSaving) return
        cancelCountdown()
        cancelNightStack()
        _uiState.update {
            it.copy(
                requestedLensId = null,
                requestedExtensionMode = OemExtensionMode.NONE,
                selectedZoom = 1f,
                lensFallbackActive = false,
                lensTruth = LensTruth(bindingState = LensBindingState.LOGICAL_AUTO)
            )
        }
    }

    fun cycleOemExtension() {
        if (_uiState.value.isSaving || _uiState.value.stacking) {
            _events.tryEmit(CameraEvent.Message("OEM režim nelze změnit během snímání."))
            return
        }
        cancelCountdown()
        val availability = _uiState.value.extensionAvailability
        if (!availability.any) {
            _events.tryEmit(CameraEvent.Message("Výrobce na tomto zařízení nezpřístupnil CameraX Extensions."))
            return
        }
        val availableModes = buildList {
            add(OemExtensionMode.NONE)
            if (availability.auto) add(OemExtensionMode.AUTO)
            if (availability.night) add(OemExtensionMode.NIGHT)
            if (availability.hdr) add(OemExtensionMode.HDR)
        }
        val current = _uiState.value.requestedExtensionMode
        val index = availableModes.indexOf(current).takeIf { it >= 0 } ?: 0
        val next = availableModes[(index + 1) % availableModes.size]
        _uiState.update {
            it.copy(
                requestedExtensionMode = next,
                requestedLensId = if (next == OemExtensionMode.NONE) it.requestedLensId else null,
                rawEnabled = if (next == OemExtensionMode.NONE) it.rawEnabled else false
            )
        }
        _events.tryEmit(CameraEvent.Message("Režim výrobce: ${next.displayName}."))
    }

    fun onLensBindingFallback(profile: LensProfile?, reason: String?) {
        _uiState.update {
            it.copy(
                lensFallbackActive = true,
                lensTruth = it.lensTruth.copy(
                    requestedLensId = profile?.id,
                    activeLabel = "Logická kamera · digitální náhrada",
                    bindingState = LensBindingState.DIGITAL_FALLBACK,
                    verified = false
                )
            )
        }
        _events.tryEmit(
            CameraEvent.Message(
                "Fyzický objektiv ${profile?.displayName ?: ""} nelze otevřít. " +
                    "Použita logická kamera${reason?.let { ": $it" } ?: "."}"
            )
        )
    }

    fun onExtensionFallback(mode: OemExtensionMode, reason: String?) {
        _uiState.update {
            it.copy(
                requestedExtensionMode = OemExtensionMode.NONE,
                activeExtensionMode = OemExtensionMode.NONE
            )
        }
        _events.tryEmit(
            CameraEvent.Message(
                "${mode.displayName} se nepodařilo spustit${reason?.let { ": $it" } ?: "."}"
            )
        )
    }

    /** Přijme skutečné hodnoty z Camera2 session callbacku. */
    fun onCaptureTelemetry(telemetry: CaptureTelemetry) {
        latestTelemetry = telemetry
        synchronized(telemetryLock) {
            telemetryHistory.addLast(telemetry)
            while (telemetryHistory.size > TELEMETRY_HISTORY_SIZE) {
                telemetryHistory.removeFirst()
            }
        }

        val request = pendingManualRequest
        val matchesNow = request != null && telemetry.matches(request)
        if (request != null && telemetry.receivedAtNanos >= request.submittedAtNanos) {
            manualMatchCount = if (matchesNow) manualMatchCount + 1 else 0
        }
        val verifiedNow = manualMatchCount >= REQUIRED_MANUAL_MATCHES
        if (verifiedNow) manualRequestVerified = true

        // CaptureResult chodí typicky 30-60x za sekundu. Pro ověření ho čteme
        // každý, ale Compose aktualizujeme jen několikrát za sekundu.
        val now = System.nanoTime()
        val stateChanged = verifiedNow &&
            _uiState.value.exposureControlState != ExposureControlState.VERIFIED
        if (stateChanged || now - lastTelemetryUiUpdateNanos >= TELEMETRY_UI_INTERVAL_NS) {
            lastTelemetryUiUpdateNanos = now
            _uiState.update { state ->
                val truth = resolveLensTruth(telemetry, state)
                state.copy(
                    captureTelemetry = telemetry,
                    selectedZoom = truth.effectiveZoom,
                    lensTruth = truth,
                    exposureControlState = if (stateChanged) {
                        ExposureControlState.VERIFIED
                    } else {
                        state.exposureControlState
                    }
                )
            }
        }
    }

    /**
     * Porovná požadovaný modul s tím, co opravdu hlásí CaptureResult. CameraX
     * může požadavek splnit fyzickým modulem, nebo ho OEM nahradit logickou
     * kamerou a digitálním výřezem. UI proto nikdy nevydává požadavek za fakt.
     */
    private fun resolveLensTruth(
        telemetry: CaptureTelemetry,
        state: CameraUiState
    ): LensTruth {
        val requested = lensCatalog.profile(state.requestedLensId)
        val bound = lensCatalog.profile(state.boundLensId)
        val active = lensCatalog.profiles.firstOrNull { profile ->
            telemetry.activePhysicalCameraId != null &&
                profile.physicalCameraId == telemetry.activePhysicalCameraId
        } ?: telemetry.focalLengthMm?.let { focal ->
            lensCatalog.profiles
                .minByOrNull { profile -> abs(profile.focalLengthMm - focal) }
                ?.takeIf { profile ->
                    abs(profile.focalLengthMm - focal) /
                        profile.focalLengthMm.coerceAtLeast(0.1f) <= FOCAL_MATCH_TOLERANCE
                }
        } ?: bound.takeUnless { state.lensFallbackActive }

        val cropWidth = telemetry.cropRegionWidth
        val cropHeight = telemetry.cropRegionHeight
        val crop = if (
            active != null &&
            active.activeArrayWidth > 0 && active.activeArrayHeight > 0 &&
            cropWidth != null && cropHeight != null &&
            cropWidth > 0 && cropHeight > 0
        ) {
            maxOf(
                active.activeArrayWidth.toFloat() / cropWidth,
                active.activeArrayHeight.toFloat() / cropHeight
            ).coerceIn(1f, active.maxDigitalZoom.coerceAtLeast(1f))
        } else if (state.lensFallbackActive) {
            state.selectedZoom.coerceAtLeast(1f)
        } else {
            1f
        }

        val physicalConfirmed = requested != null && when {
            requested.physicalCameraId != null ->
                telemetry.activePhysicalCameraId == requested.physicalCameraId
            telemetry.focalLengthMm != null ->
                abs(requested.focalLengthMm - telemetry.focalLengthMm) /
                    requested.focalLengthMm.coerceAtLeast(0.1f) <= FOCAL_MATCH_TOLERANCE
            else -> false
        }
        val standaloneBound = requested != null &&
            requested.physicalCameraId == null &&
            state.boundLensId == requested.id &&
            !state.lensFallbackActive
        val verified = physicalConfirmed || standaloneBound
        val baseZoom = if (state.lensFallbackActive) {
            active?.equivalentZoom ?: 1f
        } else {
            active?.equivalentZoom ?: requested?.equivalentZoom ?: 1f
        }
        val effectiveZoom = (baseZoom * crop).coerceAtLeast(0.1f)
        val bindingState = when {
            state.lensFallbackActive -> LensBindingState.DIGITAL_FALLBACK
            requested == null -> LensBindingState.LOGICAL_AUTO
            verified -> LensBindingState.PHYSICAL_CONFIRMED
            state.boundLensId == requested.id -> LensBindingState.BOUND_UNVERIFIED
            else -> LensBindingState.REQUESTED
        }
        val baseLabel = active?.displayName ?: when {
            state.activeExtensionMode != OemExtensionMode.NONE -> state.activeExtensionMode.displayName
            requested != null -> requested.displayName
            else -> "Logická kamera"
        }
        val label = if (crop > 1.08f) {
            "$baseLabel · digitální ${formatZoomFactor(crop)}"
        } else {
            baseLabel
        }
        return LensTruth(
            requestedLensId = requested?.id,
            activeLensId = active?.id,
            activePhysicalCameraId = telemetry.activePhysicalCameraId,
            activeLabel = label,
            opticalBaseZoom = baseZoom,
            digitalCropFactor = crop,
            effectiveZoom = effectiveZoom,
            focalLengthMm = telemetry.focalLengthMm ?: active?.focalLengthMm,
            bindingState = bindingState,
            verified = verified
        )
    }

    fun toggleDiagnostics() {
        val current = _uiState.value
        if (current.coachState.mode != CoachMode.PRO) {
            coachCueStabilizer.reset()
            val cue = PhotoCoachEngine.evaluate(
                advice = _advice.value,
                pose = current.coachState.pose,
                telemetry = CoachExposure(latestTelemetry.exposureNanos, latestTelemetry.iso),
                mode = CoachMode.PRO
            )
            _uiState.update { state ->
                state.copy(
                    diagnosticsVisible = true,
                    coachState = state.coachState.copy(
                        mode = CoachMode.PRO,
                        cue = cue,
                        compositionScore = cue.score,
                        ready = cue.severity == CoachSeverity.READY,
                        cueRevision = state.coachState.cueRevision + 1L
                    )
                )
            }
        } else {
            _uiState.update { it.copy(diagnosticsVisible = !it.diagnosticsVisible) }
        }
    }

    fun onAdvice(advice: SceneAdvice) {
        val rawRecommendation = SmartLensEngine.recommend(
            advice,
            lensCatalog,
            _uiState.value.extensionAvailability
        )
        val stableRecommendation = lensRecommendationStabilizer.update(rawRecommendation)
        val enrichedAdvice = advice.copy(
            zoomRatio = stableRecommendation.equivalentZoom,
            lensLabel = stableRecommendation.displayLabel,
            secondaryTip = buildString {
                append(stableRecommendation.reason)
                stableRecommendation.warning?.let { append(" ").append(it) }
            }
        )
        _advice.value = enrichedAdvice
        val state = _uiState.value
        val cue = coachCueStabilizer.update(
            PhotoCoachEngine.evaluate(
                advice = enrichedAdvice,
                pose = state.coachState.pose,
                telemetry = CoachExposure(latestTelemetry.exposureNanos, latestTelemetry.iso),
                mode = state.coachState.mode
            )
        )
        _uiState.update { current ->
            val revision = if (current.coachState.cue.id != cue.id) {
                current.coachState.cueRevision + 1L
            } else {
                current.coachState.cueRevision
            }
            current.copy(
                lensRecommendation = stableRecommendation,
                coachState = current.coachState.copy(
                    cue = cue,
                    faceCount = enrichedAdvice.faces.size,
                    compositionScore = cue.score,
                    ready = cue.severity == CoachSeverity.READY,
                    cueRevision = revision
                )
            )
        }
        if (activeStacker != null && advice.metrics.motion > NIGHT_PREVIEW_WARNING_MOTION) {
            _uiState.update { current ->
                current.copy(nightStatus = "Telefon se výrazně hýbe – další snímek může být odmítnut.")
            }
        }
    }

    /**
     * Aktualizace z gravitačního senzoru je omezená na přibližně 8 Hz.
     * Senzor smí okamžitě měnit jen radu k rovině/perspektivě. Ostatní rady
     * se stabilizují výhradně novými obrazovými analýzami, aby jeden starý
     * snímek nebyl během 250 ms falešně potvrzen několika sensor tick-y.
     */
    fun onDevicePose(pose: DevicePose) {
        val now = System.nanoTime()
        if (now - lastPoseUpdateNanos < COACH_POSE_INTERVAL_NS) return
        lastPoseUpdateNanos = now
        val state = _uiState.value
        val evaluated = PhotoCoachEngine.evaluate(
            advice = _advice.value,
            pose = pose,
            telemetry = CoachExposure(latestTelemetry.exposureNanos, latestTelemetry.iso),
            mode = state.coachState.mode
        )
        val poseCategories = setOf(CoachCategory.LEVEL, CoachCategory.PERSPECTIVE)
        val cue = if (evaluated.category in poseCategories || state.coachState.cue.category in poseCategories) {
            evaluated
        } else {
            state.coachState.cue
        }
        _uiState.update { current ->
            current.copy(
                coachState = current.coachState.copy(
                    pose = pose,
                    cue = cue,
                    compositionScore = cue.score,
                    ready = cue.severity == CoachSeverity.READY,
                    cueRevision = if (current.coachState.cue.id != cue.id) {
                        current.coachState.cueRevision + 1L
                    } else {
                        current.coachState.cueRevision
                    }
                )
            )
        }
    }

    fun cycleCoachMode() {
        val next = _uiState.value.coachState.mode.next()
        coachCueStabilizer.reset()
        val cue = PhotoCoachEngine.evaluate(
            advice = _advice.value,
            pose = _uiState.value.coachState.pose,
            telemetry = CoachExposure(latestTelemetry.exposureNanos, latestTelemetry.iso),
            mode = next
        )
        _uiState.update { current ->
            current.copy(
                diagnosticsVisible = current.diagnosticsVisible && next == CoachMode.PRO,
                coachState = current.coachState.copy(
                    mode = next,
                    cue = cue,
                    compositionScore = cue.score,
                    ready = cue.severity == CoachSeverity.READY,
                    cueRevision = current.coachState.cueRevision + 1L
                )
            )
        }
        _events.tryEmit(CameraEvent.Message("Režim hledáčku: ${next.displayName}."))
    }

    fun setZoom(requestedZoom: Float) {
        val profile = lensCatalog.profiles.minByOrNull {
            abs(it.equivalentZoom - requestedZoom)
        }
        if (profile != null && abs(profile.equivalentZoom - requestedZoom) <= 0.45f) {
            selectLens(profile.id)
            return
        }
        val activeCamera = camera ?: return
        val state = activeCamera.cameraInfo.zoomState.value
        val min = state?.minZoomRatio ?: _uiState.value.minZoom
        val max = state?.maxZoomRatio ?: _uiState.value.maxZoom
        val zoom = requestedZoom.coerceIn(min, max)
        activeCamera.cameraControl.setZoomRatio(zoom)
        _uiState.update {
            it.copy(
                selectedZoom = zoom,
                requestedLensId = null,
                lensTruth = it.lensTruth.copy(
                    requestedLensId = null,
                    digitalCropFactor = zoom,
                    effectiveZoom = zoom,
                    bindingState = LensBindingState.LOGICAL_AUTO,
                    verified = false
                )
            )
        }
    }

    fun applyCurrentAdvice() {
        val sceneAdvice = _advice.value
        val recommendation = _uiState.value.lensRecommendation
        val requestedExtension = recommendation.extensionMode.takeIf {
            _uiState.value.extensionAvailability.supports(it)
        } ?: OemExtensionMode.NONE

        if (requestedExtension != OemExtensionMode.NONE) {
            _uiState.update {
                it.copy(
                    requestedExtensionMode = requestedExtension,
                    requestedLensId = null,
                    rawEnabled = false
                )
            }
        } else {
            recommendation.lensId?.let(::selectLens)
        }
        applyExposureCompensation(sceneAdvice.exposureCompensation)

        val flash = recommendedFlash(sceneAdvice.scene)
        _uiState.update { it.copy(flashMode = flash) }
        applyFlashMode(flash)

        _events.tryEmit(
            CameraEvent.Message(
                "Použito: ${recommendation.displayLabel}, EV " +
                    "${formatEv(sceneAdvice.exposureCompensation)}, ${flash.label}" +
                    if (requestedExtension != OemExtensionMode.NONE) {
                        ", ${requestedExtension.displayName}"
                    } else {
                        ""
                    }
            )
        )
    }

    /**
     * Blesk má smysl jen u blízkých objektů. U vzdálených scén nedosvítí,
     * ale rozhodí měření expozice - typicky noční panorama vyfocené s ISO 2000+.
     *
     * Dříve spadaly do OFF všechny scény kromě PORTRAIT a GENERAL, takže se
     * u protisvětla nenavrhlo přisvícení, i když je to přesně ten případ,
     * kdy blesk pomůže (vyrovnání tmavého popředí).
     */
    private fun recommendedFlash(scene: SceneKind): FlashMode = when (scene) {
        // Blízké objekty - blesk dosvítí a pomůže.
        SceneKind.PORTRAIT, SceneKind.GENERAL, SceneKind.FOOD, SceneKind.MACRO, SceneKind.PET ->
            FlashMode.AUTO
        // Protisvětlo: popředí je tmavé, přisvícení je žádoucí.
        SceneKind.BACKLIGHT -> FlashMode.ON
        // Vzdálené nebo pohybové scény - blesk nedosvítí, jen rozhodí expozici.
        SceneKind.NIGHT, SceneKind.LANDSCAPE, SceneKind.ACTION,
        SceneKind.ARCHITECTURE, SceneKind.DOCUMENT -> FlashMode.OFF
    }

    private fun applyExposureCompensation(ev: Float) {
        userExposureEv = ev
        val activeCamera = camera ?: return
        val exposureState = activeCamera.cameraInfo.exposureState
        if (!exposureState.isExposureCompensationSupported) return

        val step = exposureState.exposureCompensationStep.toFloat()
        if (step <= 0f) return
        val range = exposureState.exposureCompensationRange
        val index = (ev / step).roundToInt().coerceIn(range.lower, range.upper)
        userExposureIndex = index
        activeCamera.cameraControl.setExposureCompensationIndex(index)
    }

    /**
     * Nastaví nejvyšší možnou expoziční korekci a vrátí ji, nebo 0 při neúspěchu.
     *
     * Tohle je pojistka pro noční režim. Ruční nastavení dlouhého času přes
     * Camera2 některé telefony (mj. S22 Ultra) na fotoaparátovém streamu
     * ignorují - automatika si čas přepíše zpět. Expoziční korekce jde ale
     * skrz automatiku, ne proti ní, takže ji fotoaparát respektuje: řekneme mu
     * "exponuj co nejvíc" a on prodlouží čas sám, v mezích, které dovolí.
     */
    private fun applyMaxExposureCompensation(): Int {
        val activeCamera = camera ?: return 0
        val exposureState = activeCamera.cameraInfo.exposureState
        if (!exposureState.isExposureCompensationSupported) return 0
        val range = exposureState.exposureCompensationRange
        activeCamera.cameraControl.setExposureCompensationIndex(range.upper)
        return range.upper
    }

    /**
     * Vrátí expoziční korekci na hodnotu, kterou zvolil uživatel. Noční režim
     * si ji dočasně přebíjí na maximum, ale po dokončení nesmí uživatelovo
     * nastavení zahodit.
     */
    private fun resetExposureCompensation() {
        camera?.cameraControl?.setExposureCompensationIndex(userExposureIndex)
    }

    fun focusAt(previewView: PreviewView, x: Float, y: Float) {
        val activeCamera = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(
            point,
            FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
        )
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        activeCamera.cameraControl.startFocusAndMetering(action)
        _uiState.update { it.copy(focusPoint = FocusPoint(x, y), focusPulse = it.focusPulse + 1) }
    }

    fun cycleFlash() {
        val next = when (_uiState.value.flashMode) {
            FlashMode.OFF -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.ON
            FlashMode.ON -> FlashMode.OFF
        }
        _uiState.update { it.copy(flashMode = next) }
        applyFlashMode(next)
    }

    /**
     * Svítilna jako trvalé přisvícení. Na rozdíl od blesku nerozhodí měření
     * expozice - má smysl pro blízké objekty v noci (do ~2 m).
     */
    fun toggleTorch() {
        val activeCamera = camera ?: return
        if (!activeCamera.cameraInfo.hasFlashUnit()) {
            _events.tryEmit(CameraEvent.Message("Toto zařízení nemá svítilnu."))
            return
        }
        val next = !_uiState.value.torchOn
        activeCamera.cameraControl.enableTorch(next)
        _uiState.update { it.copy(torchOn = next) }
    }

    private fun applyFlashMode(mode: FlashMode) {
        imageCapture?.flashMode = when (mode) {
            FlashMode.OFF -> ImageCapture.FLASH_MODE_OFF
            FlashMode.AUTO -> ImageCapture.FLASH_MODE_AUTO
            FlashMode.ON -> ImageCapture.FLASH_MODE_ON
        }
    }

    /**
     * Přepne samospoušť mezi vypnuto, dvěma a pěti sekundami.
     *
     * U nočního snímání je to víc než pohodlí: stisk tlačítka rozhýbe telefon
     * přesně v okamžiku, kdy začíná snímání, a protože se snímky nezarovnávají,
     * projeví se to rozmazáním. Pár sekund prodlevy nechá telefon uklidnit.
     */
    fun cycleSelfTimer() {
        val next = when (_uiState.value.selfTimerSeconds) {
            0 -> 2
            2 -> 5
            else -> 0
        }
        _uiState.update { it.copy(selfTimerSeconds = next) }
        _events.tryEmit(
            CameraEvent.Message(
                if (next == 0) "Samospoušť vypnuta." else "Samospoušť $next s."
            )
        )
    }

    /** Zruší běžící odpočet. */
    fun cancelCountdown() {
        countdownJob?.cancel()
        countdownJob = null
        _uiState.update { it.copy(countdownRemaining = 0) }
    }

    /**
     * Odpočítá nastavené sekundy a pak spustí akci. Když je samospoušť
     * vypnutá, provede akci rovnou.
     */
    private fun withSelfTimer(action: () -> Unit) {
        val seconds = _uiState.value.selfTimerSeconds
        if (seconds <= 0) {
            action()
            return
        }
        // Druhý stisk během odpočtu ho zruší, ať uživatel nemusí čekat.
        if (countdownJob != null) {
            cancelCountdown()
            return
        }
        countdownJob = viewModelScope.launch {
            for (remaining in seconds downTo 1) {
                _uiState.update { it.copy(countdownRemaining = remaining) }
                delay(1000)
            }
            // Mezi posledním čekáním a spuštěním není žádný bod, kde by se
            // korutina sama přerušila, takže zrušení přesně v tomhle okamžiku
            // by jinak fotku i tak pořídilo.
            ensureActive()
            _uiState.update { it.copy(countdownRemaining = 0) }
            countdownJob = null
            action()
        }
    }

    /**
     * Zapne nebo vypne ukládání RAW vedle běžné fotky.
     *
     * Není zapnuté ve výchozím stavu: když snímač musí dodat oba formáty
     * současně, zúží se dostupná rozlišení a snímek vyjde menší. RAW se
     * proto vyplatí u scén, kde se počítá s dodatečnými úpravami.
     */
    fun toggleRaw() {
        if (!rawSupported) {
            _events.tryEmit(CameraEvent.Message("Toto zařízení RAW nepodporuje."))
            return
        }
        if (_uiState.value.stacking) {
            _events.tryEmit(CameraEvent.Message("RAW nelze změnit během výpočetního nočního snímání."))
            return
        }
        val next = !_uiState.value.rawEnabled
        _uiState.update {
            it.copy(
                rawEnabled = next,
                stackingAvailable = currentStackingSupported &&
                    !next &&
                    it.activeExtensionMode == OemExtensionMode.NONE,
                requestedExtensionMode = if (next) OemExtensionMode.NONE else it.requestedExtensionMode
            )
        }
        _events.tryEmit(
            CameraEvent.Message(
                if (next) {
                    "RAW zapnuto - ukládá se i DNG, snímek bude mít nižší rozlišení."
                } else {
                    "RAW vypnuto - snímky v plném rozlišení."
                }
            )
        )
    }

    fun takePhoto(context: Context) {
        val capturedCue = _uiState.value.coachState.cue
        _uiState.update { current ->
            current.copy(coachState = current.coachState.copy(lastCapturedCue = capturedCue))
        }
        if (imageCapture == null) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (_uiState.value.isSaving || _uiState.value.stacking) return
        withSelfTimer { capturePhotoNow(context) }
    }

    private fun capturePhotoNow(context: Context) {
        val capture = imageCapture ?: return

        _uiState.update { it.copy(isSaving = true) }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
            .format(System.currentTimeMillis())
        val resolver = context.contentResolver
        val collection: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

        fun values(displayName: String, mime: String) = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
            }
        }

        val jpegOptions = ImageCapture.OutputFileOptions.Builder(
            resolver,
            collection,
            values("AI_Foto_$timestamp.jpg", "image/jpeg")
        ).build()

        if (rawSupported && _uiState.value.rawEnabled) {
            val rawOptions = ImageCapture.OutputFileOptions.Builder(
                resolver,
                collection,
                values("AI_Foto_$timestamp.dng", "image/x-adobe-dng")
            ).build()

            var callbacks = 0
            var jpegUri: Uri? = null
            var rawUri: Uri? = null
            var fallbackUri: Uri? = null
            var failure: String? = null
            var finalized = false
            var completionTimeout: Job? = null

            fun finishDualCapture() {
                if (finalized) return
                finalized = true
                completionTimeout?.cancel()
                _uiState.update { it.copy(isSaving = false) }
                val error = failure
                val preferredUri = jpegUri ?: fallbackUri ?: rawUri
                _events.tryEmit(
                    when {
                        jpegUri != null && rawUri != null -> CameraEvent.PhotoSaved(
                            jpegUri,
                            "Uloženo JPEG + RAW (DNG) do alba AI FotoAsistent."
                        )
                        preferredUri != null -> CameraEvent.PhotoSaved(
                            preferredUri,
                            "Uložen jen jeden formát${error?.let { ": $it" } ?: "."}"
                        )
                        else -> CameraEvent.Message(
                            "Fotografii se nepodařilo uložit: ${error ?: "chybí výstupní soubor"}"
                        )
                    }
                )
            }

            fun scheduleFinish(delayMs: Long) {
                completionTimeout?.cancel()
                completionTimeout = viewModelScope.launch {
                    delay(delayMs)
                    finishDualCapture()
                }
            }

            capture.takePicture(
                rawOptions,
                jpegOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        val uri = outputFileResults.savedUri
                        fallbackUri = fallbackUri ?: uri
                        when (uri?.let { detectSavedFormat(context, it) }) {
                            SavedFormat.JPEG -> jpegUri = uri
                            SavedFormat.RAW -> rawUri = uri
                            null -> Unit
                        }
                        callbacks += 1
                        if (callbacks >= 2) finishDualCapture() else scheduleFinish(DUAL_CAPTURE_GRACE_MS)
                    }

                    override fun onError(exception: ImageCaptureException) {
                        failure = exception.message ?: "neznámá chyba"
                        callbacks += 1
                        // Některé implementace po společné chybě zavolají
                        // onError jen jednou; krátká lhůta zabrání věčnému stavu.
                        if (callbacks >= 2) finishDualCapture() else scheduleFinish(DUAL_CAPTURE_ERROR_GRACE_MS)
                    }
                }
            )
        } else {
            capture.takePicture(
                jpegOptions,
                ContextCompat.getMainExecutor(context),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                        val savedUri = outputFileResults.savedUri
                        val metrics = _advice.value.metrics
                        if (savedUri != null &&
                            PostProcess.isWorthEnhancing(metrics.meanLuma, metrics.shadowRatio)
                        ) {
                            enhanceSavedPhoto(context, savedUri, timestamp)
                        } else {
                            _uiState.update { it.copy(isSaving = false) }
                            _events.tryEmit(
                                CameraEvent.PhotoSaved(
                                    savedUri,
                                    "Fotografie byla uložena do alba AI FotoAsistent."
                                )
                            )
                        }
                    }

                    override fun onError(exception: ImageCaptureException) {
                        _uiState.update { it.copy(isSaving = false) }
                        _events.tryEmit(
                            CameraEvent.Message(
                                "Fotografii se nepodařilo uložit: ${exception.message}"
                            )
                        )
                    }
                }
            )
        }
    }

    // ---------------------------------------------------------------------
    // Computational Night v0.8, integrovaný s AI Photo Coach v0.9
    // ---------------------------------------------------------------------

    fun cycleNightMode() {
        if (_uiState.value.stacking || _uiState.value.isSaving) return
        val values = NightModePreference.entries
        val current = _uiState.value.nightModePreference
        val next = values[(values.indexOf(current) + 1) % values.size]
        _uiState.update {
            it.copy(
                nightModePreference = next,
                nightStatus = "Noční profil: ${next.displayName}."
            )
        }
        _events.tryEmit(CameraEvent.Message("Noční režim: ${next.displayName}."))
    }

    /** Spustí výpočetní sérii; vadné snímky se odmítnou místo zrušení celé série. */
    fun startNightStack() {
        if (activeStacker != null || _uiState.value.isSaving) return
        if (!_uiState.value.cameraReady) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }
        if (_uiState.value.rawEnabled) {
            _events.tryEmit(
                CameraEvent.Message("Computational Night používá samostatnou JPEG sérii. Nejprve vypněte RAW.")
            )
            return
        }
        if (!_uiState.value.stackingAvailable) {
            _events.tryEmit(CameraEvent.Message("Výpočetní noční režim není v této session dostupný."))
            return
        }
        withSelfTimer { startNightStackNow() }
    }

    private fun startNightStackNow() {
        if (activeStacker != null) return
        val activeCamera = camera
        val activeCapture = imageCapture
        if (activeCamera == null || activeCapture == null) {
            _events.tryEmit(CameraEvent.Message("Fotoaparát ještě není připraven."))
            return
        }

        val advice = _advice.value
        val plan = NightPlanner.createPlan(
            preference = _uiState.value.nightModePreference,
            scene = advice.scene,
            metrics = advice.metrics
        )
        val stacker = FrameStacker(targetFrames = plan.targetFrames, config = plan)
        activeNightPlan = plan
        activeStacker = stacker
        resetStackTelemetry()
        nightMotionTracker.start()
        _uiState.update {
            it.copy(
                stacking = true,
                stackProgress = 0f,
                nightActiveMode = plan.mode,
                nightTargetFrames = plan.targetFrames,
                nightAcceptedFrames = 0,
                nightRejectedFrames = 0,
                nightStatus = "Připravuji ${plan.mode.displayName.lowercase(Locale.getDefault())}: ${plan.explanation}"
            )
        }

        stackTimeoutJob?.cancel()
        stackTimeoutJob = viewModelScope.launch {
            delay(plan.timeoutMs)
            if (activeStacker === stacker) {
                if (stacker.collectedFrames >= plan.minimumUsableFrames) {
                    finishNightStack()
                } else {
                    cancelNightStack("Série vypršela – nebylo dost ostrých snímků.")
                }
            }
        }

        nightPreparationJob?.cancel()
        nightPreparationJob = viewModelScope.launch {
            val manualSupported = ExposureLock.supportsManualExposure(activeCamera)
            var verifiedManual = false

            if (manualSupported) {
                val limits = ExposureLock.readLimits(activeCamera)
                val (exposure, iso) = ExposureLock.suggestExposure(
                    advice.metrics.meanLuma,
                    limits,
                    plan.exposureCapNanos
                )
                val request = ManualExposureRequest(exposure, iso)
                pendingManualRequest = request
                activeManualRequest = null
                manualRequestVerified = false
                manualMatchCount = 0
                _uiState.update {
                    it.copy(
                        exposureControlState = ExposureControlState.REQUESTED,
                        requestedExposureNanos = exposure,
                        requestedIso = iso,
                        nightStatus = "Nastavuji a ověřuji expozici…"
                    )
                }

                manualRequestSubmitted = ExposureLock.setManualExposure(activeCamera, exposure, iso)
                if (manualRequestSubmitted) {
                    val deadline = System.nanoTime() + MANUAL_VERIFY_TIMEOUT_NS
                    while (
                        activeStacker === stacker &&
                        !manualRequestVerified &&
                        System.nanoTime() < deadline
                    ) {
                        delay(MANUAL_VERIFY_POLL_MS)
                    }
                    verifiedManual = manualRequestVerified
                }
                pendingManualRequest = null

                if (verifiedManual) {
                    activeManualRequest = request
                    manualExposureActive = true
                    exposureLocked = true
                    lastExposureNanos = latestTelemetry.exposureNanos ?: exposure
                    _uiState.update { it.copy(exposureControlState = ExposureControlState.VERIFIED) }
                } else {
                    activeManualRequest = null
                    exposureLocked = ExposureLock.lock(activeCamera)
                    manualRequestSubmitted = false
                    manualExposureActive = false
                    lastExposureNanos = 0L
                    _uiState.update { it.copy(exposureControlState = ExposureControlState.FALLBACK) }
                }
            } else {
                activeManualRequest = null
                lastExposureNanos = 0L
                exposureLocked = ExposureLock.lock(activeCamera)
                _uiState.update { it.copy(exposureControlState = ExposureControlState.UNSUPPORTED) }
            }

            if (activeStacker !== stacker) return@launch
            if (!verifiedManual) {
                val evIndex = applyMaxExposureCompensation()
                nightEvApplied = evIndex != 0
            } else {
                nightEvApplied = false
            }

            val actual = latestTelemetry
            val effectiveExposure = if (verifiedManual) {
                actual.exposureNanos ?: lastExposureNanos
            } else {
                actual.exposureNanos ?: 0L
            }
            val modeText = if (verifiedManual) {
                "${plan.mode.displayName}: ${formatExposureTime(effectiveExposure)}, ISO ${actual.iso ?: "—"}, expozice ověřena."
            } else {
                "${plan.mode.displayName}: firmware nepotvrdil ruční čas, používám zamčenou automatiku."
            }
            _events.tryEmit(CameraEvent.Message(modeText))
            _uiState.update { it.copy(nightStatus = "Čekám na ustálení snímače…") }

            delay(if (verifiedManual) EXPOSURE_SETTLE_MS else FALLBACK_SETTLE_MS)
            if (activeStacker === stacker) captureNextStackFrame(activeCapture, stacker, plan)
        }
    }

    private fun captureNextStackFrame(
        capture: ImageCapture,
        stacker: FrameStacker,
        plan: NightCapturePlan
    ) {
        val context = getApplication<Application>()
        nightMotionTracker.beginFrame()
        _uiState.update {
            it.copy(nightStatus = "Snímám ${stacker.attemptedFrames + 1}/${plan.maxAttempts}…")
        }
        capture.takePicture(
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val motion = nightMotionTracker.endFrame()
                    if (activeStacker !== stacker) {
                        image.close()
                        return
                    }

                    // Dekódování, registrace a full-res blending nesmí blokovat
                    // hlavní vlákno s Compose UI a obsluhou fotoaparátu.
                    viewModelScope.launch(Dispatchers.Default) {
                        var processingError: String? = null
                        val result = try {
                            recordStackTelemetry(image.imageInfo.timestamp)
                            val rotation = image.imageInfo.rotationDegrees
                            val bitmap = image.toBitmap()
                            try {
                                stacker.addAlignedBitmap(bitmap, rotation, motion)
                            } finally {
                                bitmap.recycle()
                            }
                        } catch (_: OutOfMemoryError) {
                            processingError = "Nedostatek paměti – noční série byla bezpečně ukončena."
                            null
                        } catch (_: Throwable) {
                            processingError = "Noční snímek se nepodařilo zpracovat."
                            null
                        } finally {
                            image.close()
                        }

                        withContext(Dispatchers.Main) {
                            if (activeStacker !== stacker) return@withContext
                            if (result == null) {
                                cancelNightStack(processingError ?: "Noční snímek se nepodařilo zpracovat.")
                                return@withContext
                            }

                            val status = if (result.accepted) {
                                val shift = maxOf(
                                    abs(result.alignment.offsetX),
                                    abs(result.alignment.offsetY)
                                )
                                "Přijat ${result.acceptedFrames}/${plan.targetFrames} · " +
                                    "posun ${shift}px · pohyb " +
                                    "${(result.movingPixelRatio * 100).roundToInt()} %"
                            } else {
                                "Odmítnut: ${result.rejectReason.displayName.lowercase(Locale.getDefault())} · pokračuji"
                            }
                            _uiState.update {
                                it.copy(
                                    stackProgress = stacker.progress,
                                    nightAcceptedFrames = stacker.collectedFrames,
                                    nightRejectedFrames = stacker.rejectedFrames,
                                    nightStatus = status
                                )
                            }

                            when {
                                result.complete -> finishNightStack()
                                stacker.attemptsExhausted &&
                                    stacker.collectedFrames >= plan.minimumUsableFrames -> finishNightStack()
                                stacker.attemptsExhausted -> cancelNightStack(
                                    "Příliš mnoho snímků bylo rozhýbaných nebo nezarovnatelných."
                                )
                                else -> captureNextStackFrame(capture, stacker, plan)
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    nightMotionTracker.endFrame()
                    if (activeStacker === stacker) {
                        if (stacker.collectedFrames >= plan.minimumUsableFrames) {
                            finishNightStack()
                        } else {
                            cancelNightStack("Noční snímek se nepodařilo pořídit: ${exception.message}")
                        }
                    }
                }
            }
        )
    }

    /**
     * Uvolní zámek expozice. Kdyby zůstal, fotoaparát by dál držel jas
     * z okamžiku snímání a přestal reagovat na změnu světla.
     */
    private fun releaseExposureLock() {
        pendingManualRequest = null
        activeManualRequest = null
        manualRequestVerified = false
        manualMatchCount = 0
        if (nightEvApplied) {
            nightEvApplied = false
            resetExposureCompensation()
        }

        val activeCamera = camera
        if (manualExposureActive || manualRequestSubmitted) {
            // clearManualExposure odstraní také SENSOR_EXPOSURE_TIME a ISO.
            activeCamera?.let { ExposureLock.clearManualExposure(it) }
        } else if (exposureLocked) {
            activeCamera?.let { ExposureLock.unlock(it) }
        }
        manualExposureActive = false
        manualRequestSubmitted = false
        exposureLocked = false
        lastExposureNanos = 0L

        val supported = _uiState.value.capabilities.manualExposureSupported
        _uiState.update {
            it.copy(
                exposureControlState = if (supported) {
                    ExposureControlState.AUTO
                } else {
                    ExposureControlState.UNSUPPORTED
                },
                requestedExposureNanos = null,
                requestedIso = null
            )
        }
    }

    /** Zruší probíhající skládání a uvolní senzory i expozici. */
    fun cancelNightStack(reason: String? = null) {
        val stacker = activeStacker ?: return
        activeStacker = null
        activeNightPlan = null
        nightMotionTracker.stop()
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null
        nightPreparationJob?.cancel()
        nightPreparationJob = null
        releaseExposureLock()
        stacker.reset()
        _uiState.update {
            it.copy(
                stacking = false,
                stackProgress = 0f,
                nightStatus = reason ?: "Noční série zrušena.",
                nightActiveMode = null,
                nightTargetFrames = 0,
                nightAcceptedFrames = 0,
                nightRejectedFrames = 0
            )
        }
        reason?.let { _events.tryEmit(CameraEvent.Message(it)) }
    }


    private fun finishNightStack() {
        val stacker = activeStacker ?: return
        val plan = activeNightPlan ?: return cancelNightStack("Chybí plán noční série.")
        activeStacker = null
        activeNightPlan = null
        nightMotionTracker.stop()
        stackTimeoutJob?.cancel()
        stackTimeoutJob = null

        nightPreparationJob?.cancel()
        nightPreparationJob = null
        // Diagnostiku odvozujeme z CaptureResult hodnot spárovaných s
        // jednotlivými ImageProxy, nikoli z požadavku aplikace.
        lastStackExposureNanos = if (stackTelemetrySamples > 0) {
            stackExposureTotal / stackTelemetrySamples
        } else {
            latestTelemetry.exposureNanos ?: 0L
        }
        lastStackIso = if (stackTelemetrySamples > 0) {
            (stackIsoTotal / stackTelemetrySamples).toInt()
        } else {
            latestTelemetry.iso ?: 0
        }
        lastStackManual = stackTelemetrySamples > 0 &&
            stackManualSamples * 2 >= stackTelemetrySamples
        lastStackVerified = stackTelemetrySamples > 0 &&
            stackVerifiedSamples * 2 >= stackTelemetrySamples
        lastStackEv = nightEvApplied
        releaseExposureLock()

        val frames = stacker.collectedFrames
        val rotation = stacker.rotationDegrees
        val stats = stacker.stats
        _uiState.update { it.copy(nightStatus = "Skládám a tónuji výsledný snímek…") }
        viewModelScope.launch(Dispatchers.Default) {
            val result = runCatching {
                val bitmap = stacker.buildBitmap()
                    ?: return@runCatching NightSaveResult(
                        uri = null,
                        error = "Skládání snímků se nezdařilo."
                    )
                try {
                    val uri = saveStackedBitmap(
                        getApplication(),
                        bitmap,
                        frames,
                        rotation,
                        plan,
                        stats
                    )
                    NightSaveResult(
                        uri = uri,
                        error = if (uri == null) "Noční snímek se nepodařilo uložit." else null
                    )
                } finally {
                    bitmap.recycle()
                }
            }.getOrElse { error ->
                NightSaveResult(
                    uri = null,
                    error = if (error is OutOfMemoryError) {
                        "Nedostatek paměti při dokončování noční fotografie."
                    } else {
                        "Noční fotografii se nepodařilo dokončit."
                    }
                )
            }
            stacker.reset()

            withContext(Dispatchers.Main) {
                val success = result.uri != null
                _uiState.update {
                    it.copy(
                        stacking = false,
                        stackProgress = 0f,
                        nightActiveMode = null,
                        // Po dokončení ponecháme skutečný cíl i výsledné počty
                        // v diagnostice; při příští sérii se přepíšou.
                        nightTargetFrames = plan.targetFrames,
                        nightAcceptedFrames = frames,
                        nightRejectedFrames = stats.rejectedFrames,
                        nightStatus = if (success) {
                            "Hotovo: $frames přijatých, ${stats.rejectedFrames} odmítnutých snímků."
                        } else {
                            result.error ?: "Noční snímek se nepodařilo uložit."
                        }
                    )
                }
                if (success) {
                    _events.tryEmit(
                        CameraEvent.PhotoSaved(
                            result.uri,
                            "${plan.mode.displayName}: $frames snímků složeno, ${stats.rejectedFrames} odmítnuto."
                        )
                    )
                } else {
                    _events.tryEmit(
                        CameraEvent.Message(result.error ?: "Noční snímek se nepodařilo uložit.")
                    )
                }
            }
        }
    }

    private fun saveStackedBitmap(
        context: Context,
        bitmap: Bitmap,
        frames: Int,
        rotationDegrees: Int,
        plan: NightCapturePlan,
        stats: NightStackStats
    ): Uri? {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(
                MediaStore.MediaColumns.DISPLAY_NAME,
                "AI_Foto_${timestamp}_noc_${plan.mode.name.lowercase(Locale.US)}.jpg"
            )
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val written = resolver.openOutputStream(uri, "w")?.use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            } == true
            if (!written) error("JPEG encoder neuložil výstup.")

            writeStackExif(context, uri, frames, rotationDegrees, plan, stats)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val published = resolver.update(
                    uri,
                    ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) },
                    null,
                    null
                )
                if (published <= 0) error("MediaStore nezveřejnil dokončenou fotografii.")
            }
            uri
        } catch (_: Throwable) {
            resolver.delete(uri, null, null)
            null
        }
    }

    /**
     * Doplní metadata do uložené fotky.
     *
     * Bez orientace by galerie zobrazila snímek otočený - analyzér dodává
     * obraz v orientaci snímače, ne v té, jak telefon držíme. Poznámka
     * o počtu složených snímků se hodí při pozdějším porovnávání výsledků.
     */
    private fun writeStackExif(
        context: Context,
        uri: Uri,
        frames: Int,
        rotationDegrees: Int,
        plan: NightCapturePlan,
        stats: NightStackStats
    ) {
        try {
            context.contentResolver.openFileDescriptor(uri, "rw")?.use { descriptor ->
                val exif = ExifInterface(descriptor.fileDescriptor)
                exif.setAttribute(
                    ExifInterface.TAG_ORIENTATION,
                    when (rotationDegrees) {
                        90 -> ExifInterface.ORIENTATION_ROTATE_90
                        180 -> ExifInterface.ORIENTATION_ROTATE_180
                        270 -> ExifInterface.ORIENTATION_ROTATE_270
                        else -> ExifInterface.ORIENTATION_NORMAL
                    }.toString()
                )
                exif.setAttribute(ExifInterface.TAG_SOFTWARE, "AI FotoAsistent v0.9")
                // Do popisu zapíšeme, co se reálně dělo - podle toho jde z hotové
                // fotky poznat, jestli dlouhá expozice a plné rozlišení zabraly.
                val exposureMs = lastStackExposureNanos / 1_000_000L
                val description = buildString {
                    append("Computational Night ${plan.mode.name} - slozeno z $frames snimku")
                    append(", odmitnuto ${stats.rejectedFrames}")
                    append(", prumerny pohyb ${"%.1f".format(Locale.US, stats.averageMovingPixelRatio * 100f)} %")
                    append(", max posun ${stats.maximumShiftPx}px")
                    if (exposureMs > 0) append(", skutecna expozice ${exposureMs}ms/snimek")
                    if (lastStackIso > 0) append(", skutecne ISO $lastStackIso")
                    when {
                        lastStackVerified -> append(", manualni expozice overena CaptureResult")
                        lastStackManual -> append(", manualni AE podle CaptureResult")
                        else -> append(", automaticka expozice")
                    }
                    if (lastStackEv) append(", EV fallback")
                }
                exif.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, description)
                if (lastStackExposureNanos > 0) {
                    exif.setAttribute(
                        ExifInterface.TAG_EXPOSURE_TIME,
                        (lastStackExposureNanos / 1_000_000_000.0).toString()
                    )
                }
                if (lastStackIso > 0) {
                    exif.setAttribute(
                        ExifInterface.TAG_ISO_SPEED_RATINGS,
                        lastStackIso.toString()
                    )
                }
                exif.setAttribute(
                    ExifInterface.TAG_DATETIME,
                    SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
                        .format(System.currentTimeMillis())
                )
                exif.saveAttributes()
            }
        } catch (_: Throwable) {
            // Metadata jsou doplněk - fotka je uložená i bez nich.
        }
    }

    /**
     * Vytvoří AI upravenou KOPII. Originál z fotoaparátu zůstává beze změny,
     * včetně kompletního OEM EXIFu a případné HDR gain mapy.
     */
    private fun enhanceSavedPhoto(context: Context, originalUri: Uri, timestamp: String) {
        viewModelScope.launch(Dispatchers.Default) {
            val enhancedUri = runCatching {
                val resolver = context.contentResolver
                val exifAttributes = readExifAttributes(context, originalUri)
                val source = resolver.openInputStream(originalUri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                } ?: return@runCatching null

                val width = source.width
                val height = source.height
                if (width <= 0 || height <= 0 ||
                    width.toLong() * height.toLong() > MAX_ENHANCE_PIXELS
                ) {
                    source.recycle()
                    return@runCatching null
                }

                val pixels = IntArray(width * height)
                source.getPixels(pixels, 0, width, 0, 0, width, height)
                source.recycle()
                val adjusted = PostProcess.enhancePixels(pixels, width, height)
                val output = Bitmap.createBitmap(
                    adjusted,
                    width,
                    height,
                    Bitmap.Config.ARGB_8888
                )

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_Foto_${timestamp}_AI.jpg")
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI FotoAsistent")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                }
                val target = resolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    values
                ) ?: run {
                    output.recycle()
                    return@runCatching null
                }

                try {
                    val written = resolver.openOutputStream(target, "w")?.use { stream ->
                        output.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                    } ?: false
                    if (!written) throw IllegalStateException("JPEG se nepodařilo zapsat")
                    writeExifAttributes(context, target, exifAttributes)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        resolver.update(
                            target,
                            ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) },
                            null,
                            null
                        )
                    }
                    target
                } catch (error: Throwable) {
                    resolver.delete(target, null, null)
                    throw error
                } finally {
                    output.recycle()
                }
            }.getOrNull()

            withContext(Dispatchers.Main) {
                _uiState.update { it.copy(isSaving = false) }
                _events.tryEmit(
                    CameraEvent.PhotoSaved(
                        enhancedUri ?: originalUri,
                        if (enhancedUri != null) {
                            "Uložen originál i samostatná AI verze (stíny a šum)."
                        } else {
                            "Fotografie byla uložena; originál zůstal beze změny."
                        }
                    )
                )
            }
        }
    }

    private fun readExifAttributes(context: Context, uri: Uri): Map<String, String> = try {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
            val exif = ExifInterface(descriptor.fileDescriptor)
            EXIF_COPY_TAGS.mapNotNull { tag ->
                exif.getAttribute(tag)?.let { tag to it }
            }.toMap()
        }.orEmpty()
    } catch (_: Throwable) {
        emptyMap()
    }

    private fun writeExifAttributes(
        context: Context,
        uri: Uri,
        attributes: Map<String, String>
    ) {
        try {
            context.contentResolver.openFileDescriptor(uri, "rw")?.use { descriptor ->
                val exif = ExifInterface(descriptor.fileDescriptor)
                attributes.forEach { (tag, value) -> exif.setAttribute(tag, value) }
                exif.setAttribute(ExifInterface.TAG_SOFTWARE, "AI FotoAsistent v0.9")
                exif.setAttribute(
                    ExifInterface.TAG_IMAGE_DESCRIPTION,
                    "AI upravena kopie; puvodni fotografie zachovana beze zmeny"
                )
                exif.saveAttributes()
            }
        } catch (_: Throwable) {
            // Kopie je použitelná i bez doplňkových metadat.
        }
    }


    /** MIME z MediaStore bývá spolehlivý, ale některé OEM callbacky ho vrátí
     * až po dokončení indexace. V takovém případě použijeme skutečný název
     * uloženého souboru; pořadí callbacků nikdy nehádáme. */
    private fun detectSavedFormat(context: Context, uri: Uri): SavedFormat? {
        val resolver = context.contentResolver
        when (resolver.getType(uri)?.lowercase(Locale.US)) {
            "image/jpeg", "image/jpg" -> return SavedFormat.JPEG
            "image/x-adobe-dng", "image/dng", "image/x-dng" -> return SavedFormat.RAW
        }
        val displayName = runCatching {
            resolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (!cursor.moveToFirst()) null
                else cursor.getString(0)
            }
        }.getOrNull()?.lowercase(Locale.US)
        return when {
            displayName?.endsWith(".jpg") == true || displayName?.endsWith(".jpeg") == true ->
                SavedFormat.JPEG
            displayName?.endsWith(".dng") == true -> SavedFormat.RAW
            else -> null
        }
    }

    private fun resetStackTelemetry() {
        stackExposureTotal = 0L
        stackIsoTotal = 0L
        stackTelemetrySamples = 0
        stackManualSamples = 0
        stackVerifiedSamples = 0
    }

    private fun recordStackTelemetry(imageTimestampNanos: Long) {
        val telemetry = synchronized(telemetryLock) {
            telemetryHistory
                .filter { it.sensorTimestampNanos != null }
                .minByOrNull { item ->
                    abs((item.sensorTimestampNanos ?: Long.MAX_VALUE) - imageTimestampNanos)
                }
        } ?: latestTelemetry

        val sensorTimestamp = telemetry.sensorTimestampNanos
        if (sensorTimestamp != null &&
            abs(sensorTimestamp - imageTimestampNanos) > TELEMETRY_MATCH_TOLERANCE_NS
        ) return

        val exposure = telemetry.exposureNanos ?: return
        val iso = telemetry.iso ?: return
        stackExposureTotal += exposure
        stackIsoTotal += iso.toLong()
        stackTelemetrySamples += 1
        if (telemetry.manualSensorActive) stackManualSamples += 1
        activeManualRequest?.let { request ->
            if (telemetry.matches(request)) stackVerifiedSamples += 1
        }
    }

    override fun onCleared() {
        nightMotionTracker.stop()
        super.onCleared()
    }

    private fun hardwareLevelLabel(level: Int?): String = when (level) {
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
        else -> "NEZNÁMÝ"
    }

    private fun formatExposureTime(exposureNanos: Long): String {
        if (exposureNanos <= 0L) return "—"
        val seconds = exposureNanos / 1_000_000_000.0
        return when {
            seconds >= 1.0 -> "%.1f s".format(Locale.US, seconds)
            seconds >= 0.1 -> "%.0f ms".format(Locale.US, seconds * 1000.0)
            else -> "1/%.0f s".format(Locale.US, 1.0 / seconds)
        }
    }

    private fun formatZoomFactor(value: Float): String =
        if (abs(value - value.toInt()) < 0.04f) {
            "${value.toInt()}×"
        } else {
            "${"%.1f".format(Locale.US, value).replace('.', ',')}×"
        }

    private fun formatEv(ev: Float): String = when {
        ev > 0f -> "+%.1f".format(Locale.US, ev)
        ev < 0f -> "%.1f".format(Locale.US, ev)
        else -> "0"
    }

    private companion object {
        /**
         * Strop pro dokončovací úpravu uložené fotky. Úprava drží v paměti
         * několik polí o velikosti snímku; při 12 MPix je špička kolem 140 MB,
         * což ještě projde, ale výš už hrozí vyčerpání paměti.
         */
        const val MAX_ENHANCE_PIXELS = 12_500_000L

        /** Jen varování v UI; skutečné odmítnutí dělá gyroskop a registrace každého snímku. */
        const val NIGHT_PREVIEW_WARNING_MOTION = 0.38f

        /** Prodleva, než snímač převezme ručně nastavenou dlouhou expozici. */
        const val EXPOSURE_SETTLE_MS = 400L

        const val FALLBACK_SETTLE_MS = 250L
        const val MANUAL_VERIFY_POLL_MS = 40L
        const val REQUIRED_MANUAL_MATCHES = 2
        const val MANUAL_VERIFY_TIMEOUT_NS = 1_600_000_000L
        const val TELEMETRY_UI_INTERVAL_NS = 250_000_000L
        const val COACH_POSE_INTERVAL_NS = 125_000_000L
        const val TELEMETRY_MATCH_TOLERANCE_NS = 120_000_000L
        const val TELEMETRY_HISTORY_SIZE = 48
        const val FOCAL_MATCH_TOLERANCE = 0.15f
        const val DUAL_CAPTURE_GRACE_MS = 2_000L
        const val DUAL_CAPTURE_ERROR_GRACE_MS = 700L

        val EXIF_COPY_TAGS = listOf(
            ExifInterface.TAG_APERTURE_VALUE,
            ExifInterface.TAG_DATETIME,
            ExifInterface.TAG_DATETIME_DIGITIZED,
            ExifInterface.TAG_DATETIME_ORIGINAL,
            ExifInterface.TAG_EXPOSURE_BIAS_VALUE,
            ExifInterface.TAG_EXPOSURE_MODE,
            ExifInterface.TAG_EXPOSURE_PROGRAM,
            ExifInterface.TAG_EXPOSURE_TIME,
            ExifInterface.TAG_F_NUMBER,
            ExifInterface.TAG_FLASH,
            ExifInterface.TAG_FOCAL_LENGTH,
            ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
            ExifInterface.TAG_GPS_ALTITUDE,
            ExifInterface.TAG_GPS_ALTITUDE_REF,
            ExifInterface.TAG_GPS_DATESTAMP,
            ExifInterface.TAG_GPS_LATITUDE,
            ExifInterface.TAG_GPS_LATITUDE_REF,
            ExifInterface.TAG_GPS_LONGITUDE,
            ExifInterface.TAG_GPS_LONGITUDE_REF,
            ExifInterface.TAG_GPS_TIMESTAMP,
            ExifInterface.TAG_ISO_SPEED_RATINGS,
            ExifInterface.TAG_MAKE,
            ExifInterface.TAG_MODEL,
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.TAG_WHITE_BALANCE
        )
    }
}

data class CameraUiState(
    val cameraReady: Boolean = false,
    val selectedZoom: Float = 1f,
    val minZoom: Float = 1f,
    val maxZoom: Float = 10f,
    val flashMode: FlashMode = FlashMode.OFF,
    val torchOn: Boolean = false,
    val torchAvailable: Boolean = false,
    val rawSupported: Boolean = false,
    val rawEnabled: Boolean = false,
    val isSaving: Boolean = false,
    val focusPoint: FocusPoint? = null,
    val focusPulse: Int = 0,
    val stacking: Boolean = false,
    val stackProgress: Float = 0f,
    val stackingAvailable: Boolean = false,
    val nightModePreference: NightModePreference = NightModePreference.AUTO,
    val nightActiveMode: NightCaptureMode? = null,
    val nightTargetFrames: Int = 0,
    val nightAcceptedFrames: Int = 0,
    val nightRejectedFrames: Int = 0,
    val nightStatus: String = "Computational Night připraven.",
    val selfTimerSeconds: Int = 0,
    val countdownRemaining: Int = 0,
    /** Poslední skutečný CaptureResult z fotoaparátu. */
    val captureTelemetry: CaptureTelemetry = CaptureTelemetry(),
    val exposureControlState: ExposureControlState = ExposureControlState.AUTO,
    val requestedExposureNanos: Long? = null,
    val requestedIso: Int? = null,
    val capabilities: CameraCapabilities = CameraCapabilities(),
    val diagnosticsVisible: Boolean = false,
    val lensCatalog: LensCatalogState = LensCatalogState(),
    val requestedLensId: String? = null,
    val boundLensId: String? = null,
    val lensRecommendation: LensRecommendation = LensRecommendation(
        lensId = null,
        equivalentZoom = 1f,
        displayLabel = "1× hlavní",
        reason = "Čeká se na katalog objektivů."
    ),
    val lensTruth: LensTruth = LensTruth(),
    val lensFallbackActive: Boolean = false,
    val extensionAvailability: ExtensionAvailability = ExtensionAvailability(),
    val requestedExtensionMode: OemExtensionMode = OemExtensionMode.NONE,
    val activeExtensionMode: OemExtensionMode = OemExtensionMode.NONE,
    val coachState: CoachState = CoachState()
)

data class CameraCapabilities(
    val cameraId: String? = null,
    val hardwareLevel: String = "NEZNÁMÝ",
    val manualExposureSupported: Boolean = false,
    val minExposureNanos: Long = 0L,
    val maxExposureNanos: Long = 0L,
    val minIso: Int = 0,
    val maxIso: Int = 0,
    val rawSupported: Boolean = false
)

data class FocusPoint(val x: Float, val y: Float)

enum class FlashMode(val label: String, val shortLabel: String) {
    OFF("Blesk vyp.", "⚡✕"),
    AUTO("Blesk auto", "⚡A"),
    ON("Blesk zap.", "⚡")
}

private enum class SavedFormat { JPEG, RAW }

private data class NightSaveResult(
    val uri: Uri?,
    val error: String?
)

sealed interface CameraEvent {
    data class Message(val text: String) : CameraEvent
    data class PhotoSaved(val uri: Uri?, val text: String) : CameraEvent
}
