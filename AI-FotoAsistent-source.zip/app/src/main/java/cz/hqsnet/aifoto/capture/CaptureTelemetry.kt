package cz.hqsnet.aifoto.capture

import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.os.Build
import kotlin.math.abs
import kotlin.math.max

/**
 * Hodnoty, které fotoaparát skutečně použil v dokončeném Camera2 požadavku.
 *
 * Nejde o přání aplikace ani fotografické doporučení. Data pocházejí přímo
 * z [CaptureResult], takže podle nich lze poznat, zda firmware ruční expozici
 * opravdu přijal, nebo ji potichu nahradil automatikou.
 */
data class CaptureTelemetry(
    val exposureNanos: Long? = null,
    val iso: Int? = null,
    val aeMode: Int? = null,
    val awbMode: Int? = null,
    val afMode: Int? = null,
    val focusDistance: Float? = null,
    /** Ohnisková vzdálenost, kterou HAL skutečně použil. */
    val focalLengthMm: Float? = null,
    /** Aktivní fyzický modul uvnitř logické kamery (Android 10+). */
    val activePhysicalCameraId: String? = null,
    /** Skutečný crop region; slouží k odhalení digitálního výřezu. */
    val cropRegionWidth: Int? = null,
    val cropRegionHeight: Int? = null,
    /** Čas expozice ze snímače; odpovídá ImageInfo.timestamp. */
    val sensorTimestampNanos: Long? = null,
    /** Monotónní čas přijetí callbacku, pro kontrolu čerstvosti. */
    val receivedAtNanos: Long = System.nanoTime()
) {
    val manualSensorActive: Boolean
        get() = aeMode == CaptureRequest.CONTROL_AE_MODE_OFF &&
            exposureNanos != null && iso != null

    /**
     * Ověří, že reálný výsledek odpovídá požadavku. Některé HAL hodnoty
     * zaokrouhlují podle řádkového času snímače, proto používáme malou toleranci.
     */
    fun matches(request: ManualExposureRequest): Boolean {
        // Výsledek doručený ještě před odesláním požadavku nesmí potvrdit
        // novou expozici, i kdyby náhodou obsahoval stejné hodnoty.
        if (receivedAtNanos < request.submittedAtNanos) return false
        if (!manualSensorActive) return false
        val actualExposure = exposureNanos ?: return false
        val actualIso = iso ?: return false
        val exposureTolerance = max(2_000_000L, (request.exposureNanos * 0.12).toLong())
        val isoTolerance = max(8, (request.iso * 0.12).toInt())
        return abs(actualExposure - request.exposureNanos) <= exposureTolerance &&
            abs(actualIso - request.iso) <= isoTolerance
    }

    companion object {
        fun from(result: CaptureResult): CaptureTelemetry = CaptureTelemetry(
            exposureNanos = result.get(CaptureResult.SENSOR_EXPOSURE_TIME),
            iso = result.get(CaptureResult.SENSOR_SENSITIVITY),
            aeMode = result.get(CaptureResult.CONTROL_AE_MODE),
            awbMode = result.get(CaptureResult.CONTROL_AWB_MODE),
            afMode = result.get(CaptureResult.CONTROL_AF_MODE),
            focusDistance = result.get(CaptureResult.LENS_FOCUS_DISTANCE),
            focalLengthMm = result.get(CaptureResult.LENS_FOCAL_LENGTH),
            activePhysicalCameraId = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID)
            } else null,
            cropRegionWidth = result.get(CaptureResult.SCALER_CROP_REGION)?.width(),
            cropRegionHeight = result.get(CaptureResult.SCALER_CROP_REGION)?.height(),
            sensorTimestampNanos = result.get(CaptureResult.SENSOR_TIMESTAMP)
        )
    }
}

data class ManualExposureRequest(
    val exposureNanos: Long,
    val iso: Int,
    val submittedAtNanos: Long = System.nanoTime()
)

enum class ExposureControlState {
    /** Běžná automatika, hodnoty v UI jsou pouze naměřené. */
    AUTO,

    /** Požadavek byl odeslán a čeká se na CaptureResult. */
    REQUESTED,

    /** CaptureResult potvrdil požadovaný čas, ISO a vypnuté AE. */
    VERIFIED,

    /** Firmware ruční hodnoty nepotvrdil; používá se AE lock + EV pojistka. */
    FALLBACK,

    /** Snímač nemá MANUAL_SENSOR capability. */
    UNSUPPORTED
}
