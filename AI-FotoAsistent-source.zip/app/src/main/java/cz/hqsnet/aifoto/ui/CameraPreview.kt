package cz.hqsnet.aifoto.ui

import android.content.Context
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.TotalCaptureResult
import android.hardware.display.DisplayManager
import android.view.Surface
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionSessionConfig
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import cz.hqsnet.aifoto.CameraViewModel
import cz.hqsnet.aifoto.analysis.SceneAnalyzer
import cz.hqsnet.aifoto.capture.CaptureTelemetry
import cz.hqsnet.aifoto.lens.ExtensionAvailability
import cz.hqsnet.aifoto.lens.LensCatalog
import cz.hqsnet.aifoto.lens.LensProfile
import cz.hqsnet.aifoto.lens.OemExtensionMode
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

@OptIn(ExperimentalCamera2Interop::class)
@Composable
fun CameraPreview(
    viewModel: CameraViewModel,
    modifier: Modifier = Modifier,
    overlay: @Composable (PreviewView) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            // FIT_CENTER je záměr: uživatel vidí celý 4:3 záběr a fotografie
            // nebude obsahovat nečekané okraje mimo náhled.
            scaleType = PreviewView.ScaleType.FIT_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val analyzer = remember(viewModel) { SceneAnalyzer(viewModel::onAdvice) }
    val captureResultCallback = remember(viewModel) {
        object : CameraCaptureSession.CaptureCallback() {
            override fun onCaptureCompleted(
                session: CameraCaptureSession,
                request: CaptureRequest,
                result: TotalCaptureResult
            ) {
                // Skutečné hodnoty vrácené HALem: fyzické ID, ohnisko,
                // crop region, čas a ISO. Nejde o pouhý požadavek aplikace.
                viewModel.onCaptureTelemetry(CaptureTelemetry.from(result))
            }
        }
    }

    val uiState by viewModel.uiState.collectAsState()
    val rawRequested = uiState.rawEnabled
    val requestedLensId = uiState.requestedLensId
    val requestedExtension = uiState.requestedExtensionMode

    // Výstupní formát, fyzický modul i OEM extension jsou vlastnosti session.
    // Každá změna proto bezpečně vytvoří novou CameraX vazbu.
    DisposableEffect(
        lifecycleOwner,
        previewView,
        rawRequested,
        requestedLensId,
        requestedExtension
    ) {
        val disposed = AtomicBoolean(false)
        val mainExecutor = ContextCompat.getMainExecutor(context)
        val providerFuture = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        var displayManager: DisplayManager? = null
        var displayListener: DisplayManager.DisplayListener? = null
        var activePreview: Preview? = null
        var activeCapture: ImageCapture? = null
        var activeAnalysis: ImageAnalysis? = null

        fun registerRotationListener() {
            if (displayListener != null) return
            displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            displayListener = object : DisplayManager.DisplayListener {
                override fun onDisplayAdded(displayId: Int) = Unit
                override fun onDisplayRemoved(displayId: Int) = Unit
                override fun onDisplayChanged(displayId: Int) {
                    val display = previewView.display ?: return
                    if (display.displayId != displayId) return
                    val rotation = display.rotation
                    activePreview?.targetRotation = rotation
                    activeCapture?.targetRotation = rotation
                    activeAnalysis?.targetRotation = rotation
                }
            }
            displayManager?.registerDisplayListener(displayListener, null)
        }

        fun cameraInfoFor(
            cameraProvider: ProcessCameraProvider,
            selector: CameraSelector
        ) = runCatching {
            selector.filter(cameraProvider.availableCameraInfos).firstOrNull()
        }.getOrNull()

        fun supportsRaw(
            cameraProvider: ProcessCameraProvider,
            selector: CameraSelector,
            profile: LensProfile?,
            extensionMode: OemExtensionMode
        ): Boolean {
            if (extensionMode != OemExtensionMode.NONE) return false
            if (profile != null && !profile.rawSupported) return false
            val info = cameraInfoFor(cameraProvider, selector) ?: return false
            return runCatching {
                ImageCapture.getImageCaptureCapabilities(info)
                    .supportedOutputFormats
                    .contains(ImageCapture.OUTPUT_FORMAT_RAW_JPEG)
            }.getOrDefault(false)
        }

        fun buildPreview(
            rotation: Int,
            extensionMode: OemExtensionMode
        ): Preview {
            val builder = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setTargetRotation(rotation)
            // Camera2Interop callback u OEM Extensions záměrně nepřidáváme:
            // vendor session může vlastními parametry přepsat a vazbu odmítnout.
            if (extensionMode == OemExtensionMode.NONE) {
                Camera2Interop.Extender(builder)
                    .setSessionCaptureCallback(captureResultCallback)
            }
            return builder.build().also {
                it.surfaceProvider = previewView.surfaceProvider
            }
        }

        fun buildCapture(rotation: Int, rawSupported: Boolean): ImageCapture =
            ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(
                            AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
                        )
                        .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                        .build()
                )
                .setTargetRotation(rotation)
                .apply {
                    if (rawSupported && rawRequested) {
                        setOutputFormat(ImageCapture.OUTPUT_FORMAT_RAW_JPEG)
                    }
                }
                .build()

        fun buildAnalysis(rotation: Int): ImageAnalysis =
            ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setTargetRotation(rotation)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()
                .also {
                    analyzer.resetState()
                    it.setAnalyzer(cameraExecutor, analyzer)
                }

        fun attachBoundSession(
            cameraProvider: ProcessCameraProvider,
            camera: Camera,
            capture: ImageCapture,
            rawSupported: Boolean,
            profile: LensProfile?,
            extensionMode: OemExtensionMode,
            fallback: Boolean
        ) {
            if (fallback && profile != null) {
                val zoomState = camera.cameraInfo.zoomState.value
                val min = zoomState?.minZoomRatio ?: 1f
                val max = zoomState?.maxZoomRatio ?: profile.equivalentZoom
                camera.cameraControl.setZoomRatio(profile.equivalentZoom.coerceIn(min, max))
            }
            viewModel.attachCamera(
                camera = camera,
                imageCapture = capture,
                rawSupported = rawSupported,
                stackingSupported = extensionMode == OemExtensionMode.NONE,
                boundLens = profile,
                extensionMode = extensionMode,
                lensFallback = fallback
            )
            registerRotationListener()
        }

        fun bindSession(
            cameraProvider: ProcessCameraProvider,
            selector: CameraSelector,
            profile: LensProfile?,
            extensionMode: OemExtensionMode,
            fallback: Boolean = false
        ): Camera {
            val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
            val rawSupported = supportsRaw(cameraProvider, selector, profile, extensionMode)
            val preview = buildPreview(rotation, extensionMode)
            val capture = buildCapture(rotation, rawSupported)
            val analysis = if (extensionMode == OemExtensionMode.NONE) {
                buildAnalysis(rotation)
            } else {
                null
            }

            cameraProvider.unbindAll()
            val camera = if (analysis != null) {
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    capture,
                    analysis
                )
            } else {
                // CameraX Extensions garantují Preview + ImageCapture. Analýzu
                // nepřidáváme, protože ne každý vendor ji v rozšířené session umí.
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    selector,
                    preview,
                    capture
                )
            }
            activePreview = preview
            activeCapture = capture
            activeAnalysis = analysis
            attachBoundSession(
                cameraProvider,
                camera,
                capture,
                rawSupported,
                profile,
                extensionMode,
                fallback
            )
            return camera
        }

        fun bindExtensionSession(
            cameraProvider: ProcessCameraProvider,
            extensionsManager: ExtensionsManager,
            extensionMode: OemExtensionMode,
            extensionValue: Int
        ) {
            val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
            val preview = buildPreview(rotation, extensionMode)
            val capture = buildCapture(rotation, rawSupported = false)
            val sessionConfig = ExtensionSessionConfig.Builder(
                extensionValue,
                extensionsManager
            )
                .addUseCase(preview)
                .addUseCase(capture)
                .build()

            cameraProvider.unbindAll()
            val camera = cameraProvider.bindToLifecycle(
                lifecycleOwner,
                CameraSelector.DEFAULT_BACK_CAMERA,
                sessionConfig
            )
            activePreview = preview
            activeCapture = capture
            activeAnalysis = null
            attachBoundSession(
                cameraProvider = cameraProvider,
                camera = camera,
                capture = capture,
                rawSupported = false,
                profile = null,
                extensionMode = extensionMode,
                fallback = false
            )
        }

        fun bindNormalOrFallback(
            cameraProvider: ProcessCameraProvider,
            profile: LensProfile?
        ) {
            val selector = LensCatalog.selectorFor(profile)
            try {
                bindSession(
                    cameraProvider = cameraProvider,
                    selector = selector,
                    profile = profile,
                    extensionMode = OemExtensionMode.NONE
                )
            } catch (physicalError: Throwable) {
                if (profile == null) throw physicalError
                viewModel.onLensBindingFallback(profile, physicalError.message)
                bindSession(
                    cameraProvider = cameraProvider,
                    selector = CameraSelector.DEFAULT_BACK_CAMERA,
                    profile = profile,
                    extensionMode = OemExtensionMode.NONE,
                    fallback = true
                )
            }
        }

        fun extensionConstant(mode: OemExtensionMode): Int? = when (mode) {
            OemExtensionMode.NONE -> null
            OemExtensionMode.AUTO -> ExtensionMode.AUTO
            OemExtensionMode.NIGHT -> ExtensionMode.NIGHT
            OemExtensionMode.HDR -> ExtensionMode.HDR
        }

        fun startBinding(
            cameraProvider: ProcessCameraProvider,
            extensionsManager: ExtensionsManager?
        ) {
            if (disposed.get()) return
            try {
                val catalog = LensCatalog.discover(context, cameraProvider)
                viewModel.onLensCatalog(catalog)
                val requestedProfile = catalog.profile(requestedLensId)

                val availability = if (extensionsManager != null) {
                    ExtensionAvailability(
                        auto = runCatching {
                            extensionsManager.isExtensionAvailable(
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                ExtensionMode.AUTO
                            )
                        }.getOrDefault(false),
                        night = runCatching {
                            extensionsManager.isExtensionAvailable(
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                ExtensionMode.NIGHT
                            )
                        }.getOrDefault(false),
                        hdr = runCatching {
                            extensionsManager.isExtensionAvailable(
                                CameraSelector.DEFAULT_BACK_CAMERA,
                                ExtensionMode.HDR
                            )
                        }.getOrDefault(false)
                    )
                } else {
                    ExtensionAvailability()
                }
                viewModel.onExtensionAvailability(availability)

                val extension = requestedExtension.takeIf(availability::supports)
                    ?: OemExtensionMode.NONE
                val extensionValue = extensionConstant(extension)
                if (
                    extensionValue != null &&
                    extensionsManager != null &&
                    !rawRequested
                ) {
                    try {
                        bindExtensionSession(
                            cameraProvider = cameraProvider,
                            extensionsManager = extensionsManager,
                            extensionMode = extension,
                            extensionValue = extensionValue
                        )
                        return
                    } catch (extensionError: Throwable) {
                        viewModel.onExtensionFallback(extension, extensionError.message)
                    }
                }
                bindNormalOrFallback(cameraProvider, requestedProfile)
            } catch (error: Throwable) {
                viewModel.onCameraError(error.message)
            }
        }

        providerFuture.addListener(providerListener@{
            if (disposed.get()) return@providerListener
            try {
                val cameraProvider = providerFuture.get()
                provider = cameraProvider
                val extensionsFuture = ExtensionsManager.getInstanceAsync(context, cameraProvider)
                extensionsFuture.addListener(extensionListener@{
                    if (disposed.get()) return@extensionListener
                    val manager = runCatching { extensionsFuture.get() }.getOrNull()
                    startBinding(cameraProvider, manager)
                }, mainExecutor)
            } catch (error: Throwable) {
                viewModel.onCameraError(error.message)
            }
        }, mainExecutor)

        onDispose {
            disposed.set(true)
            displayListener?.let { displayManager?.unregisterDisplayListener(it) }
            provider?.unbindAll()
            viewModel.detachCamera()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            analyzer.close()
            cameraExecutor.shutdown()
        }
    }

    Box(modifier = modifier) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(previewView) {
                    detectTapGestures { offset ->
                        // FIT_CENTER vytváří černé pruhy. Bod v pruhu není
                        // součástí obrazu a nesmí se poslat jako bod ostření.
                        if (isInsideFourThreePreview(offset, size.width, size.height)) {
                            viewModel.focusAt(previewView, offset.x, offset.y)
                        }
                    }
                }
        ) {
            overlay(previewView)
        }
    }
}

/** Oblast skutečně zobrazeného 4:3 snímku uvnitř FIT_CENTER náhledu. */
private fun isInsideFourThreePreview(point: Offset, viewWidth: Int, viewHeight: Int): Boolean {
    if (viewWidth <= 0 || viewHeight <= 0) return false
    val contentAspect = if (viewHeight >= viewWidth) 3f / 4f else 4f / 3f
    val viewAspect = viewWidth.toFloat() / viewHeight.toFloat()
    val left: Float
    val top: Float
    val right: Float
    val bottom: Float
    if (viewAspect > contentAspect) {
        val contentWidth = viewHeight * contentAspect
        left = (viewWidth - contentWidth) / 2f
        right = left + contentWidth
        top = 0f
        bottom = viewHeight.toFloat()
    } else {
        val contentHeight = viewWidth / contentAspect
        top = (viewHeight - contentHeight) / 2f
        bottom = top + contentHeight
        left = 0f
        right = viewWidth.toFloat()
    }
    return point.x in left..right && point.y in top..bottom
}
