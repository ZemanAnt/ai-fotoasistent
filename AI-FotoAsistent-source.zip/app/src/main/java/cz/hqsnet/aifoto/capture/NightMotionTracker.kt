package cz.hqsnet.aifoto.capture

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Měří skutečný pohyb telefonu během každé expozice. Neodhaduje posun obrazu
 * samo – slouží jako nezávislá pojistka k obrazovému zarovnání.
 */
class NightMotionTracker(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        ?: sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val lock = Any()
    private var running = false
    private var frameActive = false
    private var lastGyroTimestamp = 0L
    private var angularDistance = 0f
    private var peakAngularVelocity = 0f
    private var accelerationImpulse = 0f
    private var lastAccelerationTimestamp = 0L

    val isAvailable: Boolean get() = gyroscope != null

    fun start() {
        if (running) return
        running = true
        gyroscope?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        if (!running) return
        running = false
        sensorManager.unregisterListener(this)
        synchronized(lock) { resetFrameLocked() }
    }

    fun beginFrame() {
        synchronized(lock) {
            resetFrameLocked()
            frameActive = true
        }
    }

    fun endFrame(): NightMotionSample = synchronized(lock) {
        val sample = NightMotionSample(
            angularDistanceRadians = angularDistance,
            peakAngularVelocity = peakAngularVelocity,
            accelerationImpulse = accelerationImpulse,
            sensorAvailable = gyroscope != null
        )
        frameActive = false
        lastGyroTimestamp = 0L
        lastAccelerationTimestamp = 0L
        sample
    }

    override fun onSensorChanged(event: SensorEvent) {
        synchronized(lock) {
            if (!running || !frameActive) return
            when (event.sensor.type) {
                Sensor.TYPE_GYROSCOPE -> {
                    val magnitude = sqrt(
                        event.values[0] * event.values[0] +
                            event.values[1] * event.values[1] +
                            event.values[2] * event.values[2]
                    )
                    if (lastGyroTimestamp != 0L) {
                        val dt = (event.timestamp - lastGyroTimestamp) / 1_000_000_000f
                        if (dt in 0f..0.25f) angularDistance += magnitude * dt
                    }
                    peakAngularVelocity = maxOf(peakAngularVelocity, magnitude)
                    lastGyroTimestamp = event.timestamp
                }

                Sensor.TYPE_LINEAR_ACCELERATION, Sensor.TYPE_ACCELEROMETER -> {
                    val x = event.values[0]
                    val y = event.values[1]
                    val z = event.values[2]
                    val magnitude = sqrt(x * x + y * y + z * z)
                    // U fallbacku TYPE_ACCELEROMETER odečteme přibližnou gravitaci.
                    val linearMagnitude = if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                        abs(magnitude - SensorManager.GRAVITY_EARTH)
                    } else magnitude
                    if (lastAccelerationTimestamp != 0L) {
                        val dt = (event.timestamp - lastAccelerationTimestamp) / 1_000_000_000f
                        if (dt in 0f..0.25f) accelerationImpulse += linearMagnitude * dt
                    }
                    lastAccelerationTimestamp = event.timestamp
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun resetFrameLocked() {
        frameActive = false
        lastGyroTimestamp = 0L
        angularDistance = 0f
        peakAngularVelocity = 0f
        accelerationImpulse = 0f
        lastAccelerationTimestamp = 0L
    }
}
