package cz.hqsnet.aifoto.lens

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.os.Build
import android.util.SizeF
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import kotlin.math.abs
import kotlin.math.hypot

/** Načte skutečné moduly, které Android zpřístupnil aplikaci. */
@OptIn(ExperimentalCamera2Interop::class)
object LensCatalog {

    fun discover(context: Context, provider: ProcessCameraProvider): LensCatalogState {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val backInfos = runCatching {
            CameraSelector.DEFAULT_BACK_CAMERA.filter(provider.availableCameraInfos)
        }.getOrDefault(emptyList())
        val defaultInfo = backInfos.firstOrNull()
            ?: return LensCatalogState(discoveryWarning = "CameraX nenašel zadní fotoaparát.")
        val logicalId = runCatching { Camera2CameraInfo.from(defaultInfo).cameraId }.getOrNull()
            ?: return LensCatalogState(discoveryWarning = "Camera2 neposkytlo ID zadní kamery.")
        val logicalChars = runCatching { manager.getCameraCharacteristics(logicalId) }.getOrNull()
            ?: return LensCatalogState(
                logicalCameraId = logicalId,
                discoveryWarning = "Nelze přečíst vlastnosti zadní kamery $logicalId."
            )

        val physicalIds = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            runCatching { logicalChars.physicalCameraIds }.getOrDefault(emptySet())
        } else {
            emptySet()
        }

        val rawEntries = mutableListOf<RawLens>()
        if (physicalIds.isNotEmpty()) {
            physicalIds.forEach { physicalId ->
                val chars = runCatching { manager.getCameraCharacteristics(physicalId) }.getOrNull()
                    ?: return@forEach
                if (!isPhotographicLens(chars)) return@forEach
                rawEntries += RawLens(
                    selectorCameraId = logicalId,
                    physicalCameraId = physicalId,
                    characteristics = chars,
                    logicalMultiCamera = true
                )
            }
        }

        // Některé OEM fyzická ID schovají, ale samostatné zadní kamery CameraX
        // přesto zveřejní. V tom případě je nabídneme jako samostatná zařízení.
        if (rawEntries.isEmpty()) {
            backInfos.forEach { info ->
                val cameraId = runCatching { Camera2CameraInfo.from(info).cameraId }.getOrNull()
                    ?: return@forEach
                val chars = runCatching { manager.getCameraCharacteristics(cameraId) }.getOrNull()
                    ?: return@forEach
                if (!isPhotographicLens(chars)) return@forEach
                rawEntries += RawLens(
                    selectorCameraId = cameraId,
                    physicalCameraId = null,
                    characteristics = chars,
                    logicalMultiCamera = false
                )
            }
        }

        if (rawEntries.isEmpty()) {
            rawEntries += RawLens(
                selectorCameraId = logicalId,
                physicalCameraId = null,
                characteristics = logicalChars,
                logicalMultiCamera = physicalIds.isNotEmpty()
            )
        }

        val mainRaw = chooseMain(rawEntries)
        val mainScale = mainRaw.equivalent35Mm ?: mainRaw.focalLengthMm.coerceAtLeast(0.1f)
        val profiles = rawEntries.map { raw ->
            val scale = raw.equivalent35Mm ?: raw.focalLengthMm.coerceAtLeast(0.1f)
            val rawZoom = (scale / mainScale).coerceAtLeast(0.1f)
            val zoom = snapZoom(rawZoom)
            val role = roleFor(zoom)
            val chars = raw.characteristics
            val activeArray = chars.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
            val capabilities = chars.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?: intArrayOf()
            val oisModes = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)
                ?: intArrayOf()
            val aperture = chars.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)
                ?.minOrNull()
            val sensorSize = chars.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            LensProfile(
                id = if (raw.physicalCameraId != null) {
                    "${raw.selectorCameraId}:${raw.physicalCameraId}"
                } else {
                    "camera:${raw.selectorCameraId}"
                },
                selectorCameraId = raw.selectorCameraId,
                physicalCameraId = raw.physicalCameraId,
                role = role,
                displayName = displayName(zoom, role),
                shortLabel = formatZoom(zoom),
                equivalentZoom = zoom,
                focalLengthMm = raw.focalLengthMm,
                equivalentFocalLength35Mm = raw.equivalent35Mm,
                aperture = aperture,
                sensorWidthMm = sensorSize?.width,
                sensorHeightMm = sensorSize?.height,
                minFocusDistanceDiopters = chars.get(
                    CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE
                ),
                opticalStabilization = oisModes.contains(
                    CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON
                ),
                rawSupported = capabilities.contains(
                    CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW
                ),
                activeArrayWidth = activeArray?.width() ?: 0,
                activeArrayHeight = activeArray?.height() ?: 0,
                maxDigitalZoom = chars.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
                    ?: 1f,
                logicalMultiCamera = raw.logicalMultiCamera
            )
        }.distinctBy { it.id }.sortedBy { it.equivalentZoom }

        val mainProfile = profiles.minByOrNull { abs(it.equivalentZoom - 1f) }
        return LensCatalogState(
            logicalCameraId = logicalId,
            profiles = profiles,
            mainLensId = mainProfile?.id,
            logicalMultiCamera = physicalIds.isNotEmpty(),
            discoveryWarning = when {
                physicalIds.isNotEmpty() -> null
                profiles.size > 1 -> "OEM nezpřístupnil fyzická ID; moduly se volí jako samostatné kamery."
                else -> "OEM nezpřístupnil samostatné fyzické objektivy. Volbu modulu může řídit firmware."
            }
        )
    }

    @OptIn(ExperimentalCamera2Interop::class)
    fun selectorFor(profile: LensProfile?): CameraSelector {
        if (profile == null) return CameraSelector.DEFAULT_BACK_CAMERA
        val builder = CameraSelector.Builder()
            .requireLensFacing(CameraSelector.LENS_FACING_BACK)
            .addCameraFilter { infos ->
                infos.filter { info -> cameraId(info) == profile.selectorCameraId }
            }
        profile.physicalCameraId?.let { builder.setPhysicalCameraId(it) }
        return builder.build()
    }

    @OptIn(ExperimentalCamera2Interop::class)
    private fun cameraId(info: CameraInfo): String? =
        runCatching { Camera2CameraInfo.from(info).cameraId }.getOrNull()

    /** Odstraní hloubkové/servisní senzory, které neumí běžný barevný výstup. */
    private fun isPhotographicLens(characteristics: CameraCharacteristics): Boolean {
        val focal = characteristics
            .get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            ?.any { it > 0f } == true
        val active = characteristics.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        val hasImageArea = active != null && active.width() > 0 && active.height() > 0
        val capabilities = characteristics
            .get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?: intArrayOf()
        val depthOnly = capabilities.contains(
            CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT
        ) && !capabilities.contains(
            CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE
        ) && !capabilities.contains(
            CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW
        )
        return focal && hasImageArea && !depthOnly
    }

    private fun chooseMain(entries: List<RawLens>): RawLens {
        val withEquivalent = entries.filter { it.equivalent35Mm != null }
        if (withEquivalent.isNotEmpty()) {
            return withEquivalent.minByOrNull { abs((it.equivalent35Mm ?: 24f) - 24f) }
                ?: entries.first()
        }
        val sorted = entries.sortedBy { it.focalLengthMm }
        return when {
            sorted.size >= 3 -> sorted[1]
            else -> sorted.minByOrNull { abs(it.focalLengthMm - 5f) } ?: entries.first()
        }
    }

    private fun roleFor(zoom: Float): LensRole = when {
        zoom < 0.8f -> LensRole.ULTRA_WIDE
        zoom < 1.6f -> LensRole.WIDE
        zoom < 5.5f -> LensRole.TELEPHOTO
        else -> LensRole.SUPER_TELEPHOTO
    }

    private fun snapZoom(value: Float): Float {
        val familiar = floatArrayOf(0.5f, 0.6f, 1f, 2f, 3f, 5f, 10f)
        val closest = familiar.minByOrNull { abs(it - value) } ?: value
        return if (abs(closest - value) / value.coerceAtLeast(0.1f) <= 0.24f) {
            closest
        } else {
            (value * 10f).toInt() / 10f
        }
    }

    private fun displayName(zoom: Float, role: LensRole): String = when (role) {
        LensRole.ULTRA_WIDE -> "${formatZoom(zoom)} ultraširoký"
        LensRole.WIDE -> "${formatZoom(zoom)} hlavní"
        LensRole.TELEPHOTO -> "${formatZoom(zoom)} tele"
        LensRole.SUPER_TELEPHOTO -> "${formatZoom(zoom)} supertele"
        LensRole.UNKNOWN -> "${formatZoom(zoom)} objektiv"
    }

    private fun formatZoom(zoom: Float): String = if (abs(zoom - zoom.toInt()) < 0.04f) {
        "${zoom.toInt()}×"
    } else {
        "${"%.1f".format(java.util.Locale.US, zoom).replace('.', ',')}×"
    }

    private data class RawLens(
        val selectorCameraId: String,
        val physicalCameraId: String?,
        val characteristics: CameraCharacteristics,
        val logicalMultiCamera: Boolean
    ) {
        val focalLengthMm: Float = characteristics
            .get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            ?.minOrNull()
            ?: 1f
        val equivalent35Mm: Float? = calculateEquivalent35(
            focalLengthMm,
            characteristics.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        )
    }

    private fun calculateEquivalent35(focalMm: Float, sensorSize: SizeF?): Float? {
        sensorSize ?: return null
        val diagonal = hypot(sensorSize.width.toDouble(), sensorSize.height.toDouble()).toFloat()
        if (diagonal <= 0f) return null
        return focalMm * FULL_FRAME_DIAGONAL_MM / diagonal
    }

    private const val FULL_FRAME_DIAGONAL_MM = 43.266f
}
