package cz.hqsnet.aifoto.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import cz.hqsnet.aifoto.CameraCapabilities
import cz.hqsnet.aifoto.CameraEvent
import cz.hqsnet.aifoto.CameraUiState
import cz.hqsnet.aifoto.CameraViewModel
import cz.hqsnet.aifoto.FlashMode
import cz.hqsnet.aifoto.capture.ExposureControlState
import cz.hqsnet.aifoto.capture.NightCaptureMode
import cz.hqsnet.aifoto.coach.CoachCategory
import cz.hqsnet.aifoto.coach.CoachCue
import cz.hqsnet.aifoto.coach.CoachDirection
import cz.hqsnet.aifoto.coach.CoachMode
import cz.hqsnet.aifoto.coach.CoachSeverity
import cz.hqsnet.aifoto.coach.DevicePose
import cz.hqsnet.aifoto.coach.DevicePoseEstimator
import cz.hqsnet.aifoto.lens.LensBindingState
import cz.hqsnet.aifoto.lens.LensProfile
import cz.hqsnet.aifoto.lens.OemExtensionMode
import cz.hqsnet.aifoto.model.FrameMetrics
import cz.hqsnet.aifoto.model.SceneAdvice
import cz.hqsnet.aifoto.model.SceneKind
import java.util.Locale
import kotlin.math.abs

private val PanelColor = Color(0xCC071014)
private val FineLine = Color.White.copy(alpha = 0.38f)

@Composable
fun CameraScreen(viewModel: CameraViewModel) {
    val advice by viewModel.advice.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            val message = when (event) {
                is CameraEvent.Message -> event.text
                is CameraEvent.PhotoSaved -> event.text
            }
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        containerColor = Color.Black,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .padding(innerPadding)
        ) {
            CameraPreview(
                viewModel = viewModel,
                modifier = Modifier.fillMaxSize()
            ) { previewView ->
                CameraOverlay(
                    previewView = previewView,
                    viewModel = viewModel,
                    advice = advice,
                    uiState = uiState
                )
            }
        }
    }
}

@Composable
private fun CameraOverlay(
    previewView: PreviewView,
    viewModel: CameraViewModel,
    advice: SceneAdvice,
    uiState: CameraUiState
) {
    val pose = rememberDevicePose()
    LaunchedEffect(pose) { viewModel.onDevicePose(pose) }
    val coach = uiState.coachState

    Box(Modifier.fillMaxSize()) {
        if (coach.mode != CoachMode.SIMPLE) RuleOfThirdsGrid()
        if (coach.mode == CoachMode.PRO) ClippingOverlay(advice)
        FocusReticle(uiState)
        CoachTargetOverlay(coach.cue, coach.mode)
        if (coach.mode != CoachMode.SIMPLE || coach.cue.category == CoachCategory.LEVEL) {
            LevelIndicator(pose.levelErrorDegrees)
        }

        TopControls(
            advice = advice,
            uiState = uiState,
            onDiagnostics = viewModel::toggleDiagnostics,
            onCoachMode = viewModel::cycleCoachMode,
            flashMode = uiState.flashMode,
            onFlash = viewModel::cycleFlash,
            torchOn = uiState.torchOn,
            torchAvailable = uiState.torchAvailable,
            onTorch = viewModel::toggleTorch,
            rawEnabled = uiState.rawEnabled,
            rawSupported = uiState.rawSupported,
            onRaw = viewModel::toggleRaw,
            selfTimerSeconds = uiState.selfTimerSeconds,
            onSelfTimer = viewModel::cycleSelfTimer,
            onOem = viewModel::cycleOemExtension,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        )

        if (!uiState.diagnosticsVisible) {
            CoachCueBanner(
                cue = coach.cue,
                mode = coach.mode,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(
                        top = if (coach.mode == CoachMode.SIMPLE) 68.dp else 148.dp,
                        start = 14.dp,
                        end = 14.dp
                    )
            )
        }

        CountdownOverlay(uiState.countdownRemaining)

        BottomControls(
            advice = advice,
            uiState = uiState,
            onLens = viewModel::selectLens,
            onApply = viewModel::applyCurrentAdvice,
            onCapture = { viewModel.takePhoto(previewView.context) },
            onNightMode = viewModel::cycleNightMode,
            onNightStack = viewModel::startNightStack,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun TopControls(
    advice: SceneAdvice,
    uiState: CameraUiState,
    onDiagnostics: () -> Unit,
    onCoachMode: () -> Unit,
    flashMode: FlashMode,
    onFlash: () -> Unit,
    torchOn: Boolean,
    torchAvailable: Boolean,
    onTorch: () -> Unit,
    rawEnabled: Boolean,
    rawSupported: Boolean,
    onRaw: () -> Unit,
    selfTimerSeconds: Int,
    onSelfTimer: () -> Unit,
    onOem: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // AI otevře technickou diagnostiku; sousední čip mění množství
                // informací v hledáčku, takže jednoduchý režim zůstane opravdu čistý.
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (uiState.diagnosticsVisible) Color.White
                            else MaterialTheme.colorScheme.primary
                        )
                        .clickable(onClick = onDiagnostics),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "AI",
                        color = if (uiState.diagnosticsVisible) Color.Black
                        else MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }
                CoachModeChip(uiState.coachState.mode, onCoachMode)
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (uiState.extensionAvailability.any) {
                    val requestedOem = uiState.requestedExtensionMode
                    CircleToggle(
                        label = if (requestedOem == OemExtensionMode.NONE) {
                            "OEM"
                        } else {
                            requestedOem.shortLabel
                        },
                        active = requestedOem != OemExtensionMode.NONE,
                        onClick = onOem
                    )
                }
                CircleToggle(
                    label = if (selfTimerSeconds > 0) "$selfTimerSeconds" else "⏱",
                    active = selfTimerSeconds > 0,
                    onClick = onSelfTimer
                )
                if (rawSupported) {
                    CircleToggle(label = "RAW", active = rawEnabled, onClick = onRaw)
                }
                if (torchAvailable) {
                    CircleToggle(label = "☀", active = torchOn, onClick = onTorch)
                }
                CircleToggle(
                    label = flashMode.shortLabel,
                    active = flashMode != FlashMode.OFF,
                    onClick = onFlash
                )
            }
        }

        if (uiState.coachState.mode != CoachMode.SIMPLE) {
            Spacer(Modifier.height(8.dp))
            Surface(
                color = PanelColor,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = advice.scene.displayName,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "${(advice.confidence * 100).toInt()} %",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Text(
                            text = if (uiState.coachState.mode == CoachMode.PRO) advice.mainTip else advice.secondaryTip,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = Color.White.copy(alpha = 0.78f),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                    if (uiState.coachState.mode == CoachMode.PRO) {
                        Spacer(Modifier.width(10.dp))
                        MiniHistogram(advice.metrics)
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = uiState.diagnosticsVisible && uiState.coachState.mode == CoachMode.PRO,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            DiagnosticsPanel(uiState)
        }
    }
}


@Composable
private fun CoachModeChip(mode: CoachMode, onClick: () -> Unit) {
    Surface(
        color = when (mode) {
            CoachMode.SIMPLE -> Color.White.copy(alpha = 0.12f)
            CoachMode.COACH -> MaterialTheme.colorScheme.primary.copy(alpha = 0.26f)
            CoachMode.PRO -> Color(0xFFFFC107).copy(alpha = 0.22f)
        },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = mode.shortLabel,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            color = when (mode) {
                CoachMode.SIMPLE -> Color.White
                CoachMode.COACH -> MaterialTheme.colorScheme.primary
                CoachMode.PRO -> Color(0xFFFFC107)
            },
            fontWeight = FontWeight.ExtraBold,
            fontSize = 9.sp,
            letterSpacing = 0.45.sp
        )
    }
}

@Composable
private fun CoachCueBanner(
    cue: CoachCue,
    mode: CoachMode,
    modifier: Modifier = Modifier
) {
    val color = coachColor(cue.severity)
    Surface(
        color = Color(0xDA071014),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 13.dp, vertical = if (mode == CoachMode.SIMPLE) 9.dp else 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(if (mode == CoachMode.SIMPLE) 34.dp else 40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.18f))
                    .border(1.5.dp, color.copy(alpha = 0.9f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = coachDirectionSymbol(cue),
                    color = color,
                    fontWeight = FontWeight.Black,
                    fontSize = if (cue.direction == CoachDirection.NONE) 16.sp else 20.sp
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = cue.title,
                    color = color,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = if (mode == CoachMode.SIMPLE) 13.sp else 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (mode != CoachMode.SIMPLE) {
                    Text(
                        text = cue.detail,
                        color = Color.White.copy(alpha = 0.76f),
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            ScoreBadge(cue.score, cue.severity == CoachSeverity.READY)
        }
    }
}

@Composable
private fun ScoreBadge(score: Int, ready: Boolean) {
    val color = if (ready) Color(0xFF72E6A5) else MaterialTheme.colorScheme.primary
    Surface(
        color = color.copy(alpha = 0.16f),
        shape = CircleShape,
        modifier = Modifier.size(38.dp)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = score.coerceIn(0, 100).toString(),
                color = color,
                fontWeight = FontWeight.Black,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun CoachTargetOverlay(cue: CoachCue, mode: CoachMode) {
    if (mode == CoachMode.SIMPLE) return
    val targetX = cue.targetX ?: return
    val targetY = cue.targetY ?: return
    val color = coachColor(cue.severity)
    Canvas(modifier = Modifier.fillMaxSize()) {
        val content = fourThreeContentRect(size)
        val center = Offset(
            content.left + content.width * targetX.coerceIn(0f, 1f),
            content.top + content.height * targetY.coerceIn(0f, 1f)
        )
        val radius = if (cue.severity == CoachSeverity.READY) 22.dp.toPx() else 17.dp.toPx()
        drawCircle(
            color = color.copy(alpha = 0.78f),
            radius = radius,
            center = center,
            style = Stroke(width = 1.7.dp.toPx())
        )
        drawLine(
            color = color.copy(alpha = 0.72f),
            start = Offset(center.x - radius - 7.dp.toPx(), center.y),
            end = Offset(center.x - radius + 4.dp.toPx(), center.y),
            strokeWidth = 1.5.dp.toPx()
        )
        drawLine(
            color = color.copy(alpha = 0.72f),
            start = Offset(center.x + radius - 4.dp.toPx(), center.y),
            end = Offset(center.x + radius + 7.dp.toPx(), center.y),
            strokeWidth = 1.5.dp.toPx()
        )
    }
}

private fun coachDirectionSymbol(cue: CoachCue): String = when {
    cue.severity == CoachSeverity.READY -> "✓"
    cue.direction == CoachDirection.LEFT -> "←"
    cue.direction == CoachDirection.RIGHT -> "→"
    cue.direction == CoachDirection.UP -> "↑"
    cue.direction == CoachDirection.DOWN -> "↓"
    cue.direction == CoachDirection.CLOSER -> "+"
    cue.direction == CoachDirection.FARTHER -> "−"
    cue.direction == CoachDirection.HOLD -> "●"
    cue.direction == CoachDirection.LEVEL -> "—"
    else -> "AI"
}

private fun coachColor(severity: CoachSeverity): Color = when (severity) {
    CoachSeverity.READY -> Color(0xFF72E6A5)
    CoachSeverity.INFO -> Color(0xFF67D4FF)
    CoachSeverity.WARNING -> Color(0xFFFFC107)
    CoachSeverity.URGENT -> Color(0xFFFF6B6B)
}

@Composable
private fun DiagnosticsPanel(uiState: CameraUiState) {
    val telemetry = uiState.captureTelemetry
    val capabilities = uiState.capabilities
    Surface(
        color = Color(0xE6111B20),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 7.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SKUTEČNÝ CAPTURE RESULT",
                    color = exposureStateColor(uiState.exposureControlState),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.sp,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = exposureStateLabel(uiState.exposureControlState),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Čas ${formatActualExposure(telemetry.exposureNanos)}  ·  " +
                    "ISO ${telemetry.iso ?: "—"}  ·  " +
                    "AE ${telemetry.aeMode ?: "—"}  ·  " +
                    "AF ${telemetry.afMode ?: "—"}",
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 11.sp
            )
            Text(
                text = "Objektiv ${uiState.lensTruth.activeLabel} · " +
                    "stav ${lensBindingLabel(uiState.lensTruth.bindingState)} · " +
                    "f ${uiState.lensTruth.focalLengthMm?.let { "%.2f mm".format(Locale.US, it) } ?: "—"}",
                color = if (uiState.lensTruth.verified) {
                    Color(0xFF78E08F)
                } else {
                    Color.White.copy(alpha = 0.78f)
                },
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
            Text(
                text = "Fyzické ID ${uiState.lensTruth.activePhysicalCameraId ?: "—"} · " +
                    "optika ${formatZoom(uiState.lensTruth.opticalBaseZoom)} · " +
                    "crop ${formatZoom(uiState.lensTruth.digitalCropFactor)} · " +
                    "OEM ${uiState.activeExtensionMode.displayName}",
                color = Color.White.copy(alpha = 0.62f),
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
            if (uiState.lensCatalog.profiles.isNotEmpty()) {
                Text(
                    text = "Nalezeno: ${lensCatalogLine(uiState.lensCatalog.profiles)}",
                    color = Color.White.copy(alpha = 0.56f),
                    fontSize = 9.sp,
                    lineHeight = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            uiState.lensCatalog.discoveryWarning?.let { warning ->
                Text(
                    text = warning,
                    color = Color(0xFFFFC107),
                    fontSize = 9.sp,
                    lineHeight = 13.sp
                )
            }
            Text(
                text = capabilityLine(capabilities),
                color = Color.White.copy(alpha = 0.62f),
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
            if (uiState.stacking || uiState.nightAcceptedFrames > 0 || uiState.nightRejectedFrames > 0) {
                Text(
                    text = "Noc ${uiState.nightActiveMode?.displayName ?: uiState.nightModePreference.displayName} · " +
                        "přijato ${uiState.nightAcceptedFrames}/${uiState.nightTargetFrames} · " +
                        "odmítnuto ${uiState.nightRejectedFrames}",
                    color = Color(0xFFFFC107),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text = "AI Coach: ${uiState.coachState.cue.title} · skóre ${uiState.coachState.compositionScore}/100 · " +
                    "tváře ${uiState.coachState.faceCount} · rovina ${"%.1f".format(abs(uiState.coachState.pose.levelErrorDegrees))}°",
                color = coachColor(uiState.coachState.cue.severity),
                fontSize = 10.sp,
                lineHeight = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            uiState.coachState.lastCapturedCue?.let { captured ->
                Text(
                    text = "Poslední snímek: ${captured.title}. ${captured.rationale}",
                    color = Color.White.copy(alpha = 0.58f),
                    fontSize = 9.sp,
                    lineHeight = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            val requestedExposure = uiState.requestedExposureNanos
            val requestedIso = uiState.requestedIso
            if (requestedExposure != null || requestedIso != null) {
                Text(
                    text = "Požadováno: ${formatActualExposure(requestedExposure)} · " +
                        "ISO ${requestedIso ?: "—"}",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun BottomControls(
    advice: SceneAdvice,
    uiState: CameraUiState,
    onLens: (String) -> Unit,
    onApply: () -> Unit,
    onCapture: () -> Unit,
    onNightMode: () -> Unit,
    onNightStack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LensStrip(
            profiles = uiState.lensCatalog.profiles,
            requestedLensId = uiState.requestedLensId,
            activeLensId = uiState.lensTruth.activeLensId,
            recommendedLensId = uiState.lensRecommendation.lensId,
            enabled = uiState.cameraReady && !uiState.isSaving && !uiState.stacking,
            onLens = onLens
        )
        Spacer(Modifier.height(8.dp))

        Surface(
            color = PanelColor,
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                when (uiState.coachState.mode) {
                    CoachMode.SIMPLE -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = uiState.coachState.cue.title,
                                    color = coachColor(uiState.coachState.cue.severity),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = uiState.lensTruth.activeLabel,
                                    color = Color.White.copy(alpha = 0.62f),
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            ScoreBadge(uiState.coachState.compositionScore, uiState.coachState.ready)
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    CoachMode.COACH -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SettingValue(
                                "OBJEKTIV",
                                uiState.lensTruth.activeLabel,
                                Modifier.weight(1.5f)
                            )
                            SettingValue(
                                "ČAS",
                                formatActualExposure(uiState.captureTelemetry.exposureNanos),
                                Modifier.weight(0.75f)
                            )
                        }
                        Spacer(Modifier.height(5.dp))
                        Text(
                            text = "Smart Lens: ${uiState.lensRecommendation.displayLabel}. " +
                                uiState.lensRecommendation.reason,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(8.dp))
                    }

                    CoachMode.PRO -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Čas a ISO jsou přímo z CaptureResult. Doporučení je
                            // uvedené zvlášť, takže UI nepředstírá požadovanou hodnotu.
                            SettingValue(
                                "OBJEKTIV",
                                uiState.lensTruth.activeLabel,
                                Modifier.weight(1.45f)
                            )
                            SettingValue(
                                "ZOOM",
                                formatZoom(uiState.lensTruth.effectiveZoom),
                                Modifier.weight(0.72f)
                            )
                            SettingValue(
                                "ČAS",
                                formatActualExposure(uiState.captureTelemetry.exposureNanos),
                                Modifier.weight(0.9f)
                            )
                            SettingValue(
                                "ISO",
                                uiState.captureTelemetry.iso?.toString() ?: "—",
                                Modifier.weight(0.65f)
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Smart Lens: ${uiState.lensRecommendation.displayLabel}. " +
                                uiState.lensRecommendation.reason,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        uiState.lensRecommendation.warning?.let { warning ->
                            Text(
                                text = warning,
                                color = Color(0xFFFFC107),
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )
                        }
                        Text(
                            text = "Expozice: ${advice.shutter} · ISO ${advice.iso} · " +
                                "EV ${formatEv(advice.exposureCompensation)}.",
                            color = Color.White.copy(alpha = 0.58f),
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (uiState.coachState.mode == CoachMode.SIMPLE) "NOČNÍ REŽIM" else "COMPUTATIONAL NIGHT",
                            color = Color(0xFFFFC107),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 9.sp,
                            letterSpacing = 0.55.sp
                        )
                        if (uiState.coachState.mode != CoachMode.SIMPLE) {
                            Text(
                                text = uiState.nightStatus,
                                color = Color.White.copy(alpha = 0.68f),
                                fontSize = 10.sp,
                                lineHeight = 13.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else {
                            Text(
                                text = if (uiState.stackingAvailable) "Připraven" else "V této session nedostupný",
                                color = Color.White.copy(alpha = 0.58f),
                                fontSize = 10.sp
                            )
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    NightModeChip(
                        preferenceLabel = uiState.nightModePreference.shortLabel,
                        activeMode = uiState.nightActiveMode.takeIf { uiState.stacking },
                        enabled = uiState.stackingAvailable && !uiState.stacking && !uiState.isSaving,
                        onClick = onNightMode
                    )
                }
                Spacer(Modifier.height(12.dp))

                // Spoušť patří doprostřed a musí být největší - ruka ji najde
                // bez dívání. Vedlejší akce jsou po stranách a menší, aby
                // s ní nesoupeřily o pozornost.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        ApplyButton(
                            enabled = uiState.cameraReady && !uiState.isSaving && !uiState.stacking,
                            onClick = onApply
                        )
                    }

                    ShutterButton(
                        saving = uiState.isSaving,
                        enabled = uiState.cameraReady && !uiState.stacking,
                        onClick = onCapture
                    )

                    Box(
                        modifier = Modifier.weight(1f),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        NightStackButton(
                            stacking = uiState.stacking,
                            progress = uiState.stackProgress,
                            enabled = uiState.cameraReady &&
                                uiState.stackingAvailable &&
                                !uiState.isSaving,
                            // Když aplikace scénu vyhodnotí jako noční,
                            // tlačítko se zvýrazní - jinak by uživatel nevěděl,
                            // že se tu hodí.
                            suggested = uiState.stackingAvailable &&
                                !uiState.stacking &&
                                advice.scene == SceneKind.NIGHT,
                            onClick = onNightStack
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LensStrip(
    profiles: List<LensProfile>,
    requestedLensId: String?,
    activeLensId: String?,
    recommendedLensId: String?,
    enabled: Boolean,
    onLens: (String) -> Unit
) {
    if (profiles.isEmpty()) return
    Surface(
        color = PanelColor,
        shape = RoundedCornerShape(24.dp)
    ) {
        Row(
            modifier = Modifier.padding(5.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            profiles.take(5).forEach { profile ->
                val selected = requestedLensId == profile.id ||
                    (requestedLensId == null && activeLensId == profile.id)
                val recommended = recommendedLensId == profile.id
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .then(
                            if (recommended && !selected) {
                                Modifier.border(
                                    1.5.dp,
                                    MaterialTheme.colorScheme.primary,
                                    CircleShape
                                )
                            } else {
                                Modifier
                            }
                        )
                        .clip(CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else Color.Transparent
                        )
                        .alpha(if (enabled) 1f else 0.45f)
                        .clickable(enabled = enabled) { onLens(profile.id) },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = profile.shortLabel,
                            color = if (selected) {
                                MaterialTheme.colorScheme.onPrimary
                            } else {
                                Color.White
                            },
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp
                        )
                        if (recommended && !selected) {
                            Text(
                                text = "AI",
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Black,
                                fontSize = 7.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingValue(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    /** Hodnota, kterou aplikace jen doporučuje a sama ji nenastaví. */
    advisory: Boolean = false
) {
    Column(modifier = modifier.padding(end = 5.dp)) {
        Text(
            text = if (advisory) "$label ~" else label,
            color = if (advisory) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
            } else {
                MaterialTheme.colorScheme.primary
            },
            fontWeight = FontWeight.ExtraBold,
            fontSize = 9.sp,
            letterSpacing = 0.6.sp
        )
        Text(
            text = value,
            color = if (advisory) Color.White.copy(alpha = 0.65f) else Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 13.sp
        )
    }
}

@Composable
private fun ShutterButton(saving: Boolean, enabled: Boolean, onClick: () -> Unit) {
    // Hlavní akce obrazovky - největší cíl, aby ji palec našel bez dívání.
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .border(3.dp, Color.White.copy(alpha = if (enabled) 0.95f else 0.35f), CircleShape)
            .padding(5.dp)
            .clip(CircleShape)
            .background(if (enabled) Color.White else Color.White.copy(alpha = 0.25f))
            .clickable(enabled = enabled && !saving, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (saving) {
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                strokeWidth = 3.dp,
                color = Color.Black
            )
        }
    }
}

@Composable
private fun NightModeChip(
    preferenceLabel: String,
    activeMode: NightCaptureMode?,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val label = activeMode?.let {
        when (it) {
            NightCaptureMode.HANDHELD -> "RUKA"
            NightCaptureMode.TRIPOD -> "STAT"
            NightCaptureMode.PORTRAIT -> "POR"
        }
    } ?: preferenceLabel
    Surface(
        color = if (activeMode != null) {
            Color(0xFFFFC107).copy(alpha = 0.22f)
        } else {
            Color.White.copy(alpha = 0.09f)
        },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .alpha(if (enabled || activeMode != null) 1f else 0.45f)
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp),
            color = Color(0xFFFFC107),
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

/**
 * Výpočetní noční režim - zarovná expozice, odmítne chvění a potlačí duchy.
 * Během snímání kreslí kolem tlačítka postup.
 */
@Composable
private fun NightStackButton(
    stacking: Boolean,
    progress: Float,
    enabled: Boolean,
    suggested: Boolean,
    onClick: () -> Unit
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        label = "stackProgress"
    )

    val nightColor = Color(0xFFFFC107)
    val showPulse = suggested && !stacking

    val tint = when {
        stacking -> MaterialTheme.colorScheme.primary
        suggested -> nightColor
        enabled -> Color.White.copy(alpha = 0.9f)
        else -> Color.White.copy(alpha = 0.3f)
    }
    val background = if (showPulse) {
        nightColor.copy(alpha = 0.18f)
    } else {
        Color.Black.copy(alpha = 0.35f)
    }

    Box(
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(enabled = enabled && !stacking, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        // Pulzující prstenec jen když se noční režim nabízí. Animace se
        // spouští až uvnitř téhle větve - kdyby běžela pořád, překreslovala
        // by obrazovku nad živým náhledem i ve chvílích, kdy není co ukázat.
        if (showPulse) {
            PulsingRing(color = nightColor)
        }
        if (stacking) {
            Canvas(modifier = Modifier.size(46.dp)) {
                val stroke = 3.dp.toPx()
                val diameter = size.minDimension - stroke
                val topLeft = Offset(
                    (size.width - diameter) / 2f,
                    (size.height - diameter) / 2f
                )
                drawArc(
                    color = Color.White.copy(alpha = 0.22f),
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(diameter, diameter),
                    style = Stroke(width = stroke)
                )
                drawArc(
                    color = Color(0xFFFFC107),
                    startAngle = -90f,
                    sweepAngle = 360f * animatedProgress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(diameter, diameter),
                    style = Stroke(width = stroke)
                )
            }
        }
        Text(
            text = "NOC",
            color = tint,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
private fun ApplyButton(enabled: Boolean, onClick: () -> Unit) {
    // Popisek říká jen to, co se opravdu nastaví - čas a ISO fotoaparát
    // na této cestě snímání nepřevezme, takže je slibovat nemůžeme.
    Surface(
        color = if (enabled) MaterialTheme.colorScheme.primary else PanelColor,
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.clickable(enabled = enabled, onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "POUŽÍT",
                color = if (enabled) {
                    MaterialTheme.colorScheme.onPrimary
                } else {
                    Color.White.copy(alpha = 0.4f)
                },
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "objektiv · EV · OEM",
                color = if (enabled) {
                    MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.75f)
                } else {
                    Color.White.copy(alpha = 0.3f)
                },
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun CircleToggle(
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    // Jednotný tvar i velikost pro všechny přepínače v horní liště. Kruh
    // o průměru 40 dp drží horní lištu kompaktní i se zapnutým RAW a OEM.
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (active) MaterialTheme.colorScheme.primary else PanelColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (active) MaterialTheme.colorScheme.onPrimary else Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun PulsingRing(color: Color) {
    val infinite = rememberInfiniteTransition(label = "nightPulse")
    val pulse by infinite.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "nightPulseAlpha"
    )
    Canvas(modifier = Modifier.size(52.dp)) {
        val stroke = 2.dp.toPx()
        val diameter = size.minDimension - stroke
        drawArc(
            color = color.copy(alpha = pulse),
            startAngle = 0f,
            sweepAngle = 360f,
            useCenter = false,
            topLeft = Offset(
                (size.width - diameter) / 2f,
                (size.height - diameter) / 2f
            ),
            size = Size(diameter, diameter),
            style = Stroke(width = stroke)
        )
    }
}

@Composable
private fun ClippingOverlay(advice: SceneAdvice) {
    val metrics = advice.metrics
    val mask = metrics.clipMask
    val cols = metrics.clipMaskWidth
    val rows = metrics.clipMaskHeight
    if (mask.isEmpty() || cols <= 0 || rows <= 0) return
    // Maska musí velikostí odpovídat mřížce; při nesouladu by se sahalo
    // mimo pole. Radši nekreslíme nic, než abychom shodili aplikaci.
    if (mask.size != cols * rows) return

    // U nočních scén jsou vypálené pouliční lampy nevyhnutelné a
    // zvýrazňovat je pokaždé by jen rušilo. Za denního světla je ale
    // stejný podíl přepalu problém, který stojí za upozornění.
    val threshold = if (advice.scene == SceneKind.NIGHT) {
        NIGHT_CLIPPING_RATIO
    } else {
        DAY_CLIPPING_RATIO
    }
    if (metrics.highlightRatio < threshold) return

    Canvas(modifier = Modifier.fillMaxSize()) {
        val content = fourThreeContentRect(size)
        val cellW = content.width / cols
        val cellH = content.height / rows
        for (row in 0 until rows) {
            for (col in 0 until cols) {
                if (!mask[row * cols + col]) continue
                drawRect(
                    color = Color.Red.copy(alpha = 0.30f),
                    topLeft = Offset(
                        content.left + col * cellW,
                        content.top + row * cellH
                    ),
                    size = Size(cellW, cellH)
                )
            }
        }
    }
}

/** Za dne znamená i malý přepal ztracený detail. */
private const val DAY_CLIPPING_RATIO = 0.01f

/** V noci jsou vypálená světla běžná, upozorňujeme až na větší plochu. */
private const val NIGHT_CLIPPING_RATIO = 0.06f

@Composable
private fun CountdownOverlay(remaining: Int) {
    // Odpočet je přes celou plochu, aby byl vidět i když uživatel telefon
    // odloží nebo opře - právě proto samospoušť používá.
    AnimatedVisibility(
        visible = remaining > 0,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.25f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = remaining.toString(),
                color = Color.White,
                fontSize = 96.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}

@Composable
private fun RuleOfThirdsGrid() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val content = fourThreeContentRect(size)
        val x1 = content.left + content.width / 3f
        val x2 = content.left + content.width * 2f / 3f
        val y1 = content.top + content.height / 3f
        val y2 = content.top + content.height * 2f / 3f
        drawLine(FineLine, Offset(x1, content.top), Offset(x1, content.bottom), strokeWidth = 1f)
        drawLine(FineLine, Offset(x2, content.top), Offset(x2, content.bottom), strokeWidth = 1f)
        drawLine(FineLine, Offset(content.left, y1), Offset(content.right, y1), strokeWidth = 1f)
        drawLine(FineLine, Offset(content.left, y2), Offset(content.right, y2), strokeWidth = 1f)
    }
}

/** Skutečná plocha 4:3/3:4 uvnitř PreviewView.ScaleType.FIT_CENTER. */
private fun fourThreeContentRect(size: Size): Rect {
    if (size.width <= 0f || size.height <= 0f) return Rect(0f, 0f, 0f, 0f)
    val contentAspect = if (size.height >= size.width) 3f / 4f else 4f / 3f
    val viewAspect = size.width / size.height
    return if (viewAspect > contentAspect) {
        val width = size.height * contentAspect
        val left = (size.width - width) / 2f
        Rect(left, 0f, left + width, size.height)
    } else {
        val height = size.width / contentAspect
        val top = (size.height - height) / 2f
        Rect(0f, top, size.width, top + height)
    }
}

@Composable
private fun FocusReticle(uiState: CameraUiState) {
    val point = uiState.focusPoint ?: return
    val pulse by animateFloatAsState(
        targetValue = if (uiState.focusPulse % 2 == 0) 1f else 0.82f,
        animationSpec = tween(240),
        label = "focusPulse"
    )
    Canvas(modifier = Modifier.fillMaxSize()) {
        val radius = 34.dp.toPx() * pulse
        drawCircle(
            color = Color.White,
            radius = radius,
            center = Offset(point.x, point.y),
            style = Stroke(width = 2.dp.toPx())
        )
        drawLine(
            Color.White,
            Offset(point.x - radius - 9.dp.toPx(), point.y),
            Offset(point.x - radius + 7.dp.toPx(), point.y),
            strokeWidth = 2.dp.toPx()
        )
        drawLine(
            Color.White,
            Offset(point.x + radius - 7.dp.toPx(), point.y),
            Offset(point.x + radius + 9.dp.toPx(), point.y),
            strokeWidth = 2.dp.toPx()
        )
    }
}

@Composable
private fun LevelIndicator(angle: Float) {
    val animatedAngle by animateFloatAsState(angle, label = "level")
    val leveled = abs(animatedAngle) < 1.5f
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 205.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.graphicsLayer(rotationZ = -animatedAngle.coerceIn(-12f, 12f)),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .width(54.dp)
                    .height(2.dp)
                    .background(if (leveled) MaterialTheme.colorScheme.primary else Color.White)
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (leveled) MaterialTheme.colorScheme.primary else Color.White)
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .width(54.dp)
                    .height(2.dp)
                    .background(if (leveled) MaterialTheme.colorScheme.primary else Color.White)
            )
        }
        AnimatedVisibility(visible = leveled) {
            Text(
                text = "ROVINA",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun MiniHistogram(metrics: FrameMetrics) {
    val primary = MaterialTheme.colorScheme.primary
    Canvas(
        modifier = Modifier
            .width(74.dp)
            .height(42.dp)
    ) {
        val values = metrics.histogram.ifEmpty { List(16) { 0f } }
        val maxValue = values.maxOrNull()?.coerceAtLeast(0.001f) ?: 0.001f
        val barWidth = size.width / values.size
        values.forEachIndexed { index, value ->
            val barHeight = size.height * (value / maxValue)
            drawLine(
                color = primary.copy(alpha = 0.92f),
                start = Offset(index * barWidth + barWidth / 2f, size.height),
                end = Offset(index * barWidth + barWidth / 2f, size.height - barHeight),
                strokeWidth = (barWidth * 0.64f).coerceAtLeast(1f),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun rememberDevicePose(): DevicePose {
    val context = LocalContext.current
    var pose by remember { androidx.compose.runtime.mutableStateOf(DevicePose()) }
    val estimator = remember { DevicePoseEstimator() }

    DisposableEffect(context, estimator) {
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = manager.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                pose = estimator.update(
                    x = event.values[0],
                    y = event.values[1],
                    z = event.values[2],
                    filteredBySensor = event.sensor.type == Sensor.TYPE_GRAVITY
                )
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        if (sensor != null) {
            manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose {
            manager.unregisterListener(listener)
            estimator.reset()
        }
    }
    return pose
}

private fun formatActualExposure(exposureNanos: Long?): String {
    val nanos = exposureNanos ?: return "—"
    if (nanos <= 0L) return "—"
    val seconds = nanos / 1_000_000_000.0
    return when {
        seconds >= 1.0 -> String.format(Locale.US, "%.1f s", seconds)
        seconds >= 0.1 -> String.format(Locale.US, "%.0f ms", seconds * 1000.0)
        else -> String.format(Locale.US, "1/%.0f s", 1.0 / seconds)
    }
}

private fun formatZoom(zoom: Float): String = when {
    abs(zoom - 0.6f) < 0.08f -> "0,6×"
    else -> String.format(Locale.US, "%.1f×", zoom).replace(".0×", "×")
}

private fun lensBindingLabel(state: LensBindingState): String = when (state) {
    LensBindingState.LOGICAL_AUTO -> "LOGICKÁ AUTO"
    LensBindingState.REQUESTED -> "POŽADOVÁN"
    LensBindingState.BOUND_UNVERIFIED -> "NAVÁZÁN, ČEKÁ NA DATA"
    LensBindingState.PHYSICAL_CONFIRMED -> "FYZICKY OVĚŘEN"
    LensBindingState.DIGITAL_FALLBACK -> "DIGITÁLNÍ NÁHRADA"
    LensBindingState.FAILED -> "SELHÁNÍ"
}

private fun lensCatalogLine(profiles: List<LensProfile>): String = profiles.joinToString(" · ") {
    buildString {
        append(it.shortLabel)
        append(" f/")
        append(it.aperture?.let { aperture -> "%.1f".format(Locale.US, aperture) } ?: "—")
        it.physicalCameraId?.let { id -> append(" #").append(id) }
        if (it.opticalStabilization) append(" OIS")
        if (it.rawSupported) append(" RAW")
    }
}

private fun exposureStateLabel(state: ExposureControlState): String = when (state) {
    ExposureControlState.AUTO -> "AUTO"
    ExposureControlState.REQUESTED -> "ČEKÁM"
    ExposureControlState.VERIFIED -> "OVĚŘENO"
    ExposureControlState.FALLBACK -> "AE FALLBACK"
    ExposureControlState.UNSUPPORTED -> "BEZ MANUAL"
}

private fun exposureStateColor(state: ExposureControlState): Color = when (state) {
    ExposureControlState.VERIFIED -> Color(0xFF6FE5A8)
    ExposureControlState.REQUESTED -> Color(0xFFFFC107)
    ExposureControlState.FALLBACK -> Color(0xFFFFA45B)
    ExposureControlState.UNSUPPORTED -> Color(0xFFFF7A7A)
    ExposureControlState.AUTO -> Color.White.copy(alpha = 0.72f)
}

private fun capabilityLine(capabilities: CameraCapabilities): String {
    val range = if (capabilities.manualExposureSupported &&
        capabilities.minExposureNanos > 0L && capabilities.maxExposureNanos > 0L
    ) {
        " · ${formatActualExposure(capabilities.minExposureNanos)}–" +
            formatActualExposure(capabilities.maxExposureNanos) +
            " · ISO ${capabilities.minIso}–${capabilities.maxIso}"
    } else {
        ""
    }
    return "Kamera ${capabilities.cameraId ?: "?"} · ${capabilities.hardwareLevel}" +
        " · RAW ${if (capabilities.rawSupported) "ano" else "ne"}" + range
}

private fun formatEv(ev: Float): String = when {
    ev > 0f -> "+%.1f".format(Locale.US, ev)
    ev < 0f -> "%.1f".format(Locale.US, ev)
    else -> "0"
}
