package cz.hqsnet.aifoto.coach

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.round
import kotlin.math.sqrt

/**
 * Převod gravitačního vektoru na odchylku od nejbližší roviny obrazovky.
 * Funguje v portrétu i krajině: 89° se chápe jako téměř přesná krajina,
 * nikoli jako horizont nakloněný o 89°.
 */
class DevicePoseEstimator {
    private var gravityX = 0f
    private var gravityY = 0f
    private var gravityZ = 0f
    private var pose = DevicePose()

    fun update(
        x: Float,
        y: Float,
        z: Float,
        filteredBySensor: Boolean
    ): DevicePose {
        val alpha = if (filteredBySensor) 0f else 0.82f
        gravityX = alpha * gravityX + (1f - alpha) * x
        gravityY = alpha * gravityY + (1f - alpha) * y
        gravityZ = alpha * gravityZ + (1f - alpha) * z

        val magnitude = sqrt(
            gravityX * gravityX + gravityY * gravityY + gravityZ * gravityZ
        ).coerceAtLeast(0.001f)
        val raw = Math.toDegrees(
            atan2(gravityX.toDouble(), gravityY.toDouble())
        ).toFloat()
        val nearestRightAngle = round(raw / 90f) * 90f
        var error = raw - nearestRightAngle
        while (error > 45f) error -= 90f
        while (error < -45f) error += 90f
        val flatness = (abs(gravityZ) / magnitude).coerceIn(0f, 1f)

        pose = DevicePose(
            levelErrorDegrees = pose.levelErrorDegrees * 0.72f + error * 0.28f,
            flatness = pose.flatness * 0.75f + flatness * 0.25f,
            sensorAvailable = true
        )
        return pose
    }

    fun reset() {
        gravityX = 0f
        gravityY = 0f
        gravityZ = 0f
        pose = DevicePose()
    }
}
