package cz.hqsnet.aifoto.capture

import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera

/**
 * Zamyká expozici a vyvážení bílé po dobu skládání snímků.
 *
 * Automatika mezi snímky dolaďuje jas i barvy, takže by se průměrovaly
 * snímky s odlišnou expozicí. Průměrování takovou odchylku neodstraní -
 * není náhodná jako šum, ale systematická, takže se do výsledku propíše.
 * Při kolísání kolem ±20 % vzroste chyba výsledku zhruba o polovinu.
 *
 * Interop je best-effort: když ho zařízení nepodpoří, skládání proběhne
 * i bez zámku, jen s o něco horším výsledkem.
 */
object ExposureLock {

    /**
     * Zamkne AE a AWB. Vrací true, pokud se požadavek podařilo odeslat -
     * neznamená to záruku, že zařízení zámek skutečně respektuje.
     */
    fun lock(camera: Camera): Boolean = apply(camera, locked = true)

    /** Uvolní zámek zpět na automatiku. */
    fun unlock(camera: Camera): Boolean = apply(camera, locked = false)

    /**
     * Přepne snímač na ruční expozici s delším časem.
     *
     * Tohle je hlavní rozdíl proti běžnému focení. Náhledový stream běží kvůli
     * plynulosti na krátkých časech (kolem 1/30 s), takže i šestnáct složených
     * snímků nasbírá dohromady jen zlomek sekundy světla. Telefony s dobrým
     * nočním režimem exponují jednotlivé snímky desetiny sekundy až sekundu -
     * nasbírají řádově víc světla a šum klesá s odmocninou z jeho množství.
     *
     * @param exposureNanos požadovaný čas jednoho snímku
     * @param iso citlivost; nižší znamená méně šumu, ale tmavší snímek
     */
    @OptIn(ExperimentalCamera2Interop::class)
    fun setManualExposure(camera: Camera, exposureNanos: Long, iso: Int): Boolean = try {
        val control = Camera2CameraControl.from(camera.cameraControl)
        // Kritická pravidla jsou v jediném requestu. setCaptureRequestOptions()
        // vždy nejprve smaže staré volby, takže jakékoli druhé set() by znovu
        // odstranilo právě nastavený čas a ISO.
        val options = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_OFF
            )
            .setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, exposureNanos)
            .setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AWB_MODE,
                CaptureRequest.CONTROL_AWB_MODE_AUTO
            )
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            // Barvu mezi snímky držíme zámkem místo vnucení konkrétního preset
            // režimu, který nemusí každý fyzický modul podporovat.
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, true)
            .build()
        control.setCaptureRequestOptions(options)
        true
    } catch (_: Throwable) {
        false
    }

    /** Vrátí snímač zpět na automatiku. */
    @OptIn(ExperimentalCamera2Interop::class)
    fun clearManualExposure(camera: Camera): Boolean = try {
        val control = Camera2CameraControl.from(camera.cameraControl)
        // setCaptureRequestOptions() samo nahradí celý předchozí balík,
        // takže SENSOR_EXPOSURE_TIME/SENSITIVITY po tomto jediném volání
        // nezůstanou v aktivních interop volbách.
        val options = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON
            )
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AWB_MODE,
                CaptureRequest.CONTROL_AWB_MODE_AUTO
            )
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, false)
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, false)
            .build()
        control.setCaptureRequestOptions(options)
        true
    } catch (_: Throwable) {
        false
    }

    /**
     * Zvolí čas a citlivost podle toho, jak je tma.
     *
     * Delší čas je vždycky lepší než vyšší citlivost - přidává signál, kdežto
     * citlivost jen zesílí i šum. Strop je daný tím, jak dlouho se dá telefon
     * udržet v klidu, a tím, co snímač dovolí.
     */
    fun suggestExposure(
        meanLuma: Float,
        limits: ExposureLimits,
        exposureCapNanos: Long = limits.maxExposureNanos
    ): Pair<Long, Int> {
        val wanted = when {
            meanLuma < 20f -> 400_000_000L   // 1/2.5 s
            meanLuma < 40f -> 250_000_000L   // 1/4 s
            meanLuma < 70f -> 125_000_000L   // 1/8 s
            else -> 62_500_000L              // 1/16 s
        }
        val allowedMaximum = minOf(limits.maxExposureNanos, exposureCapNanos)
            .coerceAtLeast(limits.minExposureNanos)
        val exposure = wanted.coerceIn(limits.minExposureNanos, allowedMaximum)
        // Citlivostí dorovnáme jen to, co se nevešlo do času.
        val shortfall = wanted.toFloat() / exposure.toFloat()
        val iso = (limits.minIso * shortfall * ISO_HEADROOM).toInt()
            .coerceIn(limits.minIso, limits.maxIso)
        return exposure to iso
    }

    /**
     * Zjistí, jaké časy a citlivosti snímač dovolí. Když se to nepodaří,
     * vrátí opatrné hodnoty, se kterými si poradí prakticky každý telefon.
     */
    @OptIn(ExperimentalCamera2Interop::class)
    fun readLimits(camera: Camera): ExposureLimits {
        return try {
            val info = Camera2CameraInfo.from(camera.cameraInfo)
            val exposureRange = info.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE
            )
            val isoRange = info.getCameraCharacteristic(
                CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE
            )
            ExposureLimits(
                minExposureNanos = exposureRange?.lower ?: DEFAULT_MIN_EXPOSURE,
                maxExposureNanos = exposureRange?.upper ?: DEFAULT_MAX_EXPOSURE,
                minIso = isoRange?.lower ?: DEFAULT_MIN_ISO,
                maxIso = isoRange?.upper ?: DEFAULT_MAX_ISO
            )
        } catch (_: Throwable) {
            ExposureLimits(
                DEFAULT_MIN_EXPOSURE, DEFAULT_MAX_EXPOSURE, DEFAULT_MIN_ISO, DEFAULT_MAX_ISO
            )
        }
    }

    /** Podporuje snímač ruční nastavení expozice? */
    @OptIn(ExperimentalCamera2Interop::class)
    fun supportsManualExposure(camera: Camera): Boolean = try {
        val capabilities = Camera2CameraInfo.from(camera.cameraInfo)
            .getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
        capabilities?.contains(
            CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR
        ) ?: false
    } catch (_: Throwable) {
        false
    }

    /** Camera2 ID právě připojeného logického fotoaparátu. */
    @OptIn(ExperimentalCamera2Interop::class)
    fun cameraId(camera: Camera): String? = try {
        Camera2CameraInfo.from(camera.cameraInfo).cameraId
    } catch (_: Throwable) {
        null
    }

    /** Camera2 hardware level pro diagnostiku kompatibility. */
    @OptIn(ExperimentalCamera2Interop::class)
    fun hardwareLevel(camera: Camera): Int? = try {
        Camera2CameraInfo.from(camera.cameraInfo).getCameraCharacteristic(
            CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL
        )
    } catch (_: Throwable) {
        null
    }

    /** Co snímač dovolí. */
    data class ExposureLimits(
        val minExposureNanos: Long,
        val maxExposureNanos: Long,
        val minIso: Int,
        val maxIso: Int
    )

    /** Základní citlivost bývá nízká, takže i s delším časem je třeba rezerva. */
    private const val ISO_HEADROOM = 4f

    private const val DEFAULT_MIN_EXPOSURE = 100_000L        // 1/10000 s
    private const val DEFAULT_MAX_EXPOSURE = 100_000_000L    // 1/10 s
    private const val DEFAULT_MIN_ISO = 50
    private const val DEFAULT_MAX_ISO = 3200

    @OptIn(ExperimentalCamera2Interop::class)
    private fun apply(camera: Camera, locked: Boolean): Boolean = try {
        val control = Camera2CameraControl.from(camera.cameraControl)
        // Jeden úplný balík zároveň odstraní případné ruční SENSOR_* klíče
        // a výslovně vrátí 3A automatiku. Nevzniká závod mezi clear(), set()
        // a následným lock(), který by mohl na některém HALu zanechat neurčitý stav.
        val options = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AE_MODE,
                CaptureRequest.CONTROL_AE_MODE_ON
            )
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AWB_MODE,
                CaptureRequest.CONTROL_AWB_MODE_AUTO
            )
            .setCaptureRequestOption(
                CaptureRequest.CONTROL_AF_MODE,
                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, locked)
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, locked)
            .build()
        control.setCaptureRequestOptions(options)
        true
    } catch (_: Throwable) {
        // Starší nebo nestandardní zařízení interop nemusí podporovat.
        false
    }
}
