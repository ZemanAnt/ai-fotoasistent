package cz.hqsnet.aifoto.lens

enum class LensRole {
    ULTRA_WIDE,
    WIDE,
    TELEPHOTO,
    SUPER_TELEPHOTO,
    UNKNOWN
}

data class LensProfile(
    val id: String,
    /** Camera2 ID zařízení, které CameraX vybere jako logickou/ samostatnou kameru. */
    val selectorCameraId: String,
    /** Fyzický modul uvnitř logické kamery. Null = samostatná nebo logická auto kamera. */
    val physicalCameraId: String? = null,
    val role: LensRole = LensRole.UNKNOWN,
    val displayName: String,
    val shortLabel: String,
    /** Přibližné optické zvětšení vůči hlavnímu modulu, ne digitální zoom. */
    val equivalentZoom: Float,
    val focalLengthMm: Float,
    val equivalentFocalLength35Mm: Float? = null,
    val aperture: Float? = null,
    val sensorWidthMm: Float? = null,
    val sensorHeightMm: Float? = null,
    val minFocusDistanceDiopters: Float? = null,
    val opticalStabilization: Boolean = false,
    val rawSupported: Boolean = false,
    val activeArrayWidth: Int = 0,
    val activeArrayHeight: Int = 0,
    val maxDigitalZoom: Float = 1f,
    val logicalMultiCamera: Boolean = false
) {
    val minFocusDistanceCm: Float?
        get() = minFocusDistanceDiopters
            ?.takeIf { it > 0f }
            ?.let { 100f / it }
}

data class LensCatalogState(
    val logicalCameraId: String? = null,
    val profiles: List<LensProfile> = emptyList(),
    val mainLensId: String? = null,
    val logicalMultiCamera: Boolean = false,
    val discoveryWarning: String? = null
) {
    fun profile(id: String?): LensProfile? = profiles.firstOrNull { it.id == id }
    fun mainLens(): LensProfile? = profile(mainLensId)
}

enum class OemExtensionMode(val shortLabel: String, val displayName: String) {
    NONE("OEM", "Vypnuto"),
    AUTO("A", "OEM Auto"),
    NIGHT("N", "OEM Night"),
    HDR("H", "OEM HDR")
}

data class ExtensionAvailability(
    val auto: Boolean = false,
    val night: Boolean = false,
    val hdr: Boolean = false
) {
    val any: Boolean get() = auto || night || hdr

    fun supports(mode: OemExtensionMode): Boolean = when (mode) {
        OemExtensionMode.NONE -> true
        OemExtensionMode.AUTO -> auto
        OemExtensionMode.NIGHT -> night
        OemExtensionMode.HDR -> hdr
    }
}

enum class LensBindingState {
    LOGICAL_AUTO,
    REQUESTED,
    BOUND_UNVERIFIED,
    PHYSICAL_CONFIRMED,
    DIGITAL_FALLBACK,
    FAILED
}

data class LensTruth(
    val requestedLensId: String? = null,
    val activeLensId: String? = null,
    val activePhysicalCameraId: String? = null,
    val activeLabel: String = "Logická kamera",
    val opticalBaseZoom: Float = 1f,
    val digitalCropFactor: Float = 1f,
    val effectiveZoom: Float = 1f,
    val focalLengthMm: Float? = null,
    val bindingState: LensBindingState = LensBindingState.LOGICAL_AUTO,
    val verified: Boolean = false
) {
    val digitalCropActive: Boolean get() = digitalCropFactor > 1.08f
}

data class LensRecommendation(
    val lensId: String?,
    val equivalentZoom: Float,
    val displayLabel: String,
    val reason: String,
    val warning: String? = null,
    val extensionMode: OemExtensionMode = OemExtensionMode.NONE,
    val stable: Boolean = false,
    val confirmingSamples: Int = 1
)
