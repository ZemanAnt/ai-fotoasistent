# Kompatibilita zařízení

## Primární zařízení

Projekt je navržen a laděn pro Samsung Galaxy S22 Ultra. Aplikace však nepoužívá pevně zadaná Camera2 ID a při startu vytváří katalog schopností konkrétního telefonu.

## Minimální systém

- Android 8.0 / API 26
- zadní fotoaparát
- doporučený autofocus

## Funkce závislé na zařízení

| Funkce | Požadavek | Fallback |
| --- | --- | --- |
| Přímý fyzický objektiv | Camera2 logical multi-camera a zveřejněné physical ID | Logická zadní kamera s pravdivě označeným digitálním cropem |
| Ruční ISO a čas | `MANUAL_SENSOR` | AE/AWB lock a automatická expozice |
| RAW/DNG | RAW capability | JPEG |
| OIS telemetrie | Dostupná charakteristika modulu | Bez tvrzení o OIS |
| OEM Auto/Night/HDR | CameraX Extension dostupná pro session | Standardní CameraX nebo vlastní Computational Night |
| Computational Night | Dostatek paměti a alespoň minimální počet přijatých snímků | Jednotlivý referenční snímek / bezpečné ukončení |

## Jak přidat výsledek testu

Použijte GitHub issue formulář **Výsledek testu zařízení** a přiložte pouze anonymizovanou telemetrii. Nevkládejte soukromé fotografie, GPS, sériové číslo telefonu ani účty.
