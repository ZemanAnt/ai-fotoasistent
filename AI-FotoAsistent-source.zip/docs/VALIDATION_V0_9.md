# Validace zdrojového projektu v0.9

## Automaticky ověřeno v pracovním prostředí

- Kotlin PSI: všechny `.kt` soubory bez syntaktické chyby;
- čistě kotlinové jádro `CoachModels`, `DevicePoseEstimator`, `PhotoCoachEngine` a `SceneAdvice` se přeložilo přes `kotlinc`;
- validační scénáře:
  - pohyb má přednost před kompozicí;
  - horizont má přednost u krajiny;
  - malý obličej vyvolá přiblížení;
  - bezpečná scéna přejde do READY;
  - READY vyžaduje tři potvrzení;
  - nezjištěná pravděpodobnost očí se nepovažuje za zavřené oči;
  - portrét i krajina se normalizují na nulovou rovinu;
  - telefon rovnoběžný s podložkou vrátí vysokou flatness;
- callback obou ML Kit úloh vždy uvolní `ImageProxy`, i při chybě modelu nebo UI callbacku;
- XML zdroje lze parsovat;
- výsledný ZIP lze celý přečíst bez CRC chyby.

## Omezení validace

Plný Android build nebyl v pracovním prostředí dokončen, protože:

- Gradle wrapper nemohl kvůli nedostupnému DNS stáhnout distribuci z `services.gradle.org`;
- prostředí neobsahovalo Android SDK / `android.jar`.

Proto je stále nutné provést Gradle Sync, unit testy a instalaci na fyzický Galaxy S22 Ultra podle `TEST_PLAN_V0_9.md`.

## Zvlášť ověřit na zařízení

- skutečné souřadnice ML Kit bounding boxů ve všech čtyřech orientacích;
- přesnost prahu otevřených očí v horším světle a s brýlemi;
- prahy velikosti tváře pro 1× a 3× modul;
- zpoždění face detection při 10× modulu a v noční scéně;
- mapování směru vodováhy při obráceném portrétu;
- souběh bundled face modelu, image labeling a CameraX na dlouhé session;
- chování kouče během OEM Extension session, kde není aktivní ImageAnalysis.
