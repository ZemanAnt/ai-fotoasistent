# Soukromí

## Technické chování verze 0.9.0

- Aplikace nemá v manifestu oprávnění `INTERNET`.
- Analýza scény a obličeje probíhá lokálně v zařízení.
- Detekce obličeje neurčuje totožnost člověka.
- Fotografie, RAW soubory a AI kopie se ukládají do systémového úložiště médií zařízení.
- Aplikace neobsahuje analytiku, reklamní SDK ani vzdálené logování.
- Diagnostické údaje zůstávají v běžícím procesu, pokud je uživatel sám nezkopíruje do hlášení chyby.

## Příspěvky do GitHub issues

Veřejný GitHub není vhodné místo pro soukromé fotografie, přesnou polohu, EXIF s GPS, sériová čísla, účty nebo signing klíče. Před přiložením logu či snímku tato data odstraňte.

Tento dokument popisuje chování zdrojové verze v tomto repozitáři. Upravené sestavení třetí strany může mít jiné vlastnosti.
