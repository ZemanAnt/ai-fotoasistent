# Validace zdrojového projektu v0.8

- Kotlin PSI parser: 28 zdrojových a testovacích souborů, 0 syntaktických chyb.
- Překlad čistého jádra `NightPlanner` / `NightAlignment` / `FrameStacker` s testovací Bitmap implementací: úspěšný.
- Integrační test: známý posun +4/−3 px přijat, senzorově rozhýbaný snímek odmítnut.
- Regresní matice registrace: 900 kombinací posunů −7…+7 px a oken 8/9/12/18, všechny úspěšné.
- Jednolitý obraz: nulový posun, nulová obrazová důvěra.
- XML prostředky a manifest: validní XML.
- Gradle wrapper je přítomen a jeho JAR je čitelný. Distribuce má deklarovaný SHA-256.

Plné Android sestavení v tomto pracovním prostředí neproběhlo: Gradle wrapper nemohl kvůli nedostupnému DNS stáhnout `gradle-8.13-bin.zip` a Android SDK zde není instalováno. Finální ověření na Galaxy S22 Ultra proveďte podle `TEST_PLAN_V0_8.md`.
