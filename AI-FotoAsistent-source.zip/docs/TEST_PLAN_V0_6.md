# Testovací plán v0.6 – Samsung Galaxy S22 Ultra

## 1. Sestavení

```bash
./gradlew testDebugUnitTest assembleDebug
```

Očekávaný výstup: `app/build/outputs/apk/debug/app-debug.apk`.

## 2. Živá telemetrie

1. Spusťte aplikaci a klepněte na odznak **AI**.
2. Ověřte, že se mění skutečný čas a ISO při zakrytí a odkrytí objektivu.
3. Diagnostika musí ukázat Camera2 ID, hardware level, rozsah času/ISO a stav RAW.
4. V běžném náhledu musí být stav expozice **AUTO**, nikoli „ověřeno“.

## 3. Ruční noční expozice

1. Telefon opřete a otevřete tmavou, nepohyblivou scénu.
2. Spusťte **NOC**.
3. Stav má přejít přes **ČEKÁM** do jedné z pravdivých větví:
   - **OVĚŘENO** pouze po dvou po sobě jdoucích odpovídajících CaptureResult;
   - **AE FALLBACK**, pokud firmware čas a ISO nepotvrdí.
4. Po dokončení nebo zrušení se stav musí vrátit na **AUTO** a náhled musí znovu reagovat na světlo.
5. V EXIF výsledku zkontrolujte skutečný průměrný čas a ISO.

## 4. Rotace a překryvy

Ověřte portrét, obrácený portrét, krajinu vlevo i vpravo:

- uložená fotografie má správnou orientaci;
- mřížka a červená maska přepalů leží jen nad obrazem 4:3/3:4;
- dotyk v černém pruhu nevykreslí bod ostření;
- dotyk v obrazu ostří na odpovídající místo.

## 5. JPEG a AI kopie

1. Vyfoťte tmavou scénu bez RAW.
2. V galerii musí zůstat původní JPEG a vedle něj samostatný soubor `_AI.jpg`.
3. Originál nesmí změnit velikost, EXIF ani datum.
4. AI kopie má zachovat orientaci, čas, ISO, ohnisko, výrobce/model a případná GPS metadata.

## 6. RAW + JPEG

1. Zapněte RAW a pořiďte snímek.
2. Ukládání se musí vždy ukončit, i když jeden callback selže.
3. Při úspěchu musí být v galerii JPEG a DNG se stejným časovým základem názvu.
4. Aplikace nesmí určovat formát podle pořadí callbacků; ověřuje MIME a název souboru.

## 7. Regrese

- blesk cykluje OFF → AUTO → ON → OFF;
- svítilna se po návratu z aplikace nezasekne;
- samospoušť lze druhým stiskem zrušit;
- zrušení nočního režimu vždy uvolní AE/AWB a EV;
- po opakovaném zapnutí/vypnutí RAW se kamera znovu korektně naváže;
- po deseti běžných a třech nočních snímcích aplikace nespadne kvůli paměti.
