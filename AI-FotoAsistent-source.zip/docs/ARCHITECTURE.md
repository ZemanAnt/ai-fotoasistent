# Architektura verze 0.9

## Hlavní tok dat

1. `LensCatalog` sestaví katalog zadních fyzických modulů z Camera2 charakteristik.
2. `CameraPreview` naváže fyzický modul, logickou kameru nebo dostupný OEM Extension režim.
3. Camera2 callback převádí skutečný `CaptureResult` na `CaptureTelemetry`.
4. `SceneAnalyzer` paralelně spouští image labeling a face detection a počítá jas, kontrast, přepaly, pohyb, ostrost a vizuální těžiště.
5. `SceneAdvisor` určí typ scény a fotografická doporučení.
6. `SmartLensEngine` doporučí pravdivý objektiv a případný OEM režim.
7. `DevicePoseEstimator` převádí gravitační vektor na odchylku od roviny a míru rovnoběžnosti telefonu s podložkou.
8. `PhotoCoachEngine` spojí obraz, tváře, polohu telefonu a skutečný čas expozice do jediného prioritního pokynu.
9. `CoachCueStabilizer` zabrání blikání rady a stav READY potvrdí až po třech bezpečných analýzách.
10. Při Computational Night vytvoří `NightPlanner` konkrétní plán série, `NightMotionTracker` měří pohyb, `NightAlignment` registruje snímky a `FrameStacker` provede tiled blending a deghosting.
11. Fotografie se uloží do MediaStore; diagnostika si zapamatuje pokyn platný při stisku spouště.

## AI Photo Coach

### Datové modely

- `FaceObservation` – normalizovaný obdélník obličeje, tracking ID, otevření očí, úsměv a natočení hlavy;
- `DevicePose` – odchylka od nejbližší vodorovné orientace a flatness 0–1;
- `CoachExposure` – skutečný čas a ISO bez závislosti rozhodovacího jádra na Android API;
- `CoachCue` – jeden pokyn, priorita, směr, skóre, cílový bod a vysvětlení;
- `CoachState` – režim UI, aktuální pokyn, počet tváří, skóre a poslední pokyn zachycený při spoušti.

### Priorita pokynů

`PhotoCoachEngine` vrací právě jeden pokyn v tomto pořadí:

1. pohyb telefonu vzhledem ke skutečnému expozičnímu času;
2. perspektiva dokumentu a rovina horizontu;
3. přepaly;
4. zavřené oči, příliš malý/velký obličej a kontakt s okrajem;
5. chybějící jemná kresba / ostření;
6. vizuální těžiště a kompozice;
7. stav READY.

Tím je zajištěno, že estetická rada nikdy nepřebije technický problém, který by znehodnotil celý snímek.

### Stabilizace

- urgentní rada se zobrazí okamžitě;
- běžná rada musí být nalezena dvakrát;
- READY musí být potvrzen třikrát;
- aktualizace gravitačního senzoru smí okamžitě měnit jen rovinu a perspektivu;
- kompozici a obličej mohou potvrdit pouze nové obrazové analýzy.

### Tři režimy rozhraní

#### Jednoduchý

- jedna krátká rada;
- skóre připravenosti;
- aktivní objektiv, noční režim a spoušť;
- bez histogramu, přepalové masky a technické diagnostiky.

#### AI kouč

- rada s vysvětlením a cílovým bodem;
- Smart Lens doporučení a skutečný čas;
- mřížka a vodováha;
- kompaktní noční informace.

#### Pro

- histogram a přepalová maska;
- optický základ, digitální crop, čas, ISO a OEM stav;
- plná Camera2 diagnostika;
- vysvětlení aktuální i poslední zachycené rady.

## Analýza obrazu

`SceneAnalyzer` používá pevnou mřížku 48×36. Vedle starších metrik počítá:

- `sharpnessScore` – normalizovanou energii jemných hran;
- `saliencyCenterX/Y` – vizuální těžiště z lokálních hran a kontrastu;
- `saliencyConfidence` – zda má scéna dostatek struktury pro smysluplnou kompoziční radu.

Jednolitá obloha nebo prázdná stěna proto nevytvoří silný falešný kompoziční cíl. Obličeje mají před heuristickým těžištěm přednost.

## Poloha telefonu

`DevicePoseEstimator` používá `TYPE_GRAVITY`, případně filtrovaný akcelerometr. Úhel normalizuje vůči nejbližšímu násobku 90°. Telefon držený přesně na šířku tedy vrací přibližně 0°, nikoli 90°.

`flatness` vychází z podílu gravitační složky osy Z:

- přibližně 0 – telefon je svisle;
- přibližně 1 – displej je rovnoběžně se zemí nebo dokumentem.

## Profily Computational Night

### Z ruky

- 7–12 přijatých snímků podle tmy;
- maximálně pět náhradních pokusů;
- čas jednoho snímku omezen přibližně na 125 ms;
- toleruje běžné chvění, ale každý snímek kontroluje gyroskop i obrazová registrace;
- deghosting dovolí pohyb menší části scény.

### Stativ

- 5–8 přijatých snímků;
- čas může dosáhnout až 800 ms, pokud ho snímač podporuje;
- výrazně přísnější gyroskopický a registrační práh;
- menší tolerance pohybu scény, protože cílem je maximálně čisté statické pozadí.

### Noční portrét

- 6–8 přijatých snímků;
- čas omezen zhruba na 55 ms, aby obličej nebyl pohybově rozmazaný;
- silný referenční deghosting;
- pozadí se stále temporálně odšumí.

AUTO použije portrétní profil pro člověka nebo zvíře, stativ jen při velmi tmavém a mimořádně stabilním náhledu, jinak profil z ruky.

## Registrace snímků

`NightAlignment` pracuje nad `LumaFrame` o maximální delší straně 320 px:

1. všechny celočíselné posuny v omezeném okně se změří na řídkém vzorku obrazu;
2. několik nejlepších prostorově odlišných kandidátů se ověří jemným měřením;
3. normalizovaná robustní chyba omezuje vliv blikajících světel;
4. důvěra vyžaduje nízkou chybu, jednoznačný vítězný posun i dostatek textury.

Jednolitá tma vrátí nulovou důvěru. Full-resolution posun vznikne přepočtem z miniatury. Pipeline opravuje globální translaci; velká rotace a paralaxa vedou raději k odmítnutí snímku.

## Paměťový model

`FrameStacker` drží:

- jeden `IntArray` s průběžným ARGB výsledkem;
- jeden `ByteArray` s počtem vzorků na pixel;
- malou referenční luma mapu;
- právě zpracovávanou `Bitmap`.

Blending používá dlaždice o 64 nebo 96 řádcích. Při 12 Mpx má dlouhodobý stav přibližně 60 MB.

## Soukromí

Image labeling i face detection používají bundled modely. Aplikace nemá oprávnění `INTERNET`; obraz, tváře ani metriky neopouštějí telefon. Face Detection neurčuje identitu osoby.

## Důležité soubory

- `coach/CoachModels.kt` – režimy, tváře, poloha telefonu a pokyny;
- `coach/PhotoCoachEngine.kt` – prioritní rozhodovací logika a stabilizace;
- `coach/DevicePoseEstimator.kt` – testovatelný převod gravitačního vektoru;
- `analysis/SceneAnalyzer.kt` – ML Kit, metriky ostrosti a salience;
- `analysis/SceneAdvisor.kt` – klasifikace scény;
- `lens/SmartLensEngine.kt` – volba objektivu a OEM režimu;
- `capture/NightPlanner.kt` – volba nočního profilu;
- `capture/NightMotionTracker.kt` – gyroskop a akcelerometr;
- `capture/NightAlignment.kt` – registrace luma snímků;
- `capture/FrameStacker.kt` – tiled blending, deghosting a tone mapping;
- `CameraViewModel.kt` – orchestrace kamery, kouče, ukládání a pravdivé telemetrie;
- `ui/CameraScreen.kt` – tři úrovně hledáčku a živé pokyny.
