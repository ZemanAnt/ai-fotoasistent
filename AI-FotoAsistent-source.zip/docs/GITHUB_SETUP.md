# Nahrání projektu na GitHub

## 1. Vytvoření repozitáře

Na GitHubu vytvořte prázdný repozitář, například:

```text
AI-FotoAsistent-S22-Ultra
```

Při vytváření nepřidávejte další README, licenci ani `.gitignore`; všechny soubory už projekt obsahuje.

## 2. První push

V kořenové složce projektu spusťte:

```bash
git init
git add .
git commit -m "Initial release: AI Photo Coach v0.9.0"
git branch -M main
git remote add origin https://github.com/USERNAME/AI-FotoAsistent-S22-Ultra.git
git push -u origin main
```

Nahraďte `USERNAME` svým GitHub účtem nebo organizací.

## 3. Kontrola po nahrání

- V záložce **Actions** musí proběhnout workflow `Android CI`.
- V **Settings → Actions → General** ponechte workflow oprávnění minimálně pro čtení. Release workflow má vlastní omezené `contents: write`.
- V **Settings → Code security and analysis** zapněte Dependabot alerts a private vulnerability reporting, pokud jsou dostupné.
- Nastavte větev `main` jako chráněnou a vyžadujte úspěšný check `build` před sloučením pull requestu.

## 4. Podepsaný GitHub Release

Nikdy neukládejte keystore do repozitáře. V **Settings → Secrets and variables → Actions** vytvořte tyto repository secrets:

- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

### Převod keystore na Base64

Linux/macOS:

```bash
base64 -w 0 release.keystore
```

macOS, pokud `-w` není dostupné:

```bash
base64 < release.keystore | tr -d '\n'
```

PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("release.keystore"))
```

Výsledek vložte jako hodnotu secretu `ANDROID_KEYSTORE_BASE64`.

### Vydání přes tag

```bash
git tag -a v0.9.0 -m "AI Photo Coach v0.9.0"
git push origin v0.9.0
```

Workflow vytvoří podepsaný APK, podepsaný AAB, společný SHA-256 součet a GitHub Release. Tagy s `-alpha`, `-beta` nebo `-rc` se označí jako prerelease.

Release lze spustit také ručně v záložce **Actions → Signed Android Release**.
