# Testovací plán v0.7 – Smart Lens Engine na Galaxy S22 Ultra

## 1. Start a katalog

1. Spusťte aplikaci a klepněte na odznak **AI**.
2. Ověřte, že diagnostika vypíše více zadních modulů nebo čestné varování, že je Samsung nezpřístupnil.
3. Zkontrolujte, že hlavní modul je označen přibližně 1× a ostatní jsou seřazeny podle zvětšení.
4. Ověřte, že aplikace nespadne při opakovaném otočení telefonu a návratu z pozadí.

## 2. Ruční přepínání modulů

Pro každý zobrazený modul:

1. Klepněte na jeho tlačítko.
2. Stav musí projít přes **POŽADOVÁN** a následně **FYZICKY OVĚŘEN**, **NAVÁZÁN** nebo čestný **DIGITÁLNÍ FALLBACK**.
3. Sledujte změnu fyzického ID a ohniska.
4. Zakryjte postupně jednotlivé objektivy prstem a ověřte, že diagnostika odpovídá obrazu.
5. U fallbacku ověřte, že UI neoznačuje výsledek jako opticky potvrzený.

## 3. Digitální crop

1. Vyvolejte případ, kdy fyzický modul nelze navázat, nebo použijte logickou kameru.
2. Zkontrolujte `crop` a efektivní zoom.
3. Efektivní zoom musí odpovídat `optika × crop`; nesmí se násobit dvakrát.
4. Při cropu větším než přibližně 1,08× musí aktivní popisek obsahovat „digitální“.

## 4. Rozhodování AI

- tmavý portrét: doporučení 1×, tele odmítnuto;
- světlý stabilní portrét: doporučení skutečného 3× modulu, pokud je dostupný;
- noční scéna: hlavní modul, případně OEM Night;
- krajina za silného světla: ultraširoký modul;
- krajina za šera nebo s pohybem: hlavní modul;
- běžná kočka: nikdy automatické 10×;
- vzdálený pták za silného světla a bez pohybu: lze doporučit supertele.

Pohybujte telefonem na hranici rozhodnutí. Doporučený modul se smí změnit až po třech shodných analýzách, nikoli každým snímkem.

## 5. OEM Auto / Night / HDR

1. Horním tlačítkem **OEM** projděte pouze režimy, které aplikace označí jako dostupné.
2. Ověřte, že se session po změně obnoví a náhled nezčerná.
3. V OEM režimu musí být RAW vypnutý a vlastní tlačítko NOC nedostupné.
4. Při návratu na OEM vypnuto se má obnovit ImageAnalysis a živé doporučení.
5. Při selhání vendor režimu se musí objevit zpráva a běžná kamera se automaticky obnovit.

## 6. RAW a kompatibilita

1. Zapněte RAW; OEM režim se musí vypnout.
2. Vyberte modul bez RAW capability; volba RAW nesmí být nabízena jako podporovaná.
3. U hlavního podporovaného modulu pořiďte JPEG+DNG a ověřte oba soubory.

## 7. Regrese v0.6

- skutečný čas a ISO dál přicházejí z CaptureResult;
- ruční noční expozice se neoznačí jako ověřená bez dvou shodných výsledků;
- mřížka, přepaly a dotykové ostření zůstávají v ploše 4:3;
- AI úprava nepřepisuje originální JPEG;
- samospoušť, blesk, svítilna a rotace fungují po každém přepnutí modulu.
