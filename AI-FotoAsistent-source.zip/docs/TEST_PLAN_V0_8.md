# Testovací plán v0.8 – Computational Night

Cílové zařízení: Samsung Galaxy S22 Ultra, ideálně Exynos i Snapdragon varianta. Testovat s nabitou baterií, bez úsporného režimu a s volným místem alespoň 2 GB.

## 1. Základní sestavení

1. Otevřít projekt s JDK 17 a Android SDK 36.
2. Spustit `gradlew.bat testDebugUnitTest assembleDebug`.
3. Ověřit, že projdou `NightAlignmentTest`, `NightPlannerTest`, `ExposureLockTest` a starší testy v0.6/v0.7.
4. Nainstalovat debug APK a zkontrolovat, že aplikace hlásí verzi 0.8.0.

## 2. Režim Z ruky

Scéna: noční ulice s lampami a statickými budovami.

- vybrat RUKA nebo AUTO;
- udělat tři série s běžným držením telefonu;
- očekávat 7–12 přijatých snímků a případně jednotlivé odmítnuté snímky;
- série se nesmí zrušit při drobném chvění;
- hrany oken a lamp nesmějí mít dvojité kontury;
- jasné lampy nesmějí vytvořit velké průhledné duchy;
- UI musí zůstat responzivní během registrace a skládání.

## 3. Silné chvění

Během druhého či třetího snímku telefon záměrně krátce vychýlit.

- právě rozhýbaný snímek má být odmítnut;
- počitadlo odmítnutých snímků se zvýší;
- aplikace má pokračovat náhradním pokusem;
- výsledek nesmí obsahovat šmouhu z odmítnutého snímku.

## 4. Stativ

Scéna: velmi tmavé panorama, telefon na pevném stativu, samospoušť 2 s.

- vybrat STAT;
- ověřit, že požadovaný čas může být delší než v režimu RUKA;
- po dotyku stativu během série se má snímek odmítnout nebo série bezpečně ukončit;
- statická scéna má mít méně šumu než RUKA při podobném výsledném jasu;
- zkontrolovat teplotu zařízení a dobu zpracování.

## 5. Noční portrét

Scéna: člověk před osvětlenou ulicí, bez blesku.

- vybrat POR nebo AUTO s rozpoznaným portrétem;
- požadovaný čas má být kratší než u profilu RUKA;
- požádat osobu o drobný pohyb hlavy mezi snímky;
- obličej nesmí mít několik průhledných poloh;
- pozadí má být čistší než u jediného běžného snímku;
- ověřit, že první přijatý snímek určuje hlavní podobu pohybující se osoby.

## 6. Pohyb ve scéně

Scéna: projíždějící auto nebo chodec před statickou budovou.

- budova se má skládat a odšumit;
- pohybující se objekt se má zachovat převážně z reference;
- při pohybu většiny obrazu se má snímek odmítnout;
- rychlé panorámování celým telefonem nesmí být vydáváno za úspěšně zarovnanou sérii;
- zakrýt objektiv nebo fotografovat téměř jednolitou tmavou stěnu: diagnostika nesmí hlásit velký „přesně ověřený“ posun; při klidném telefonu smí použít pravdivý nulový senzorový fallback.

## 7. Paměť a stabilita

- pořídit deset nočních fotografií za sebou v 12 Mpx;
- sledovat Android Studio Memory Profiler;
- po dokončení série se paměť musí vracet, nesmí růst po každém snímku;
- otočit telefon během neaktivního náhledu a poté pořídit další sérii;
- během aktivní série přepnout aplikaci do pozadí a vrátit se: nesmí zůstat aktivní gyroskop ani zamčená expozice;
- otestovat přerušení CameraX session změnou objektivu před a po sérii.

## 8. RAW a OEM režimy

- zapnout RAW: tlačítko Computational Night musí být nedostupné nebo zobrazit pravdivou výzvu k vypnutí RAW;
- zapnout OEM Night/HDR: vlastní Computational Night se nesmí spustit;
- po návratu na OEM NONE a vypnutí RAW musí být vlastní noční režim znovu dostupný.

## 9. EXIF a galerie

U výsledku ověřit:

- správnou orientaci;
- `Software = AI FotoAsistent v0.8`;
- popis s profilem, přijatými a odmítnutými snímky, maximálním posunem, časem a ISO;
- název souboru obsahuje `noc_handheld`, `noc_tripod` nebo `noc_portrait`;
- galerie snímek otevře bez opravné rotace nebo poškození JPEG.

## 10. Kritéria vydání

- žádný pád nebo trvale černý náhled v deseti po sobě jdoucích sériích;
- žádný trvale zamčený čas, ISO, AWB nebo aktivní senzor po ukončení;
- nejméně 80 % běžných sérií z ruky dokončeno se čtyřmi nebo více přijatými snímky;
- odmítnutý rozhýbaný snímek nesmí být viditelný jako dvojitá kontura;
- zpracování nesmí blokovat animaci průběhu a základní UI;
- výsledek musí být při 100% zobrazení prokazatelně čistší než jeden referenční JPEG.
