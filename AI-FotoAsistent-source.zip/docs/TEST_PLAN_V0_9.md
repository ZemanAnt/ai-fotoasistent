# Testovací plán v0.9 – AI Photo Coach

## Příprava

1. Galaxy S22 Ultra aktualizovaný na dostupný stabilní systém.
2. Android Studio, JDK 17, Android SDK 36.
3. Spustit `gradlew.bat testDebugUnitTest assembleDebug`.
4. Nainstalovat debug APK a ověřit verzi 0.9.0.
5. Vypnout datové připojení a ověřit, že image labeling i face detection fungují po čisté instalaci.

## 1. Režimy rozhraní

### Jednoduchý

- přepnout čip na `JEDN`;
- ověřit jednu krátkou radu, skóre, objektiv, noční režim a spoušť;
- histogram, přepalová maska a diagnostika nesmějí být viditelné.

### AI kouč

- přepnout na `KOUČ`;
- ověřit mřížku, cílový bod, vysvětlení rady, Smart Lens a skutečný čas;
- rada se nesmí měnit při každém jednotlivém snímku analýzy.

### Pro

- přepnout na `PRO`;
- ověřit histogram, přepaly, ISO, čas, optický základ, crop a OEM stav;
- klepnout na AI a zkontrolovat plnou diagnostiku;
- otevření diagnostiky z jiného režimu musí automaticky přejít do Pro.

## 2. Priorita rad

1. Rozhýbat telefon při delším čase – musí vyhrát `Zklidněte telefon`.
2. Současně naklonit horizont a postavit obličej k okraji – nejprve musí vyhrát rovina.
3. Vytvořit přepálené okno a špatnou kompozici – musí vyhrát ochrana světel.
4. Po odstranění technických problémů se teprve smí objevit kompoziční rada.

## 3. Rovina v portrétu a krajině

- držet telefon přesně svisle – odchylka pod 1,5°;
- otočit telefon na šířku – odchylka musí znovu klesnout k 0°, nikoli k 90°;
- naklonit o přibližně 5° – směr šipky musí odpovídat skutečné korekci;
- po srovnání musí rada zmizet bez kmitání doleva/doprava.

## 4. Dokument

- položit papír na stůl a držet telefon šikmo – zobrazí se rovnoběžnost s papírem;
- telefon postupně srovnat – skóre flatness musí růst;
- po rovnoběžném držení zkontrolovat ostrost a přepaly;
- odlesk lampy musí mít přednost před jemnou kompozicí.

## 5. Obličej

- malý obličej pod přibližně 3,5 % obrazu – rada přiblížit se;
- velmi velký obličej – rada ustoupit;
- posunout tvář k levému a pravému okraji – správná směrová rada;
- přiblížit temeno k hornímu okraji – požadavek na prostor nad hlavou;
- několikrát zavřít obě oči – při spolehlivé klasifikaci se objeví čekání na otevřené oči;
- více osob – kompoziční cíl musí přejít blíže ke středu skupiny.

## 6. Ostrost

- zakrýt nebo zamastit objektiv v dostatečném světle – rada zkontrolovat ostření/objektiv;
- ve tmě nesmí nízká hranová energie sama o sobě vynutit falešnou radu o ostření;
- pohyb má mít před neostrostí prioritu.

## 7. Připravenost

- vytvořit stabilní, rovnou, nepřepálenou scénu;
- stav `Teď můžete fotit` se nesmí objevit po jediném snímku;
- musí přijít až po třech bezpečných analýzách;
- krátké jednorázové zakolísání nesmí READY okamžitě rozbít, varování ano.

## 8. Skutečný expoziční čas

- v Pro diagnostice sledovat skutečný čas;
- při 1/1000 s má kouč tolerovat pohyb odpovídající akční scéně;
- při 1/20–1/10 s musí být výrazně přísnější;
- změna pouze doporučeného textu bez změny CaptureResult nesmí práh ovlivnit.

## 9. Poslední zachycená rada

- pořídit snímek ve stavu READY;
- otevřít diagnostiku a ověřit `Poslední snímek` s vysvětlením;
- pořídit snímek během varování a ověřit změnu uloženého kontextu;
- přepínání režimů nesmí poslední zachycený pokyn vymazat.

## 10. Výkon a stabilita

- sledovat hledáček alespoň 10 minut;
- ověřit, že face detection nezpůsobuje postupný růst paměti;
- rychle přepínat objektivy, OEM režimy a orientaci;
- opakovaně opustit a obnovit aplikaci;
- nesmí zůstat neuzavřený `ImageProxy`, černý preview ani trvale aktivní senzor.

## 11. Regrese v0.6–v0.8

- ověřit pravdivou expozici a fallback;
- zkontrolovat fyzický objektiv a digitální crop;
- provést noční sérii z ruky, ze stativu i portrét;
- ověřit RAW/JPEG, EXIF, rotaci, dotykové ostření a ukládání do galerie.
