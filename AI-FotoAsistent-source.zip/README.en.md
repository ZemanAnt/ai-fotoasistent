# AI Photo Assistant for Samsung Galaxy S22 Ultra

A native Android camera written in Kotlin and Jetpack Compose. The app analyses the live preview entirely on-device and combines ML Kit scene and face detection with exposure telemetry, movement, sharpness, highlights, composition and the actual capabilities of each camera module.

> **Current version: 0.9.0 — AI Photo Coach**

The project is designed around one rule: requested settings must never be presented as applied settings until Camera2 telemetry confirms them.

## Highlights

- three viewfinder modes: Simple, AI Coach and Pro;
- one prioritised, explainable shooting cue at a time;
- actual shutter speed and ISO from `CaptureResult`;
- dynamic physical-lens catalogue instead of hard-coded Samsung camera IDs;
- separate optical magnification, digital crop and effective zoom;
- Smart Lens Engine with low-light telephoto protection;
- Computational Night with motion rejection, image alignment, tiled blending and reference-frame deghosting;
- local face position, size and eye-state guidance without identity recognition;
- RAW/DNG support where the selected camera exposes RAW capability;
- no `INTERNET` permission, analytics or advertising SDK.

## Requirements

- Android Studio
- JDK 17
- Android SDK 36
- Android 8.0 / API 26 or newer
- a real device for Camera2 and lens verification; Galaxy S22 Ultra is the primary target

## Build

Linux/macOS:

```bash
./gradlew lintDebug testDebugUnitTest assembleDebug
```

Windows:

```bat
gradlew.bat lintDebug testDebugUnitTest assembleDebug
```

The debug APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Repository documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Device compatibility](docs/COMPATIBILITY.md)
- [Privacy](docs/PRIVACY.md)
- [GitHub setup and signed releases](docs/GITHUB_SETUP.md)
- [Contributing](CONTRIBUTING.md)
- [Security policy](SECURITY.md)
- [Changelog](CHANGELOG.md)

## GitHub Actions

`Android CI` runs Android lint, JVM unit tests, a debug APK build and an unsigned release/R8 build. A separate release workflow can create a signed APK, signed AAB and SHA-256 checksum from encrypted GitHub Secrets when a `v*` tag is pushed.

## Known limitations

Samsung firmware may hide some physical camera IDs or reject direct physical-camera sessions. The app reports that state and falls back to the logical rear camera instead of pretending that an optical module was selected. Computational Night currently aligns global translation; large rotation, parallax or scene-wide motion can cause a frame to be rejected.

## License

Licensed under the Apache License 2.0. Samsung Galaxy is a trademark of Samsung Electronics Co., Ltd.; this independent project is not affiliated with or endorsed by Samsung.
