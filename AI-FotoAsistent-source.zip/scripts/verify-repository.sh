#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

fail=0

required=(
  README.md README.en.md LICENSE NOTICE SECURITY.md CONTRIBUTING.md
  gradlew gradlew.bat gradle/wrapper/gradle-wrapper.jar
)

for path in "${required[@]}"; do
  if [[ ! -e "$path" ]]; then
    echo "Missing: $path" >&2
    fail=1
  fi
done

if grep -RInE --exclude-dir=.git --exclude='verify-repository.sh' \
  '(BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|ANDROID_KEYSTORE_PASSWORD\s*=|keyPassword\s*=\s*".+")' .; then
  echo "Possible secret material found." >&2
  fail=1
fi

if find . -type f \( -name '*.jks' -o -name '*.keystore' -o -name '*.apk' -o -name '*.aab' \) -print -quit | grep -q .; then
  echo "Generated package or signing file found in repository." >&2
  fail=1
fi

if grep -q 'android.permission.INTERNET' app/src/main/AndroidManifest.xml; then
  echo "Unexpected INTERNET permission found." >&2
  fail=1
fi

if [[ ! -x gradlew ]]; then
  echo "gradlew is not executable." >&2
  fail=1
fi

if (( fail != 0 )); then
  exit 1
fi

echo "Repository structure and basic secret checks passed."
