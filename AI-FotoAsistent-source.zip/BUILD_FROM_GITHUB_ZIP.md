# Sestavení ze ZIPu na GitHubu

Tento zdrojový archiv je určen pro repozitář, ve kterém je v kořeni uložen jako:

`AI-FotoAsistent-source.zip`

Samostatný soubor `build.yml` musí být uložen v repozitáři na cestě:

`.github/workflows/build.yml`

Workflow archiv rozbalí, zkontroluje projekt a vytvoří debug APK dostupné v kartě **Actions** jako artefakt `AI-FotoAsistent-debug`.
