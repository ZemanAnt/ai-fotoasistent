# AI FotoAsistent pro Samsung Galaxy S22 Ultra

[English README](README.en.md)

Nativní Android fotoaparát v Kotlinu a Jetpack Compose. Živý obraz analyzuje výhradně v telefonu a kombinuje ML Kit, skutečnou Camera2 telemetrii, pohyb, ostrost, přepaly, kompozici a reálné schopnosti jednotlivých fotoaparátů.

> **Aktuální verze: 0.9.0 – AI Photo Coach**

Základní pravidlo projektu je jednoduché: aplikace nesmí vydávat požadované ISO, čas, objektiv nebo zoom za skutečně použité hodnoty, dokud je nepotvrdí zařízení.

## Hlavní funkce

- **Jednoduchý / AI kouč / Pro** – tři úrovně hledáčku od jediné rady po plnou diagnostiku;
- jeden prioritní a vysvětlitelný fotografický pokyn místo souběžného seznamu varování;
- skutečný čas a ISO z `CaptureResult`;
- dynamický katalog fyzických objektivů bez pevně zadaných Samsung Camera2 ID;
- oddělené optické zvětšení, digitální crop a výsledný efektivní zoom;
- **Smart Lens Engine** chrání kvalitu a za šera odmítá nevhodný teleobjektiv;
- **Computational Night** se zarovnáním snímků, odmítáním pohybu, tiled blendingem a deghostingem;
- lokální kontrola polohy a velikosti obličeje a pravděpodobně otevřených očí bez rozpoznávání identity;
- RAW/DNG na modulech, které zveřejňují RAW capability;
- nedestruktivní AI kopie fotografie;
- žádné oprávnění `INTERNET`, analytika ani reklamní SDK.

## Požadavky

- Android Studio
- JDK 17
- Android SDK 36
- Android 8.0 / API 26 nebo novější
- pro ověření Camera2 a objektivů skutečný telefon; primárním cílem je Galaxy S22 Ultra

Projekt používá Gradle 8.13, Android Gradle Plugin 8.11.1, Kotlin 2.2.20 a CameraX 1.6.1.

## Rychlé sestavení

Linux nebo macOS:

```bash
./gradlew lintDebug testDebugUnitTest assembleDebug
```

Windows:

```bat
gradlew.bat lintDebug testDebugUnitTest assembleDebug
```

Výsledné APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Jak číst pravdivé ovládání

### Objektiv

- **LOGICKÁ AUTO** – firmware vybírá fyzický modul;
- **POŽADOVÁN** – aplikace přestavuje session pro vybraný modul;
- **NAVÁZÁN, ČEKÁ NA DATA** – session běží, ale CaptureResult ještě modul nepotvrdil;
- **FYZICKY OVĚŘEN** – aktivní physical ID nebo samostatná kamera odpovídá požadavku;
- **DIGITÁLNÍ NÁHRADA** – fyzický modul nebyl dostupný a logická kamera používá crop.

Hodnota **optika** je základní zvětšení modulu. **Crop** je další digitální výřez. Efektivní zoom je jejich součin.

### Expozice

- **AUTO** – zobrazené ISO a čas jsou skutečné naměřené hodnoty;
- **ČEKÁM** – ruční požadavek byl odeslán a čeká na potvrzení;
- **OVĚŘENO** – CaptureResult potvrdil čas, ISO a vypnuté AE;
- **AE FALLBACK** – firmware ruční hodnoty nepotvrdil, aplikace použila bezpečnou automatiku;
- **BEZ MANUAL** – vybraný modul neposkytuje `MANUAL_SENSOR`.

## Dokumentace repozitáře

- [Architektura](docs/ARCHITECTURE.md)
- [Kompatibilita zařízení](docs/COMPATIBILITY.md)
- [Soukromí](docs/PRIVACY.md)
- [Nahrání na GitHub a podepsané releasy](docs/GITHUB_SETUP.md)
- [Testovací plán v0.9](docs/TEST_PLAN_V0_9.md)
- [Přispívání](CONTRIBUTING.md)
- [Bezpečnost](SECURITY.md)
- [Historie změn](CHANGELOG.md)

## GitHub Actions

Workflow **Android CI** automaticky provede Android lint, JVM testy, debug build a nepodepsaný release/R8 build. Workflow **Signed Android Release** umí z šifrovaných GitHub Secrets vytvořit podepsaný APK, AAB, SHA-256 součet a GitHub Release po odeslání tagu `v*`.

Aktuální workflow používají současné hlavní verze oficiálních akcí a Gradle action. Gradle wrapper je při CI automaticky validován.

## Soukromí

Aplikace nemá síťové oprávnění. Modely pracují lokálně a fotografie se ukládají pouze do systémového úložiště médií. Detekce obličeje neurčuje identitu člověka.

## Známá omezení

- Samsung může skrýt physical ID nebo odmítnout přímou fyzickou session; aplikace stav přizná a použije logickou kameru.
- OEM Extension session nemusí podporovat živou `ImageAnalysis`; poslední ověřená rada může zůstat zobrazená.
- Noční registrace opravuje globální posun. Velká rotace, paralaxa nebo rychlý pohyb celé scény mohou způsobit odmítnutí snímku.
- Prahy pohybu, portrétu a dokumentové perspektivy je nutné dále ladit na skutečných zařízeních.

## Licence a značky

Zdrojový kód je dostupný pod [Apache License 2.0](LICENSE). Samsung Galaxy je ochranná známka Samsung Electronics Co., Ltd. Projekt je nezávislý a není společností Samsung podporován ani schválen.
