# Changelog

## Repository preparation – GitHub edition

- doplněny české a anglické README pro veřejný repozitář;
- přidána Apache License 2.0, NOTICE, CONTRIBUTING a SECURITY policy;
- přidány formuláře pro chyby, návrhy funkcí a výsledky testů zařízení;
- CI používá aktuální hlavní verze GitHub Actions, Android lint, JVM testy a debug/release build;
- přidán bezpečný workflow podepsaného GitHub Release přes šifrované repository secrets;
- přidán Dependabot, automatické release notes, dependency submission a repository verifier;
- doplněna dokumentace nahrání na GitHub, kompatibility zařízení a soukromí;
- aplikační verze zůstává 0.9.0 / versionCode 10.

## 0.9.0 – AI Photo Coach

- přidány režimy hledáčku Jednoduchý, AI kouč a Pro;
- nový čistě kotlinový `PhotoCoachEngine` vrací jediný prioritní pokyn místo souběžného seznamu varování;
- rozhodování používá skutečný expoziční čas z `CaptureResult`, jas, přepaly, pohyb, ostrost, scénu, polohu telefonu a obličeje;
- přidán bundled ML Kit Face Detection 16.1.7 s rychlým režimem, trackingem a klasifikací otevřených očí;
- portrétní kouč kontroluje velikost obličeje, rezervu u okrajů a pravděpodobně zavřené oči;
- `SceneAnalyzer` nově počítá vizuální těžiště, jeho důvěru a normalizované skóre jemné kresby;
- dokumentový režim kontroluje rovnoběžnost telefonu s podložkou;
- nový `DevicePoseEstimator` správně normalizuje rovinu vůči portrétu i krajině a používá gravity sensor s fallbackem na akcelerometr;
- rady mají pevnou bezpečnostní prioritu: stabilita, perspektiva/rovina, přepaly, obličej, ostrost, kompozice a připravenost;
- `CoachCueStabilizer` potvrzuje běžnou radu dvěma analýzami a stav READY třemi; urgentní pokyn reaguje okamžitě;
- sensor tick-y nemohou falešně potvrdit kompoziční pokyn založený na starém obrazu;
- hledáček zobrazuje směrovou radu, cílový bod a skóre 0–100;
- AI odznak otevře Pro diagnostiku a režimový čip mění hustotu rozhraní;
- diagnostika zobrazuje počet obličejů, rovinu, aktuální vysvětlení a pokyn zachycený při posledním stisku spouště;
- doplněny testy priorit, zavřených očí, malé tváře, dokumentové perspektivy, READY stabilizace a orientace telefonu;
- bundled face model zachovává offline provoz a aplikace nadále nemá oprávnění k internetu;
- nezjištěné ML Kit klasifikační pravděpodobnosti se převádějí na `null`, takže nemohou vytvořit falešnou radu o zavřených očích;
- asynchronní analyzer vždy uvolní `ImageProxy` a po chybě jednoho modelu pokračuje dalšími snímky;
- verze aplikace zvýšena na 0.9.0 / versionCode 10.

## 0.8.0 – Computational Night

- prosté RGB/RAW průměrování nahrazeno výpočetním nočním pipeline;
- přidány profily AUTO, Z ruky, Stativ a Noční portrét s vlastními limity expozice, počtem snímků a deghostingem;
- nový `NightPlanner` vybírá profil podle scény, jasu a stability;
- nový `NightMotionTracker` měří úhlovou vzdálenost, špičku gyroskopu a impuls akcelerometru během každé expozice;
- nový čistě kotlinový `NightAlignment` registruje snímky na malé luma mapě a vrací posun, chybu a důvěru;
- registrace prochází všechny celočíselné kandidáty na řídkém vzorku, jemně ověřuje nejlepší výsledky a není závislá na liché/sudé paritě vyhledávacího okna;
- textura obrazu je součástí důvěry: jednolitá tma už nevytvoří falešný posun a nulový fallback je povolen jen při potvrzeném klidu senzorů;
- snímky s nadlimitním chvěním, chybnou registrací nebo pohybem většiny scény se odmítnou bez zrušení celé série;
- přidány náhradní pokusy a minimální použitelný počet přijatých snímků pro částečné dokončení série;
- `FrameStacker` drží jen průběžný průměr a mapu počtu vzorků; full-resolution data zpracovává po dlaždicích;
- per-pixel deghosting zachovává pohybující se objekty z referenčního snímku a průměruje jen stabilní pixely;
- dokončovací tónová křivka používá percentily histogramu, otevírá stíny a chrání světelné zdroje;
- dekódování, registrace a blending byly přesunuty z hlavního vlákna na `Dispatchers.Default`;
- UI zobrazuje aktivní noční profil, průběh, přijaté/odmítnuté snímky, posun a pohybovou masku;
- EXIF obsahuje profil, počet odmítnutých snímků, průměrný pohyb, maximální posun a skutečnou telemetrii;
- RAW je během Computational Night blokován, aby se nemíchala RAW+JPEG session se sekvenčním memory capture;
- opraveny starší kompilační duplicity v parametrech a závěrečná kontrola Kotlin PSI potvrdila syntaktickou čistotu všech zdrojů;
- ukládání nočního JPEG používá MediaStore `IS_PENDING`, ověřuje výsledek enkodéru a při chybě neúplný soubor odstraní;
- dokončovací pipeline bezpečně zachytí nedostatek paměti a vždy recykluje bitmapu;
- přidány testy registrace známého posunu, pohybové oblasti, automatického plánování a expozičního limitu;
- verze aplikace zvýšena na 0.8.0 / versionCode 9.

## 0.7.0 – Smart Lens Engine

- přidán dynamický katalog fyzických zadních objektivů z Camera2 charakteristik;
- každý profil eviduje fyzické/selektorové ID, ohnisko, 35mm ekvivalent, světelnost, velikost senzoru, OIS, RAW, ostřicí vzdálenost, aktivní pole a maximální digitální zoom;
- CameraX session umí vybrat konkrétní fyzický modul přes `setPhysicalCameraId()`;
- při odmítnutí fyzického modulu se automaticky naváže logická zadní kamera a fallback je označen jako digitální, nikoli optický;
- `CaptureTelemetry` nově čte aktivní fyzické ID, skutečné ohnisko a crop region;
- nový `LensTruth` rozlišuje požadovaný, navázaný a skutečně potvrzený objektiv;
- UI zobrazuje samostatně optický základ, digitální crop a efektivní zoom;
- pevná tlačítka 0,6× / 1× / 3× / 10× byla nahrazena dynamickým seznamem skutečně nalezených modulů;
- Smart Lens Engine vybírá objektiv podle scény, světla, pohybu a přepalů;
- slabé světlo blokuje teleobjektiv, supertele je automatické jen u jasného vzdáleného motivu a stabilní scény;
- stabilizátor vyžaduje tři shodná doporučení, aby se objektiv v UI neměnil při každém snímku analýzy;
- zapojeny CameraX OEM Extensions Auto, Night a HDR přes `ExtensionSessionConfig` s kontrolou dostupnosti;
- RAW, OEM Extensions a vlastní noční skládání se bezpečně vylučují;
- rozšířena diagnostika objektivů a přidány jednotkové testy rozhodovací logiky;
- verze aplikace zvýšena na 0.7.0 / versionCode 8.

## 0.6.0 – Stabilita a pravdivé ovládání

- přidána telemetrie z Camera2 `CaptureResult`: skutečný čas, ISO, režim AE/AWB/AF, ostřicí vzdálenost a čas snímače;
- opraveno zásadní mazání ruční expozice: druhé `setCaptureRequestOptions()` už nepřepisuje požadovaný čas a ISO;
- noční režim čeká na dva po sobě jdoucí odpovídající CaptureResult a odmítá zastaralé výsledky; bez potvrzení přejde na AE/AWB lock a EV fallback;
- UI důsledně rozlišuje doporučení, požadované nastavení a potvrzený výsledek;
- nový diagnostický panel po klepnutí na odznak AI zobrazuje Camera2 ID, hardware level, RAW, rozsah času/ISO a živé hodnoty;
- mřížka a maska přepalů se kreslí pouze do skutečné plochy 4:3/3:4 náhledu; ostření ignoruje dotyky v černých pruzích;
- průběžně se synchronizuje `targetRotation` Preview, ImageCapture i ImageAnalysis; aktivita používá `fullSensor`;
- AI postprocessing už nikdy nepřepisuje originál – ukládá samostatnou JPEG kopii a přenáší důležité EXIF údaje;
- RAW+JPEG callbacky se rozlišují podle skutečného MIME typu a mají pojistku proti trvalému stavu „ukládám“;
- metadata nočního snímku obsahují průměrný skutečný čas a ISO spárované podle timestampu;
- doplněn kompletní Gradle 8.13 wrapper s ověřeným JARem a SHA-256 distribuce;
- přidány testy potvrzení ruční expozice a odmítnutí falešně shodných automatických hodnot;
- verze aplikace zvýšena na 0.6.0 / versionCode 7.

## 0.5.0

- noční režim: skládání 4-16 snímků do jedné fotky s nižším šumem
  (průměrování potlačí šum zhruba √N krát);
- oprava detekce pohybu: vzorkování na pevné mřížce 48×36 místo kroku
  závislého na rozlišení - dřív se při změně rozlišení délka vzorků
  rozešla a pohyb se vyhodnotil jako nulový;
- doporučení blesku pokrývá všechny typy scén; u protisvětla se nově
  navrhne přisvícení, dřív spadlo všechno kromě portrétu a univerzální
  scény do "vypnuto";
- selhání startu fotoaparátu se ohlásí místo tichého černého náhledu;
- release build: zapnutý R8 a shrinkResources, vypnutá záloha dat;
- opraveno chybné vyhodnocení texturované krajiny (tráva, listí, les) jako
  makra - štítek scény má nově přednost před hustotou hran;
- po trvalém odmítnutí přístupu k fotoaparátu nabídne aplikace otevření
  nastavení; dřív tlačítko nedělalo nic a uživatel uvízl na úvodní obrazovce;
- při ukládání JPEG+RAW se chyba jednoho formátu už nezasekne na stavu
  "ukládám" a fotka se nabídne, pokud se uložil aspoň jeden soubor;
- noční snímání se ukončí po 15 s, i když přestanou chodit snímky;
- poloviční spotřeba paměti při skládání (akumulátory Int místo Long)
  a pojistka proti vyčerpání paměti u velkých rozlišení;
- během nočního snímání se zamyká expozice a vyvážení bílé; bez zámku
  automatika mezi snímky dolaďovala jas a průměr se rozmazal o odchylku,
  kterou skládání neodstraní;
- pohyb se nově hlídá i v průběhu snímání - rozhýbaný telefon snímání
  zruší místo uložení rozmazané fotky;
- složená fotka dostala metadata: orientaci (jinak se v galerii zobrazila
  otočená), počet složených snímků a název aplikace;
- dokončovací úpravy nočního snímku: hranově citlivé odšumění a místní
  vyrovnání jasu. Pořadí je podstatné - odšumit až po zesílení kontrastu
  by zesílilo i šum. Měření na složeném snímku: zhruba 1,6x vyšší kontrast
  při dvojnásobně lepším poměru signál/šum;
- běžná fotka se po uložení dotáhne, ale jen když na tom získá - tedy
  u tmavých snímků a u ztracených stínů. Dobře exponovaný snímek zůstane
  beze změny, protože úpravou skoro nezíská. Úprava se dotýká jen jasu,
  barevné odstíny zůstávají (ověřeno: posun pod 1 stupeň);
- velmi tmavé snímky se nově zvedají i gama korekcí. Na skutečné noční
  fotce z telefonu mělo 96 % plochy jas pod 28 a samotné vyrovnání
  histogramu zvedlo průměr jen z 16 na 24 - snímek zůstal černý.
  S gamou vychází 62 a černá plocha zmizí úplně;
- noční režim nově exponuje jednotlivé snímky ručně, typicky 1/4 až 1/2,5 s
  místo náhledových zhruba 1/30 s. To je to hlavní, co dělalo rozdíl proti
  telefonům s dobrým nočním režimem: sedm snímků z náhledu nasbírá dohromady
  jen zlomek sekundy světla, kdežto s delší expozicí je nasbíraného světla
  zhruba patnáctkrát víc. Snímků proto stačí méně (10 místo 16) a snímání
  trvá do čtyř sekund. Když snímač ruční expozici neumí, zůstane aspoň
  zámek automatiky jako dřív.

## 0.1.0

- první funkční CameraX fotoaparát;
- lokální AI rozpoznávání scén;
- fotografický poradce pro deset typů scén;
- histogram, vodováha, mřížka a dotykové ostření;
- zoom, korekce expozice, blesk a ukládání do MediaStore;
- české mobilní rozhraní.
